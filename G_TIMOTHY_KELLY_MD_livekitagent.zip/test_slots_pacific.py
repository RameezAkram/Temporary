"""
test_slots_pacific.py
─────────────────────
Fetches appointment availability from the CareCloud API and converts
all slot times to Pacific Time (PDT / PST — DST handled automatically).

Usage:
    python test_slots_pacific.py
"""

import urllib.request
import json
from datetime import datetime
from zoneinfo import ZoneInfo

# ─── API request config ──────────────────────────────────────────────────────

URL = (
    "https://services-new-infra.carecloud.com/appointment_availability.json"
    "?date_range_start=2027-01-25"
    "&date_range_end=2027-02-25"
    "&token=AQIC5wM2LY4SfcwHTKHeVhxoWVvaUNDHUJ4MNvORlcD-PbY.*AAJTSQACMDIAAlNLAAstMjAzNjA1OTEyNAACUzEAAjAx*"
    "&business_entity_id=4944"
    "&original_business_entity_id=4944"
    "&search_criterias[][resource_ids][]=24133"
    "&search_criterias[][location_ids][]=29414"
    "&search_criterias[][nature_of_visit_id]=79304"
    "&morning=true&afternoon=true&sequential=true"
    "&monday=true&tuesday=true&wednesday=true&thursday=true&friday=true"
    "&saturday=false&sunday=false"
)

HEADERS = {
    "Accept": "application/json",
    "Authorization": "Bearer 3uW8bbYsnISboc0_iVP2Xp-ZGoX8R01O",
}

PACIFIC = ZoneInfo("America/Los_Angeles")


# ─── Conversion helpers ───────────────────────────────────────────────────────

def convert_to_pacific(iso_string: str) -> str:
    """
    Parse an ISO-8601 string (any UTC offset) and return it
    re-expressed in America/Los_Angeles (PDT or PST as appropriate).
    """
    dt = datetime.fromisoformat(iso_string)
    pacific_dt = dt.astimezone(PACIFIC)
    return pacific_dt.isoformat()


def convert_slot_to_pacific(slot: dict) -> dict:
    return {
        "start_time": convert_to_pacific(slot["start_time"]),
        "end_time":   convert_to_pacific(slot["end_time"]),
    }


def _tz_abbr_from_offset(offset_hours: float) -> str:
    """Return a human-readable abbreviation for common US offsets."""
    return {
        -4.0: "EDT",
        -5.0: "EST",
        -6.0: "CST / MDT",
        -7.0: "PDT / MST",
        -8.0: "PST",
    }.get(offset_hours, f"UTC{int(offset_hours):+d}")


def convert_pacific_to_original(pacific_iso: str, original_iso: str) -> str:
    """
    Re-express a Pacific-Time ISO string back into the UTC offset that
    the original API slot used (e.g. -05:00 for EST, -04:00 for EDT).

    pacific_iso  – slot time already in America/Los_Angeles
    original_iso – the raw slot string from the API (provides the target offset)

    Returns a formatted string like "11:30 AM EST (-05:00)"
    """
    pacific_dt  = datetime.fromisoformat(pacific_iso)
    original_dt = datetime.fromisoformat(original_iso)

    # Restore the original UTC offset
    target_tz   = original_dt.tzinfo
    restored_dt = pacific_dt.astimezone(target_tz)

    offset_hours = restored_dt.utcoffset().total_seconds() / 3600
    abbr         = _tz_abbr_from_offset(offset_hours)
    offset_str   = f"{int(offset_hours):+03d}:00"

    return restored_dt.strftime("%I:%M %p") + f"  {abbr} ({offset_str})"


# ─── Fetch ────────────────────────────────────────────────────────────────────

def fetch_slots() -> dict:
    """Returns the first (and only) availability group from the API list response."""
    req = urllib.request.Request(URL, headers=HEADERS)
    with urllib.request.urlopen(req, timeout=30) as resp:
        payload = json.loads(resp.read().decode())
    # API returns a list of availability groups; we always use the first entry
    if isinstance(payload, list):
        return payload[0] if payload else {}
    return payload


# ─── Main ─────────────────────────────────────────────────────────────────────

def main():
    print("Fetching slots from CareCloud API …\n")
    data = fetch_slots()

    location     = data.get("location", {})
    visit_reason = data.get("visit_reason", {})
    resource     = data.get("resource", {})
    raw_slots    = data.get("slots", [])

    print(f"  Location     : {location.get('name')}  (id {location.get('id')})")
    print(f"  Visit reason : {visit_reason.get('name')}  (id {visit_reason.get('id')})")
    print(f"  Resource     : {resource.get('name')}  (id {resource.get('id')})")
    print(f"  Total slots  : {len(raw_slots)}")
    print()

    # Convert every slot to Pacific Time; keep originals for reverse display
    pacific_slots = [convert_slot_to_pacific(s) for s in raw_slots]

    # Group by date for readability (keep raw slot paired for reverse conversion)
    by_date: dict[str, list[tuple[dict, dict]]] = {}
    for raw, pac in zip(raw_slots, pacific_slots):
        date_key = pac["start_time"][:10]
        by_date.setdefault(date_key, []).append((raw, pac))

    # ── Print ─────────────────────────────────────────────────────────────────
    print("=" * 90)
    print(f"{'ALL AVAILABLE SLOTS  →  PACIFIC TIME  +  ORIGINAL TIMEZONE':^90}")
    print("=" * 90)
    print(f"  {'PACIFIC TIME':<28}  {'ORIGINAL (API) TIMEZONE'}")
    print(f"  {'─' * 86}")

    for date_str, pairs in sorted(by_date.items()):
        day_label = datetime.strptime(date_str, "%Y-%m-%d").strftime("%A, %B %d %Y")
        print(f"\n  📅  {day_label}")
        print(f"  {'─' * 86}")
        for raw, pac in pairs:
            # Pacific side
            p_start = datetime.fromisoformat(pac["start_time"])
            p_end   = datetime.fromisoformat(pac["end_time"])
            p_off   = p_start.utcoffset().total_seconds() / 3600
            p_abbr  = "PDT" if p_off == -7 else "PST"
            pac_str = f"{p_start.strftime('%I:%M %p')} – {p_end.strftime('%I:%M %p')}  {p_abbr}"

            # Reverse side — original timezone from raw API slot
            rev_start = convert_pacific_to_original(pac["start_time"], raw["start_time"])
            rev_end   = convert_pacific_to_original(pac["end_time"],   raw["end_time"])

            print(f"    {pac_str:<30}  ←→   {rev_start}  |  end: {rev_end}")

    print()
    print(f"  Total slots : {len(pacific_slots)}")
    print("=" * 90)


if __name__ == "__main__":
    main()
