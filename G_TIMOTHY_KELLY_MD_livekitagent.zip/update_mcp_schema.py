"""
Fetch the latest MCP tool schema from the remote N8N MCP server and save to mcp_schema.json.

Usage:
    python update_mcp_schema.py
"""

import asyncio
import json
import os
from dotenv import load_dotenv
from mcp.client.sse import sse_client
from mcp.client.session import ClientSession

# Load env vars from .env
load_dotenv()

MCP_URL = os.environ.get("N8N_MCP_SERVER_URL", "https://n8n.carecloud.com/mcp/Stratus_AI_MCP_Universal")
OUTPUT_FILE = os.path.join(os.path.dirname(__file__), "mcp_schema.json")


async def fetch_schema():
    print(f"Connecting to MCP server: {MCP_URL}")
    
    async with sse_client(url=MCP_URL, timeout=60, sse_read_timeout=60) as transport:
        read_stream, write_stream = transport
        async with ClientSession(read_stream, write_stream) as session:
            await session.initialize()
            print("Session initialized. Fetching tools list...")
            
            result = await session.list_tools()
            tools = result.tools
            
            print(f"Fetched {len(tools)} tools from MCP server.\n")
            
            # Convert to serializable dicts
            schema = []
            for tool in tools:
                tool_dict = {
                    "name": tool.name,
                    "description": tool.description or "",
                    "inputSchema": tool.inputSchema if tool.inputSchema else {},
                }
                schema.append(tool_dict)
                print(f"  - {tool.name}")
            
            # Write to file
            with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
                json.dump(schema, f, indent=2, ensure_ascii=False)
            
            print(f"\nSchema saved to {OUTPUT_FILE}")


if __name__ == "__main__":
    asyncio.run(fetch_schema())
