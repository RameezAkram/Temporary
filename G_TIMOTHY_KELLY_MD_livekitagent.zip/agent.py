from concurrent.futures import thread
import threading
import time as t
import json
import uuid
from datetime import datetime
import os
from dotenv import load_dotenv

load_dotenv()  # Load env vars BEFORE any LangGraph/LangSmith imports

# LangSmith background thread — prevents non-daemon threads from blocking process exit
os.environ.setdefault("LANGCHAIN_CALLBACKS_BACKGROUND", "true")

from prompts import AGENT_INSTRUCTION, SESSION_INSTRUCTION
from livekit import agents
from livekit.agents import AgentSession, Agent, llm, BackgroundAudioPlayer, AudioConfig, BuiltinAudioClip
from livekit.agents.voice.room_io import RoomOptions, AudioInputOptions
from livekit.plugins import noise_cancellation
from livekit.plugins import openai as openai_plugin
from livekit.plugins import silero
from livekit.plugins import elevenlabs
from livekit.plugins.elevenlabs import VoiceSettings
from mcp_client import MCPServerSse, create_transfer_to_human_tool
from mcp_client.agent_tools import MCPToolsIntegration, _processed_kwargs_store, set_agent_session
import asyncio
import openai as openai_sdk
from langsmith import traceable
from langsmith.wrappers import wrap_openai

# Note: OpenAI Realtime is not used in this configuration
# We use standard OpenAI LLM with OpenAI Whisper STT and Cartesia TTS
from tools import get_available_locations, get_location_resources, get_provider_schedule, lookup_payer, lookup_insurance_policy_type
from db import execute_query

from business_entity_fetcher import fetch_and_store_business_entity_data, get_business_entity_summary
from transcription_manager import TranscriptionManager
from token_manager import TokenManager
from booking_graph import BookingWorkflow
from booking_tools import (
    set_booking_workflow,
    booking_check_availability,
    booking_create_appointment,
    booking_cancel_appointment,
    booking_reschedule_appointment,
    booking_view_appointments,
    booking_get_state,
)
import logging

logger = logging.getLogger(__name__)

# Suppress noisy AdaptiveInterruptionDetector 401 warnings (cloud feature not available locally)
for _name in ("livekit.agents.inference.interruption", "livekit.agents"):
    _lg = logging.getLogger(_name)
    _lg.addFilter(lambda r: "interruption" not in r.getMessage().lower() and "bargein" not in r.getMessage().lower() and "_main_task" not in r.getMessage())



# ============================================
# TOKEN REFRESH SINGLETON
# ============================================
TokenManager().load_from_db()
TokenManager().start()


class Assistant(Agent):
    def __init__(self, booking_tools_list=None) -> None:
        # Initialize with main agent instructions with critical validation rules
        user_profile_id = os.environ.get("USER_PROFILE_ID", "25819082")
        business_id = os.environ.get("BUSINESS_ID", "4944")
        enhanced_instructions = f"""
    {AGENT_INSTRUCTION}

    **DEFAULT USER PROFILE ID: {user_profile_id}**
    Use this only for fields named user_profile_id. It is never a patient_id.

    **PATIENT ID RULE**
    patient_id must come from the verified patient returned by Patient_Verification (or equivalent lookup). Never reuse user_profile_id as patient_id. If no verified patient_id is available, ask the user to verify the patient first.

    **DEFAULT BUSINESS ID: {business_id}**
    Use this ID whenever a business ID is required in any tool call.
    
    **BOOKING WORKFLOW TOOLS**
    Use the booking_* tools for appointment operations - they have built-in retry logic and validation.
"""
        # Base local tools
        tools = [get_available_locations, get_location_resources, get_provider_schedule, lookup_payer, lookup_insurance_policy_type]
        
        # Add booking tools if provided
        if booking_tools_list:
            tools.extend(booking_tools_list)
        
        super().__init__(instructions=enhanced_instructions, tools=tools)
        self.current_workflow = None
        self.patient_verified = False



@traceable(
    run_type="chain",
    name="gtk-call-console",
    tags=["appointment", "gtk-appointment-agent", "call"],
    metadata={"agent_name": "gtk-appointment-agent"},
)
async def entrypoint(ctx: agents.JobContext):
    # ============================================
    # STEP -1: CLEAR SESSION STATE FOR NEW CALL
    # ============================================
    # Clear per-call session state (verified patient, slot maps, etc.)
    from mcp_client.agent_tools import clear_session_state
    clear_session_state()

    # ============================================
    # STEP -0.5: REFRESH TOKENS FROM DB FOR THIS CALL
    # ============================================
    TokenManager().load_from_db()
    logger.info("[CALL] Tokens refreshed from DB for new call")
    
    # ============================================
    # STEP 0: UPDATE LOCATIONS BEFORE AGENT STARTS
    # ============================================
    auto_update = os.environ.get("AUTO_UPDATE_LOCATIONS", "true").lower() == "true"
    
    if auto_update:
        logger.info("\n" + "="*60)
        logger.info("🔄 Updating location knowledge base...")
        logger.info("="*60)
        
        # try:
        #     def auto_runner():
        #         while True:
        #             asyncio.run(run_location_update())
        #             t.sleep(60)  # 1 hour safely
        #     thread = threading.Thread(target=auto_runner, daemon=True)
        #     thread.start()

        #     print("🔁 Auto location update started — runs every 1 hour in background!")
        # except Exception as e:
        #     print(f"⚠️ Warning: Could not update locations: {e}")
        #     print("⚠️ Agent will continue with existing locations from Knowledgebase.py")
        # print("="*60 + "\n")
    else:
        logger.info("ℹ️ Auto-update locations disabled (set AUTO_UPDATE_LOCATIONS=true to enable)\n")
    
    # ============================================
    # START AGENT SESSION WITH LANGSMITH TRACING
    # ============================================
    # Create LangSmith-wrapped OpenAI client for full tracing (tokens, cost, latency)
    traced_openai_client = wrap_openai(openai_sdk.AsyncOpenAI(
        api_key=os.environ.get("OPENAI_API_KEY"),
    ))

    # Initialize ElevenLabs TTS
    # Model:  eleven_flash_v2_5 — recommended for real-time agents (~75ms TTFB)
    # Voice: Sarah — soft, calm, professional receptionist tone
    tts_engine = elevenlabs.TTS(
        voice_id="tnSpp4vdxKPjI9w0GnoV",  # Sarah — Soft, Calm, Professional
        model="eleven_flash_v2_5",
        api_key=os.environ.get("ELEVEN_API_KEY"),
        voice_settings=VoiceSettings(
            stability=0.40,
            similarity_boost=0.55,
            style=0.15,
            speed=0.95,
            use_speaker_boost=False,
        ),
    )

    session = AgentSession(
        stt=openai_plugin.STT(
            model="gpt-4o-transcribe",
            # No language restriction — auto-detect Arabic, Spanish, Urdu, etc.
        ),
        llm=openai_plugin.LLM(
            model="gpt-4.1",
            client=traced_openai_client,   # LangSmith-wrapped client → traces every LLM call
            temperature=0.3,          # Low temperature for reliable tool calling
        ),
        tts=tts_engine,
        vad=silero.VAD.load(
            min_speech_duration=0.15,
            min_silence_duration=0.3,
            activation_threshold=0.4,
            prefix_padding_duration=0.4,
        ),
        min_endpointing_delay=0.15,
        min_interruption_duration=0.4,  # Voice activity detection for interruption handling
    )

    # Wire session into tool layer so MCP tools can say "One moment please"
    # when a tool call takes longer than 8 seconds (prevents dead air).
    set_agent_session(session)

    # Initialize background audio player
    # - ambient_sound: plays crowd-talking-3.mp3 on loop throughout the entire call
    # - thinking_sound: plays keyboard typing when the agent is processing/thinking
    _audio_dir = os.path.dirname(os.path.abspath(__file__))
    _crowd_audio_path = os.path.join(_audio_dir, "crowd-talking-3.mp3")
    background_audio = BackgroundAudioPlayer(
        ambient_sound=AudioConfig(
            source=_crowd_audio_path,
            volume=0.15,  # Soft background ambience — raise/lower as needed (0.0–1.0)
            probability=1.0,  # Always play the ambience track
        ),
        thinking_sound=[
            AudioConfig(BuiltinAudioClip.KEYBOARD_TYPING, volume=0.8, probability=1.0),
            AudioConfig(BuiltinAudioClip.KEYBOARD_TYPING2, volume=0.7, probability=1.0),
        ],
        stream_timeout_ms=3000,  # If TTS takes longer than 3 seconds, play thinking sound until it finishes (prevents dead air during long tool calls or LLM responses)
    )

    mcp_url = os.environ.get("N8N_MCP_SERVER_URL")
    logger.info(f"DEBUG: MCP Server URL: {mcp_url}")
    
    if not mcp_url:
        logger.error("ERROR: N8N_MCP_SERVER_URL environment variable is not set!")
        mcp_url = "http://10.20.35.68:9070/sse"  # Fallback URL
        logger.info(f"Using fallback URL: {mcp_url}")

    try:
        # Add proper headers for n8n MCP server to prevent 406 errors
        mcp_headers = {
            "Content-Type": "application/json",
            "Accept": "application/json, text/event-stream, */*"
        }
        
        mcp_server = MCPServerSse(
            params={
                "url": mcp_url,
                "headers": mcp_headers
            },
            cache_tools_list=True,
            name="SSE MCP Server"
        )
        logger.info(f"DEBUG: MCP Server initialized successfully with headers")
    except Exception as e:
        logger.error(f"ERROR: Failed to initialize MCP Server: {e}")
        raise

    # ============================================
    # INITIALIZE BOOKING WORKFLOW (LangGraph)
    # ============================================
    booking_workflow = BookingWorkflow(mcp_server)
    set_booking_workflow(booking_workflow)
    logger.info("[BOOKING] LangGraph booking workflow initialized")

    # Collect booking tools
    booking_tools_list = [
        booking_check_availability,
        booking_create_appointment,
        booking_cancel_appointment,
        booking_reschedule_appointment,
        booking_view_appointments,
        booking_get_state,
    ]

    agent = await MCPToolsIntegration.create_agent_with_tools(
        agent_class=Assistant,
        mcp_servers=[mcp_server],
        agent_kwargs={"booking_tools_list": booking_tools_list}
    )
    
    # Log all tools (including custom tools) — printed after ALL tools are registered
    # (This block is intentionally left empty here; final count logged after transfer tool is added below)

    # Pre-warm tokens: reload the freshest tokens from DB right before the session
    # connects. The background refresh daemon may have updated the DB between
    # module-load time and the first LLM tool call. Without this, a stale token
    # can cause a 401 auth failure on the very first tool invocation.
    TokenManager().load_from_db()
    logger.info("[AGENT] Tokens reloaded from DB — first tool call pre-warmed")

    # ============================================
    # FETCH BUSINESS ENTITY DATA IN BACKGROUND
    # ============================================
    async def fetch_business_data_background():
        """Background task to fetch business entity data"""
        try:
            logger.info("\n" + "="*60)
            logger.info("📊 Fetching Business Entity Data (background)...")
            logger.info("="*60)
            success = await fetch_and_store_business_entity_data(mcp_server)
            if success:
                summary = await get_business_entity_summary()
                logger.info(summary)
            else:
                logger.warning("⚠️ Using existing data.txt file")
            logger.info("="*60 + "\n")
        except Exception as e:
            logger.warning(f"⚠️ Warning: Could not fetch business entity data: {e}")
            logger.warning("⚠️ Agent will continue with existing data.txt")
            logger.info("="*60 + "\n")
    
    # NOTE: fetch_business_data_background task is launched AFTER session.start() below.
    # Launching it here would compete with Cartesia TTS WebSocket pre-warm in the event
    # loop, causing the 10-second pre-warm timeout and a ~14-second greeting delay.
    logger.info("🚀 Agent starting... (Business data will fetch after session starts)")

    # ============================================
    # TRANSCRIPTION MANAGER SETUP
    # ============================================
    caller_number = os.environ.get("CALLER_PHONE_NUMBER", "unknown")
    session_id = str(uuid.uuid4())[:12]
    transcript_mgr = TranscriptionManager(session_id=session_id, caller_number=caller_number)
    logger.info(f"[TRANSCRIPT] Initialized for session {session_id}, caller {caller_number}")

    # ============================================
    # SILENCE MONITOR
    # ============================================
    # Tracks the last time ANY conversation activity occurred (user speech,
    # agent reply, or tool execution).  A background task checks every 5 s
    # and says "Are you still there?" if 30 s of complete silence passes.
    # The warning itself resets the timer so repeated silence re-prompts.
    _last_activity: dict = {"ts": t.time()}
    _silence_task: dict = {"task": None}
    SILENCE_THRESHOLD_SECS = 30

    def _reset_silence_timer():
        _last_activity["ts"] = t.time()

    async def _silence_monitor():
        """Background coroutine: prompt the caller after SILENCE_THRESHOLD_SECS of silence."""
        CHECK_INTERVAL = 5  # poll every 5 seconds
        prompts = [
            "Are you still there?",
            "I'm still here if you need help. Are you there?",
        ]
        prompt_index = 0
        while True:
            await asyncio.sleep(CHECK_INTERVAL)
            elapsed = t.time() - _last_activity["ts"]
            if elapsed >= SILENCE_THRESHOLD_SECS:
                msg = prompts[prompt_index % len(prompts)]
                prompt_index += 1
                logger.info(f"[SILENCE] {elapsed:.0f}s of silence detected — prompting caller: '{msg}'")
                # Reset timer BEFORE speaking so the say() call itself doesn't
                # re-trigger another prompt before the caller has a chance to respond.
                _reset_silence_timer()
                try:
                    await session.say(msg, allow_interruptions=True)
                except Exception as _se:
                    logger.warning(f"[SILENCE] say() failed (non-fatal): {_se}")

    # --- Event: final user speech transcriptions ---
    @session.on("user_input_transcribed")
    def _on_user_transcribed(event):
        try:
            if event.is_final and event.transcript:
                _reset_silence_timer()
                transcript_mgr.add_user_message(event.transcript)
        except Exception as e:
            logger.error(f"[TRANSCRIPT] Error capturing user speech: {e}")

    # --- Event: conversation items (captures agent messages) ---
    @session.on("conversation_item_added")
    def _on_conversation_item(event):
        try:
            item = event.item
            if getattr(item, "role", None) == "assistant":
                _reset_silence_timer()
                text = getattr(item, "text_content", None)
                if text:
                    transcript_mgr.add_agent_message(text)
        except Exception as e:
            logger.error(f"[TRANSCRIPT] Error capturing agent message: {e}")

    # --- Event: tool / function calls executed ---
    @session.on("function_tools_executed")
    def _on_tools_executed(event):
        try:
            _reset_silence_timer()
            for call, output in event.zipped():
                args = {}
                try:
                    args = json.loads(call.arguments) if call.arguments else {}
                except Exception:
                    args = {"raw": call.arguments}

                # For create_insurance (and any other pre-processed tool), replace raw LLM
                # args with the fully fuzzy-matched / resolved kwargs that were actually
                # sent to the API.  This keeps the transcript truthful.
                if call.name in _processed_kwargs_store:
                    args = dict(_processed_kwargs_store[call.name])

                result = output.output if output else None
                transcript_mgr.add_tool_call(
                    tool_name=call.name,
                    arguments=args,
                    result=result,
                )
        except Exception as e:
            logger.error(f"[TRANSCRIPT] Error capturing tool call: {e}")

    # --- Event: session close – stop silence monitor + finalize & save transcript ---
    @session.on("close")
    def _on_session_close(event):
        try:
            # Cancel the silence monitor so it doesn't fire after the call ends
            _task = _silence_task.get("task")
            if _task and not _task.done():
                _task.cancel()
                logger.info("[SILENCE] Monitor cancelled on session close")
        except Exception:
            pass
        try:
            logger.info(f"[TRANSCRIPT] Session closing (reason={event.reason})")
            transcript_mgr.mark_session_closed()
            transcript_mgr.finalize(force=True)
            transcript_mgr.save_json()
            logger.info(f"[TRANSCRIPT] Transcription saved for session {session_id}")
        except Exception as e:
            logger.error(f"[TRANSCRIPT] Error during finalization: {e}")

    # Connect to the LiveKit room FIRST — required before publishing any tracks
    await ctx.connect()

    # ============================================
    # TRANSFER TO HUMAN TOOL
    # ============================================
    transfer_to_human = create_transfer_to_human_tool(ctx, session)
    if hasattr(agent, '_tools') and isinstance(agent._tools, list):
        agent._tools.append(transfer_to_human)

        all_tool_names = [getattr(t, '__name__', 'unknown') for t in agent._tools]
        logger.info(f"[SETUP] transfer_to_human tool registered")
        logger.info(f"DEBUG: Total tools registered: {len(agent._tools)}")
        logger.info(f"DEBUG: All tool names: {all_tool_names}")

    # BVCTelephony noise cancellation — enabled unconditionally.
    # Self-hosted LiveKit now supports BVC; this filters patient-side telephony
    # noise (TV, background chatter, etc.) before audio reaches the STT pipeline.
    await session.start(
        room=ctx.room,
        agent=agent,
        room_options=RoomOptions(
            audio_input=AudioInputOptions(
                noise_cancellation=noise_cancellation.BVCTelephony(),
            )
        ),
    )

    # Launch business entity fetch NOW — after session.start() — so Cartesia's WebSocket
    # pre-warm (triggered by session.start) has uncontested event-loop time to connect.
    # Launching it earlier caused the pre-warm to lose the 10-second race, producing
    # ~14 seconds of caller silence before the greeting played.
    asyncio.create_task(fetch_business_data_background())
    logger.info("📊 Business entity fetch launched (background, post-session-start)")

    # Start session with comprehensive instructions BEFORE background audio so that
    # audio file I/O does not compete with TTS synthesis for the greeting.
    await session.generate_reply(
        instructions=SESSION_INSTRUCTION,
    )

    # Start background audio AFTER the greeting is dispatched — file I/O no longer
    # competes with Cartesia TTS synthesis for the opening phrase.
    await background_audio.start(
        room=ctx.room,
        agent_session=session,
    )

    # Start silence monitor AFTER the greeting is dispatched so the 30-second
    # clock begins from the moment Sara finishes saying the opening phrase.
    _silence_task["task"] = asyncio.create_task(_silence_monitor())
    logger.info("[SILENCE] Monitor started (threshold: 30 s)")

if __name__ == "__main__":
    agents.cli.run_app(
        agents.WorkerOptions(
            entrypoint_fnc=entrypoint,
            agent_name="gtkml_appointment_agent",
        )
    )