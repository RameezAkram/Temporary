"""
CareCloud Companion (WS) Token Refresh Service
------------------------------------------------
Replicates the n8n workflow that:
1. Calls the Companion login endpoint to obtain an authtoken
2. Updates TokenTable in the database with the new ws_auth_token
"""

import os
import time
import logging
import requests
from dotenv import load_dotenv

# Reuse existing DB helpers
from db import execute_update

load_dotenv()

# ---------------------------------------------------------------------------
# Configuration (override via environment variables)
# ---------------------------------------------------------------------------
COMPANION_USERNAME = os.getenv("COMPANION_USERNAME", "stratusai_gtk@carecloud.com")
COMPANION_PASSWORD = os.getenv("COMPANION_PASSWORD", "str@tus@Ai426*$")
COMPANION_API_KEY = os.getenv("COMPANION_API_KEY", "OYKCRgkVlMRR1AtbxDmOnVHS0f-eQ7e3")
COMPANION_DEVICE_ID = os.getenv("COMPANION_DEVICE_ID", "62122DB9-964E-4607-8355-9CBD8C0C17DD")
BUSINESS_ENTITY_ID = os.getenv("BUSINESS_ID", "4944")

LOGIN_URL = (
    f"https://services-companion.carecloud.com/login.json"
    f"?login={COMPANION_USERNAME}&password={COMPANION_PASSWORD}"
)

# ---------------------------------------------------------------------------
# Logging  (use a dedicated logger — never call basicConfig here so we
# don't hijack the root logger when imported by agent.py)
# ---------------------------------------------------------------------------
logger = logging.getLogger("ws_token_refresh")
if not logger.handlers:
    _handler = logging.StreamHandler()
    _handler.setFormatter(logging.Formatter(
        "%(asctime)s [WS_TOKEN] %(levelname)s %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    ))
    logger.addHandler(_handler)
    logger.setLevel(logging.INFO)

# ---------------------------------------------------------------------------
# Core login flow
# ---------------------------------------------------------------------------

def _fetch_companion_token() -> str:
    """Call the Companion login endpoint and return the authtoken."""
    headers = {
        "Host": "services-companion.carecloud.com",
        "CC-APP-API-KEY": COMPANION_API_KEY,
        "Accept": "application/json",
        "User-Agent": "Companion%20Plus/1 CFNetwork/1399 Darwin/24.6.0",
        "Accept-Language": "en-US,en;q=0.9",
        "Connection": "keep-alive",
        "Pragma": "no-cache",
        "Cache-Control": "no-cache",
    }
    body = {
        "device": {
            "device_id": COMPANION_DEVICE_ID,
            "device_type:": "Simulator (iPhone15,2)",
        }
    }

    resp = requests.get(LOGIN_URL, headers=headers, json=body, allow_redirects=True)
    resp.raise_for_status()
    data = resp.json()

    authtoken = data.get("authtoken")
    if not authtoken:
        raise ValueError(f"No authtoken in response: {data}")

    logger.info("Companion authtoken obtained (length=%d)", len(authtoken))
    return authtoken


def _update_ws_token_in_db(authtoken: str) -> bool:
    """Write the new WS token to the TokenTable."""
    success = execute_update(
        "UPDATE TokenTable SET ws_auth_token = ? WHERE business_entity = ?",
        [authtoken, BUSINESS_ENTITY_ID],
    )
    if success:
        logger.info("ws_auth_token stored in DB for business_entity=%s", BUSINESS_ENTITY_ID)
    else:
        logger.error("Failed to update ws_auth_token in DB for business_entity=%s", BUSINESS_ENTITY_ID)
    return success


MAX_REFRESH_RETRIES = 3
RETRY_BACKOFF_SECONDS = 5


def get_fresh_ws_token() -> str:
    """Run the Companion login flow and return the new authtoken string.

    Pure HTTP — no DB update, no os.environ side effects.
    TokenManager calls this and owns the update responsibility.

    Retries up to MAX_REFRESH_RETRIES times on transient network/HTTP errors.
    Raises the last exception on final failure so the caller can decide how
    to handle it.
    """
    last_exc: Exception | None = None
    for attempt in range(1, MAX_REFRESH_RETRIES + 1):
        try:
            logger.info("Starting Companion (WS) token fetch (attempt %d/%d)…", attempt, MAX_REFRESH_RETRIES)
            authtoken = _fetch_companion_token()
            logger.info("Companion token fetched successfully (len=%d)", len(authtoken))
            return authtoken

        except (requests.ConnectionError, requests.Timeout) as exc:
            last_exc = exc
            logger.warning("Network error on attempt %d/%d: %s", attempt, MAX_REFRESH_RETRIES, exc)
            if attempt < MAX_REFRESH_RETRIES:
                time.sleep(RETRY_BACKOFF_SECONDS * attempt)

        except requests.exceptions.HTTPError as exc:
            last_exc = exc
            status = exc.response.status_code if exc.response is not None else 0
            if status in (401, 403, 500, 502, 503, 504) and attempt < MAX_REFRESH_RETRIES:
                logger.warning("HTTP %d on attempt %d/%d — retrying…", status, attempt, MAX_REFRESH_RETRIES)
                time.sleep(RETRY_BACKOFF_SECONDS * attempt)
            else:
                logger.error("Companion token fetch failed (HTTP %d) after %d attempt(s).", status, attempt)
                raise

        except Exception as exc:
            last_exc = exc
            logger.exception("Companion token fetch failed (non-retryable): %s", exc)
            raise

    raise last_exc


def refresh_ws_token() -> bool:
    """Run the full Companion login flow, persist the token to DB, and update os.environ.

    Kept for backward-compatibility: token_refresh_service.py calls this
    function directly for on-demand auth-failure recovery.

    Returns True on success, False on failure.
    """
    for attempt in range(1, MAX_REFRESH_RETRIES + 1):
        try:
            logger.info("=" * 50)
            logger.info("Starting Companion (WS) token refresh (attempt %d/%d)…", attempt, MAX_REFRESH_RETRIES)

            authtoken = _fetch_companion_token()
            _update_ws_token_in_db(authtoken)

            os.environ["COMPANION_TOKEN"] = authtoken
            logger.info("COMPANION_TOKEN env var updated (len=%d)", len(authtoken))
            logger.info("WS token refresh completed successfully ✓")
            logger.info("=" * 50)
            return True

        except (requests.ConnectionError, requests.Timeout) as exc:
            logger.warning("Network error on attempt %d/%d: %s", attempt, MAX_REFRESH_RETRIES, exc)
            if attempt < MAX_REFRESH_RETRIES:
                logger.info("Retrying in %d seconds…", RETRY_BACKOFF_SECONDS * attempt)
                time.sleep(RETRY_BACKOFF_SECONDS * attempt)
            else:
                logger.error("WS token refresh failed after %d attempts.", MAX_REFRESH_RETRIES)
                return False

        except requests.exceptions.HTTPError as exc:
            status = exc.response.status_code if exc.response is not None else 0
            if status in (401, 403, 500, 502, 503, 504) and attempt < MAX_REFRESH_RETRIES:
                logger.warning("HTTP %d on attempt %d/%d — retrying in %ds…", status, attempt, MAX_REFRESH_RETRIES, RETRY_BACKOFF_SECONDS * attempt)
                time.sleep(RETRY_BACKOFF_SECONDS * attempt)
            else:
                logger.error("WS token refresh failed (HTTP %d) after %d attempt(s).", status, attempt)
                return False

        except Exception as exc:
            logger.exception("WS token refresh failed (non-retryable): %s", exc)
            return False

    return False


# ---------------------------------------------------------------------------
# Standalone execution
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import sys

    if "--once" in sys.argv:
        success = refresh_ws_token()
        sys.exit(0 if success else 1)
    else:
        logger.info("Running one-shot Companion (WS) token refresh…")
        success = refresh_ws_token()
        sys.exit(0 if success else 1)
