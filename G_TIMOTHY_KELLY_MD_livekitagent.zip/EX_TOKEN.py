"""
CareCloud OAuth2 Token Refresh Service
---------------------------------------
Replicates the n8n workflow that:
1. Hits the CareCloud OAuth2 authorize endpoint (GET) to initiate login
2. POSTs credentials to retrieve an authorization code
3. Extracts the auth code from the response
4. Exchanges the auth code for an access_token
5. Updates TokenTable in the database with the new token
"""

import os
import re
import time
import base64
import logging
import requests
from dotenv import load_dotenv

# Reuse existing DB helpers
from db import execute_update, execute_query

load_dotenv()

# ---------------------------------------------------------------------------
# Configuration (override via environment variables)
# ---------------------------------------------------------------------------
CARECLOUD_API_KEY = os.getenv("CARECLOUD_API_KEY", "o_Ccakf7Oqdx37oigsRVO356fPWgHWT6")
CARECLOUD_SECRET_KEY = os.getenv("CARECLOUD_SECRET_KEY", "D3cOSJ-raqpNRRko")
CARECLOUD_USERNAME = os.getenv("CARECLOUD_USERNAME", "stratusai_gtk@carecloud.com")
CARECLOUD_PASSWORD = os.getenv("CARECLOUD_PASSWORD", "str@tus@Ai426*$")
CARECLOUD_PRACTICE_ID = os.getenv("CARECLOUD_PRACTICE_ID", "250e55a3-82a2-43a0-92e0-77fe0046c242")
CARECLOUD_REDIRECT_URI = os.getenv("CARECLOUD_REDIRECT_URI", "https://n8n.carecloud.com/rest/oauth2-credential/callback")
CARECLOUD_CLIENT_ID = os.getenv("CARECLOUD_CLIENT_ID", "o_Ccakf7Oqdx37oigsRVO356fPWgHWT6")
BUSINESS_ENTITY_ID = os.getenv("BUSINESS_ID", "4944")

AUTHORIZE_URL = "https://platform.carecloud.com/oauth2/authorize"
TOKEN_URL = "https://api.carecloud.com/oauth2/access_token"

# ---------------------------------------------------------------------------
# Logging  (use a dedicated logger — never call basicConfig here so we
# don't hijack the root logger when imported by agent.py)
# ---------------------------------------------------------------------------
logger = logging.getLogger("ex_token_refresh")
if not logger.handlers:
    _handler = logging.StreamHandler()
    _handler.setFormatter(logging.Formatter(
        "%(asctime)s [EX_TOKEN] %(levelname)s %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    ))
    logger.addHandler(_handler)
    logger.setLevel(logging.INFO)

# ---------------------------------------------------------------------------
# Core OAuth2 flow
# ---------------------------------------------------------------------------

def _get_login_page(session: requests.Session) -> requests.Response:
    """Step 1: GET the authorize page (captures cookies/session)."""
    params = {
        "client_id": CARECLOUD_CLIENT_ID,
        "response_type": "code",
        "redirect_uri": CARECLOUD_REDIRECT_URI,
        "practice_id": CARECLOUD_PRACTICE_ID,
        "state": "xyz",
    }
    resp = session.get(AUTHORIZE_URL, params=params, allow_redirects=True)
    resp.raise_for_status()
    logger.info("Step 1/4 — Login page fetched (status %s)", resp.status_code)
    return resp


def _submit_credentials(session: requests.Session) -> requests.Response:
    """Step 2: POST credentials to authorize endpoint to obtain auth code.

    Uses allow_redirects=False so we never actually hit the redirect_uri
    (removes runtime dependency on n8n being reachable).  The auth code
    is extracted from the 302 Location header instead.
    """
    data = {
        "client_id": CARECLOUD_CLIENT_ID,
        "response_type": "code",
        "redirect_uri": CARECLOUD_REDIRECT_URI,
        "practice_id": CARECLOUD_PRACTICE_ID,
        "decision": "Allow",
        "user_name": CARECLOUD_USERNAME,
        "password": CARECLOUD_PASSWORD,
    }
    resp = session.post(AUTHORIZE_URL, data=data, allow_redirects=False)
    # Accept 302 (redirect with code) or 200 (code in body)
    if resp.status_code not in (200, 301, 302, 303, 307, 308):
        resp.raise_for_status()
    logger.info("Step 2/4 — Credentials submitted (status %s)", resp.status_code)
    return resp


def _extract_auth_code(response: requests.Response) -> str:
    """Step 3: Extract the authorization code (UUID) from the response.

    Checks (in order):
    1. Location header (302 redirect — no n8n dependency)
    2. Response body JSON
    3. Final URL query params (if redirects were followed)
    """
    uuid_re = r'[a-f0-9-]{36}'

    # 1. Try the Location header first (most reliable when redirects are off)
    location = response.headers.get("Location", "")
    if location and "code=" in location:
        m = re.search(r'[?&]code=(' + uuid_re + r')', location, re.IGNORECASE)
        if m:
            code = m.group(1)
            logger.info("Step 3/4 — Auth code extracted from Location header: %s…%s", code[:8], code[-4:])
            return code

    # 2. Try the response body
    body = response.text
    decoded = body.replace("&quot;", '"').replace("&amp;", "&")
    match = re.search(r'"code"\s*:\s*"(' + uuid_re + r')"', decoded, re.IGNORECASE)
    if match:
        code = match.group(1)
        logger.info("Step 3/4 — Auth code extracted from body: %s…%s", code[:8], code[-4:])
        return code

    # 3. Fallback: check final URL query param
    if response.url and "code=" in response.url:
        url_match = re.search(r'[?&]code=(' + uuid_re + r')', response.url, re.IGNORECASE)
        if url_match:
            code = url_match.group(1)
            logger.info("Step 3/4 — Auth code extracted from redirect URL")
            return code

    raise ValueError(
        f"Could not extract authorization code "
        f"(status={response.status_code}, body_len={len(body)}, "
        f"location={location[:120] if location else 'N/A'}, url={response.url})"
    )


def _exchange_code_for_token(auth_code: str) -> str:
    """Step 4: Exchange the authorization code for an access_token."""
    credentials = f"{CARECLOUD_API_KEY}:{CARECLOUD_SECRET_KEY}"
    encoded = base64.b64encode(credentials.encode()).decode()

    headers = {
        "Authorization": f"Basic {encoded}",
        "Content-Type": "application/x-www-form-urlencoded",
    }
    payload = {
        "code": auth_code,
        "grant_type": "authorization_code",
        "redirect_uri": CARECLOUD_REDIRECT_URI,
    }

    resp = requests.post(TOKEN_URL, headers=headers, data=payload)
    resp.raise_for_status()
    data = resp.json()

    access_token = data.get("access_token")
    if not access_token:
        raise ValueError(f"No access_token in response: {data}")

    expires_in = data.get("expires_in")
    logger.info(
        "Step 4/4 — Access token obtained (length=%d, expires_in=%s)",
        len(access_token),
        expires_in if expires_in is not None else "N/A",
    )
    return access_token, expires_in


def _update_token_in_db(access_token: str) -> bool:
    """Write the new token to the TokenTable using a simple UPDATE.

    Uses pyodbc-compatible '?' placeholders (not MySQL '%s') and does not
    attempt a SELECT first — the row for business_entity 4944 always exists.
    """
    success = execute_update(
        "UPDATE TokenTable SET ex_auth_token = ? WHERE business_entity = ?",
        [access_token, BUSINESS_ENTITY_ID],
    )
    if success:
        logger.info("ex_auth_token stored in DB for business_entity=%s", BUSINESS_ENTITY_ID)
    else:
        logger.error("Failed to store ex_auth_token in DB for business_entity=%s", BUSINESS_ENTITY_ID)
    return success


MAX_REFRESH_RETRIES = 3
RETRY_BACKOFF_SECONDS = 5


def get_fresh_ex_token() -> str:
    """Run the full OAuth2 flow and return the new access_token string.

    Pure HTTP — no DB update, no os.environ side effects.
    TokenManager calls this and owns the update responsibility.

    Retries up to MAX_REFRESH_RETRIES times on transient network/HTTP errors.
    Raises the last exception on final failure so the caller can decide how
    to handle it.
    """
    last_exc: Exception | None = None
    for attempt in range(1, MAX_REFRESH_RETRIES + 1):
        try:
            logger.info("Starting CareCloud token fetch (attempt %d/%d)…", attempt, MAX_REFRESH_RETRIES)
            session = requests.Session()
            _get_login_page(session)
            code_response = _submit_credentials(session)
            auth_code = _extract_auth_code(code_response)
            access_token, _ = _exchange_code_for_token(auth_code)
            logger.info("CareCloud token fetched successfully (len=%d)", len(access_token))
            return access_token

        except (requests.ConnectionError, requests.Timeout) as exc:
            last_exc = exc
            logger.warning("Network error on attempt %d/%d: %s", attempt, MAX_REFRESH_RETRIES, exc)
            if attempt < MAX_REFRESH_RETRIES:
                time.sleep(RETRY_BACKOFF_SECONDS * attempt)

        except requests.exceptions.HTTPError as exc:
            last_exc = exc
            status = exc.response.status_code if exc.response is not None else 0
            if status in (401, 403, 500, 502, 503, 504) and attempt < MAX_REFRESH_RETRIES:
                logger.warning("HTTP %d on attempt %d/%d — retrying…", status, attempt, MAX_REFRESH_RETRIES)
                time.sleep(RETRY_BACKOFF_SECONDS * attempt)
            else:
                logger.error("CareCloud token fetch failed (HTTP %d) after %d attempt(s).", status, attempt)
                raise

        except Exception as exc:
            last_exc = exc
            logger.exception("CareCloud token fetch failed (non-retryable): %s", exc)
            raise

    raise last_exc


def refresh_token() -> bool:
    """Run the full OAuth2 flow, persist the token to DB, and update os.environ.

    Kept for backward-compatibility: token_refresh_service.py calls this
    function directly for on-demand auth-failure recovery.

    Returns True on success, False on failure.
    """
    for attempt in range(1, MAX_REFRESH_RETRIES + 1):
        try:
            logger.info("=" * 50)
            logger.info("Starting CareCloud token refresh (attempt %d/%d)…", attempt, MAX_REFRESH_RETRIES)
            session = requests.Session()

            _get_login_page(session)
            code_response = _submit_credentials(session)
            auth_code = _extract_auth_code(code_response)
            access_token, expires_in = _exchange_code_for_token(auth_code)

            _update_token_in_db(access_token)

            os.environ["CARECLOUD_BEARER_TOKEN"] = access_token
            os.environ["CARECLOUD_TOKEN_REFRESHED_AT"] = str(time.time())
            os.environ["CARECLOUD_TOKEN_EXPIRES_IN"] = str(int(expires_in) if expires_in else 28800)
            logger.info(
                "CARECLOUD_BEARER_TOKEN env var updated (len=%d, expires_in=%s)",
                len(access_token), expires_in,
            )
            logger.info("Token refresh completed successfully ✓")
            logger.info("=" * 50)
            return True

        except (requests.ConnectionError, requests.Timeout) as exc:
            logger.warning("Network error on attempt %d/%d: %s", attempt, MAX_REFRESH_RETRIES, exc)
            if attempt < MAX_REFRESH_RETRIES:
                logger.info("Retrying in %d seconds…", RETRY_BACKOFF_SECONDS * attempt)
                time.sleep(RETRY_BACKOFF_SECONDS * attempt)
            else:
                logger.error("Token refresh failed after %d attempts.", MAX_REFRESH_RETRIES)
                return False

        except requests.exceptions.HTTPError as exc:
            status = exc.response.status_code if exc.response is not None else 0
            if status in (401, 403, 500, 502, 503, 504) and attempt < MAX_REFRESH_RETRIES:
                logger.warning("HTTP %d on attempt %d/%d — retrying in %ds…", status, attempt, MAX_REFRESH_RETRIES, RETRY_BACKOFF_SECONDS * attempt)
                time.sleep(RETRY_BACKOFF_SECONDS * attempt)
            else:
                logger.error("Token refresh failed (HTTP %d) after %d attempt(s).", status, attempt)
                return False

        except Exception as exc:
            logger.exception("Token refresh failed (non-retryable): %s", exc)
            return False

    return False


# ---------------------------------------------------------------------------
# Standalone execution
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import sys

    if "--once" in sys.argv:
        success = refresh_token()
        sys.exit(0 if success else 1)
    else:
        # Single immediate refresh and exit
        logger.info("Running one-shot CareCloud token refresh…")
        success = refresh_token()
        sys.exit(0 if success else 1)
