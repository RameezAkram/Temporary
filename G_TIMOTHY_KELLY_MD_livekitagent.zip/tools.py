from livekit.agents import function_tool, RunContext
import json
import re
from typing import Optional
from custom_template import get_location_resource_types_with_visits
from provider_schedules import (
    get_provider_schedule_text,
    get_provider_schedule_for_location,
    get_all_schedules_summary,
    LOCATION_NAMES,
)
from Knowledge_base import fuzzy_match_payer as _fuzzy_match_payer, fuzzy_match_insurance_policy_type as _fuzzy_match_insurance_policy_type

# ===============================
# VALIDATION HELPER FUNCTIONS
# ===============================

def validate_and_fix_patient_data(patient_data):
    """Auto-fix patient data formats before MCP tool calls."""
    fixed_data = {}

    # Date format: Add timezone if missing AND create comma-separated string format
    if 'date_of_birth' in patient_data:
        dob = patient_data['date_of_birth']
        fixed_data['date_of_birth'] = f"{dob}T12:00:00-05:00" if 'T' not in dob else dob
        date_part = dob.split('T')[0] if 'T' in dob else dob
        fixed_data['date_of_birth_string'] = date_part.replace('-', ',')

    # Gender: Convert to single letter
    if 'gender_code' in patient_data:
        gender = patient_data['gender_code'].lower()
        fixed_data['gender_code'] = 'M' if gender in ['male', 'm'] else 'F' if gender in ['female', 'f'] else gender

    # State: Abbreviation to full name
    state_mapping = {
        'AL': 'Alabama', 'AK': 'Alaska', 'AZ': 'Arizona', 'AR': 'Arkansas', 'CA': 'California',
        'CO': 'Colorado', 'CT': 'Connecticut', 'DE': 'Delaware', 'FL': 'Florida', 'GA': 'Georgia',
        'HI': 'Hawaii', 'ID': 'Idaho', 'IL': 'Illinois', 'IN': 'Indiana', 'IA': 'Iowa',
        'KS': 'Kansas', 'KY': 'Kentucky', 'LA': 'Louisiana', 'ME': 'Maine', 'MD': 'Maryland',
        'MA': 'Massachusetts', 'MI': 'Michigan', 'MN': 'Minnesota', 'MS': 'Mississippi', 'MO': 'Missouri',
        'MT': 'Montana', 'NE': 'Nebraska', 'NV': 'Nevada', 'NH': 'New Hampshire', 'NJ': 'New Jersey',
        'NM': 'New Mexico', 'NY': 'New York', 'NC': 'North Carolina', 'ND': 'North Dakota', 'OH': 'Ohio',
        'OK': 'Oklahoma', 'OR': 'Oregon', 'PA': 'Pennsylvania', 'RI': 'Rhode Island', 'SC': 'South Carolina',
        'SD': 'South Dakota', 'TN': 'Tennessee', 'TX': 'Texas', 'UT': 'Utah', 'VT': 'Vermont',
        'VA': 'Virginia', 'WA': 'Washington', 'WV': 'West Virginia', 'WI': 'Wisconsin', 'WY': 'Wyoming'
    }
    if 'state' in patient_data:
        state = patient_data['state'].upper()
        fixed_data['state'] = state_mapping.get(state, patient_data['state'])

    fixed_data['country_name'] = 'UNITED STATES'

    # Phone: Remove formatting, keep digits only
    if 'phone_number' in patient_data:
        phone = re.sub(r'[^\d]', '', patient_data['phone_number'])
        if len(phone) == 11 and phone.startswith('1'):
            phone = phone[1:]
        fixed_data['phone_number'] = phone

    # Copy other fields
    for field in ['first_name', 'last_name', 'line1', 'city', 'zip_code', 'email']:
        if field in patient_data:
            fixed_data[field] = patient_data[field]

    return fixed_data


# Load business entity data
def load_business_data():
    """Load business data from data.txt"""
    try:
        with open("data.txt", "r") as f:
            return json.load(f)
    except Exception as e:
        print(f"❌ Error loading data.txt: {e}")
        return None

@function_tool
async def get_location_resources(
    location_id: int,
    visit_reason_id: Optional[int] = None
) -> str:
    """
    Get available resources (doctors/providers) at a specific location.
    Optionally filter by visit reason (appointment type).
    
    First call get_available_locations() to retrieve location IDs and names,
    then use the location_id from that response.
    
    Args:
        location_id: The numeric ID of the specific location (required).
                    Call get_available_locations() first to get valid location IDs.
                    Example: 29414 for MAIN OFFICE
        visit_reason_id: (Optional) Filter resources by visit reason/appointment type ID
        
    Returns:
        JSON string with default and alternative resources available at the location,
        including resource names and associated providers. If no resources found,
        includes list of available locations to help choose the correct one.
    """
    try:
        # Load fresh data from data.txt
        business_data = load_business_data()
        if not business_data:
            error_response = {
                "success": False,
                "error": "Could not load business entity data"
            }
            print(f"❌ ERROR: {error_response}")
            return json.dumps(error_response)
        
        print(f"\n{'='*60}")
        print(f"🔍 get_location_resources CALLED")
        print(f"   📍 location_id: {location_id}")
        print(f"   🎯 visit_reason_id: {visit_reason_id}")
        print(f"{'='*60}")
        
        print(f"✅ Business data loaded successfully")
        
        # Get list of available locations for reference
        available_locations = [
            {"id": loc["id"], "name": loc.get("name", "Unknown")}
            for loc in business_data.get("locations", [])
        ]
        
        # Check if location_id matches business_entity_id (common mistake)
        business_entity_id = int(business_data.get("business_entity_id", 0))
        if location_id == business_entity_id:
            warning_msg = (
                f"⚠️  WARNING: location_id ({location_id}) matches business_entity_id. "
                f"This is likely incorrect. Available locations are: {available_locations}"
            )
            print(f"\n{warning_msg}")
            
            error_response = {
                "success": False,
                "error": "Invalid location_id: you provided the business_entity_id instead of an actual location ID",
                "business_entity_id": business_entity_id,
                "available_locations": available_locations,
                "hint": "Please use one of the location IDs from the available_locations list"
            }
            print(f"\n❌ RESPONSE: {json.dumps(error_response, indent=2)}")
            print(f"{'='*60}\n")
            return json.dumps(error_response)
        
        # Call the core function
        result = get_location_resource_types_with_visits(
            business_data,
            location_id,
            visit_reason_id
        )
        
        # Check if no resources found and provide helpful info
        has_resources = (len(result.get('default_resources', [])) > 0 or 
                        len(result.get('alternative_resources', [])) > 0)
        
        # Attach schedule info for each resource found
        def _enrich_resources(resources_list):
            for res in resources_list:
                rid = res.get('resource_id')
                if rid:
                    res['schedule_at_location'] = get_provider_schedule_for_location(rid, location_id)
                    res['full_schedule'] = get_provider_schedule_text(rid)
            return resources_list

        _enrich_resources(result.get('default_resources', []))
        _enrich_resources(result.get('alternative_resources', []))

        response = {
            "success": True,
            "data": result
        }
        
        # Check if no resources found and provide helpful info
        has_resources = (len(result.get('default_resources', [])) > 0 or 
                        len(result.get('alternative_resources', [])) > 0)
        
        # If no resources found, include available locations to help
        if not has_resources:
            response["available_locations"] = available_locations
            response["warning"] = (
                f"No resources/providers are configured for location_id {location_id}. "
                f"This location exists but has no resources assigned in CareCloud. "
                f"Please check available_locations for locations that have resources configured."
            )
            print(f"\n   ⚠️  WARNING: No resources found for location_id {location_id}")
            print(f"   💡 This location exists but may not be configured with resources yet")
        
        print(f"\n📊 RESPONSE:")
        print(f"   - Location ID: {result.get('location_id')}")
        print(f"   - Default Resources: {len(result.get('default_resources', []))}")
        print(f"   - Alternative Resources: {len(result.get('alternative_resources', []))}")
        if not has_resources:
            print(f"   - Available Locations: {available_locations}")
        
        if result.get('default_resources'):
            print(f"\n   📌 Default Resources:")
            for res in result.get('default_resources', []):
                print(f"      • {res.get('resource_name')} (ID: {res.get('resource_id')})")
                for prov in res.get('providers', []):
                    print(f"        - Provider: {prov.get('name')} (ID: {prov.get('id')})")
        
        if result.get('alternative_resources'):
            print(f"\n   🔄 Alternative Resources:")
            for res in result.get('alternative_resources', []):
                print(f"      • {res.get('resource_name')} (ID: {res.get('resource_id')})")
                for prov in res.get('providers', []):
                    print(f"        - Provider: {prov.get('name')} (ID: {prov.get('id')})")
        
        print(f"{'='*60}\n")
        
        return json.dumps(response, indent=2)
        
    except Exception as e:
        error_response = {
            "success": False,
            "error": str(e)
        }
        print(f"❌ ERROR in get_location_resources: {error_response}")
        print(f"{'='*60}\n")
        return json.dumps(error_response)

@function_tool
async def get_provider_schedule(
    resource_id: Optional[int] = None,
    location_id: Optional[int] = None
) -> str:
    """
    Get the working schedule of a provider (doctor).
    If resource_id is provided, returns that provider's schedule.
    If location_id is also provided, returns the provider's schedule at that specific location.
    If no resource_id is given, returns schedules for ALL providers.

    Args:
        resource_id: (Optional) The scheduling resource ID
                     (24133 = DR. KELLY OB / DR. GEORGE T KELLY MD,
                      25784 = ELISE CALL / ELISE K CALL)
        location_id: (Optional) Filter schedule to a specific location (29414 = Main Office)

    Returns:
        Human-readable schedule description for the provider at the given location.
    """
    try:
        print(f"\n{'='*60}")
        print(f"📅 get_provider_schedule CALLED")
        print(f"   resource_id: {resource_id}")
        print(f"   location_id: {location_id}")
        print(f"{'='*60}")

        if resource_id is None:
            # Return all schedules
            result = get_all_schedules_summary()
        elif location_id is not None:
            result = get_provider_schedule_for_location(resource_id, location_id)
        else:
            result = get_provider_schedule_text(resource_id)

        print(f"📋 Result:\n{result}")
        print(f"{'='*60}\n")
        return result
    except Exception as e:
        error_msg = f"Error getting schedule: {str(e)}"
        print(f"❌ {error_msg}")
        return error_msg


@function_tool
async def get_available_locations() -> str:
    """
    Get available locations for booking appointments.
    
    BUSINESS RULE: Only MAIN OFFICE is available for appointments.
    Returns location details including ID, name, address, and resource count.
    
    Returns:
        JSON string with MAIN OFFICE location details (ID: 29414).
    """
    try:
        print(f"\n{'='*60}")
        print(f"📍 get_available_locations CALLED")
        print(f"{'='*60}")
        
        # Load business data
        business_data = load_business_data()
        if not business_data:
            error_response = {
                "success": False,
                "error": "Could not load business entity data"
            }
            return json.dumps(error_response)
        
        locations = business_data.get("locations", [])
        business_entity_id = business_data.get("business_entity_id")
        
        # Extract key location information - ONLY locations with resources
        # BUSINESS RULE: Only return MAIN OFFICE location
        location_list = []
        skipped_locations = []
        
        for loc in locations:
            location_id = loc.get("id")
            location_name = loc.get("name")
            location_resources = loc.get("location_resources", [])
            
            # FILTER 1: Only include locations that have at least one resource configured
            if not location_resources or len(location_resources) == 0:
                skipped_locations.append(f"{location_name} (ID: {location_id}) - No resources configured")
                continue
            
            # FILTER 2: ONLY allow MAIN OFFICE (ID: 29414)
            if location_id != 29414:
                skipped_locations.append(f"{location_name} (ID: {location_id}) - Not MAIN OFFICE")
                continue
            
            location_list.append({
                "id": location_id,
                "name": location_name,
                "mnemonic": loc.get("mnemonic"),
                "is_default": loc.get("is_default", False),
                "status": loc.get("status"),
                "resource_count": len(location_resources),
                "address": {
                    "line1": loc.get("address", {}).get("address", {}).get("line1"),
                    "city": loc.get("address", {}).get("address", {}).get("city"),
                    "state": loc.get("address", {}).get("address", {}).get("state_id"),
                    "zip": loc.get("address", {}).get("address", {}).get("zip_code")
                } if loc.get("address") else None
            })
        
        response = {
            "success": True,
            "business_entity_id": business_entity_id,
            "total_available_locations": len(location_list),
            "locations": location_list,
            "note": "BUSINESS RULE: Only MAIN OFFICE location is available for appointments. Telehealth and other locations are excluded."
        }
        
        print(f"\n📊 RESPONSE:")
        for loc in location_list:
            print(f"   \u2705 {loc['name']} (ID: {loc['id']})")
        print(f"{'='*60}\n")
        
        return json.dumps(response, indent=2)
        
    except Exception as e:
        error_response = {
            "success": False,
            "error": str(e)
        }
        print(f"❌ ERROR in get_available_locations: {error_response}")
        print(f"{'='*60}\n")
        return json.dumps(error_response)


@function_tool
async def lookup_payer(insurance_name: str) -> str:
    """
    Look up an insurance payer by name from the payer knowledge base using fuzzy matching.
    ALWAYS call this tool immediately after the patient provides their insurance company name.
    Returns the matched payer's id, name, address (line1, city, zip), and phone number.
    Use the returned values directly as parameters when calling create_insurance.

    Args:
        insurance_name: The insurance company name as provided by the patient.

    Returns:
        JSON with matched payer details (id, name, line1, city, zip_code, payer_phone_number)
        or an error message if no match is found.
    """
    result = _fuzzy_match_payer(insurance_name)
    if result:
        addr = result.get('address', {})
        return json.dumps({
            'found': True,
            'payer_id':           result['id'],
            'payer_name':         result['name'],
            'line1':              addr.get('line1', ''),
            'city':               addr.get('city', ''),
            'zip_code':           addr.get('zip', ''),
            'payer_phone_number': result.get('phone', ''),
            'match_score':        result.get('score', 0),
        })
    return json.dumps({'found': False, 'message': f'No payer match found for "{insurance_name}". Ask the patient to spell it out or provide the full name.'})


@function_tool
async def lookup_insurance_policy_type(policy_type_name: str) -> str:
    """
    Look up an insurance policy type by name or code from the knowledge base using fuzzy matching.
    ALWAYS call this tool immediately after the patient provides their policy type (e.g. HMO, PPO, Medicare).
    Returns the matched policy type's id, name, and code.
    Use the returned values directly as parameters when calling create_insurance.

    Args:
        policy_type_name: The policy type name or code as provided by the patient (e.g. "PPO", "HMO", "Medicare").

    Returns:
        JSON with matched policy type details (insurance_policy_type_id, insurance_policy_type_name, insurance_policy_type_code)
        or an error message if no match is found.
    """
    result = _fuzzy_match_insurance_policy_type(policy_type_name)
    if result:
        return json.dumps({
            'found': True,
            'insurance_policy_type_id':   result['id'],
            'insurance_policy_type_name': result['name'],
            'insurance_policy_type_code': result['code'],
            'match_score':                result.get('score', 0),
        })
    return json.dumps({'found': False, 'message': f'No policy type match found for "{policy_type_name}". Ask the patient to clarify (e.g. HMO, PPO, Medicare, Medicaid).'})