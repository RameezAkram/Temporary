"""
LangGraph Booking Logic Layer for G. Timothy Kelly MD Appointment Agent.

Manages stateful, multi-step appointment booking workflows:
  - Check availability → Select slot → Create appointment → Confirm
  - Cancel → Verify → Execute → Confirm
  - Reschedule → Cancel old → Book new
  - Automatic retry with fallback dates when slots unavailable

Architecture:
    LiveKit (voice) → OpenAI Realtime (LLM) → LangGraph (booking brain) → MCP (API)

    LiveKit handles the voice. LangGraph handles the brain logic.
"""

from __future__ import annotations

import json
import logging
import os
import asyncio
from typing import TypedDict, Optional, List, Dict, Any
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

from langgraph.graph import StateGraph, START, END
from langsmith import traceable
from mcp_client.agent_tools import _convert_slots_to_pacific, _pacific_to_original_slot

logger = logging.getLogger("booking-graph")


# ─── Booking Workflow State ──────────────────────────────────────────────────

class BookingState(TypedDict, total=False):
    """Persistent state across the booking workflow for a single call session."""

    # Patient identification
    patient_id: str
    patient_external_id: str
    patient_name: str
    is_new_patient: bool

    # Caller intent: schedule | cancel | reschedule | view
    intent: str

    # Provider & location context
    location_id: str
    provider_id: str
    resource_id: str
    nature_of_visit_id: str
    reason_for_visit: str

    # Scheduling context
    requested_date: str             # YYYY-MM-DD
    available_slots: list           # Slots returned by Available_time_slots
    selected_slot: dict             # Slot user chose

    # Existing appointment (for cancel / reschedule)
    appointment_id: str
    existing_appointments: list     # From get_appointments_list

    # API results
    booking_result: dict
    cancel_result: dict

    # Control flow
    retry_count: int
    max_retries: int
    status: str                     # pending | checking | slots_found | no_slots |
    #                                 booked | cancelled | failed | transferred
    error: str
    response_message: str           # Message for voice agent to speak to patient
    action_required: str            # What the voice agent should do next
    action_data: dict               # Supporting data for the action


# ─── MCP Tool Caller ─────────────────────────────────────────────────────────

class MCPToolCaller:
    """
    Wraps the MCP server to call tools with proper token injection.
    Injected into the BookingWorkflow at call start.
    """

    def __init__(self, mcp_server):
        self.server = mcp_server

    async def call(self, tool_name: str, arguments: Dict[str, Any]) -> str:
        """Call an MCP tool with automatic reconnect on connection failures."""
        # Don't mutate original
        arguments = dict(arguments)
        self._inject_tokens(tool_name, arguments)

        logger.info(f"[BOOKING_GRAPH] Calling MCP tool: {tool_name}")

        _CONN_ERROR_TYPES = {
            'ClosedResourceError', 'ConnectionError', 'TimeoutError',
            'RemoteProtocolError', 'ReadError', 'WriteError',
            'ConnectError', 'PoolTimeout', 'BrokenResourceError', 'RuntimeError',
        }

        for attempt in range(2):
            try:
                # Reconnect if the SSE session has gone stale
                if not getattr(self.server, 'connected', False) or self.server.session is None:
                    logger.warning(
                        f"[BOOKING_GRAPH] Server disconnected — reconnecting before '{tool_name}' "
                        f"(attempt {attempt + 1}/2)"
                    )
                    await self.server.cleanup()
                    await asyncio.sleep(0.5)
                    await self.server.connect()
                    logger.info("[BOOKING_GRAPH] Reconnected successfully")

                result = await self.server.call_tool(tool_name, arguments)
                return self._extract_text(result)

            except Exception as e:
                error_type = type(e).__name__
                if error_type in _CONN_ERROR_TYPES and attempt == 0:
                    logger.warning(
                        f"[BOOKING_GRAPH] Connection error on attempt 1 for '{tool_name}' "
                        f"({error_type}: {e}) — reconnecting and retrying"
                    )
                    try:
                        await self.server.cleanup()
                        await asyncio.sleep(0.5)
                        await self.server.connect()
                        logger.info("[BOOKING_GRAPH] Reconnected OK, retrying")
                        continue
                    except Exception as re_err:
                        logger.error(f"[BOOKING_GRAPH] Reconnect failed: {re_err}")
                        raise e from re_err

                logger.error(f"[BOOKING_GRAPH] MCP tool '{tool_name}' failed: {error_type}: {e}")
                raise

        # Should never reach here
        raise RuntimeError(f"[BOOKING_GRAPH] Failed to call '{tool_name}' after 2 attempts")

    @staticmethod
    def _inject_tokens(tool_name: str, args: Dict[str, Any]) -> None:
        """Inject the correct auth token based on tool type."""
        carecloud_tools = [
            "Appoitment_template", "Blockout",
            "get_appointments_list", "get_provider_appointments",
            "Visit_Reasons",
        ]
        if tool_name in carecloud_tools:
            token = os.environ.get("CARECLOUD_BEARER_TOKEN", "")
        else:
            token = os.environ.get("COMPANION_TOKEN", "")
        if token:
            args["web_token"] = token

    @staticmethod
    def _extract_text(result) -> str:
        """Extract text from CallToolResult."""
        if result is None:
            return ""
        if hasattr(result, "content") and result.content:
            parts = []
            for item in result.content:
                if hasattr(item, "text"):
                    parts.append(item.text)
            return "\n".join(parts) if parts else str(result)
        if hasattr(result, "text"):
            return result.text
        return str(result)


# ─── Helper Functions ─────────────────────────────────────────────────────────

def _parse_json(text: str) -> Any:
    """Parse JSON text, returning parsed object or original text on failure."""
    try:
        return json.loads(text)
    except Exception:
        return text


def _parse_slots(result_text: str) -> List[Dict[str, Any]]:
    """Extract appointment slots from Available_time_slots response."""
    parsed = _parse_json(result_text)
    
    # Handle different response formats
    if isinstance(parsed, list):
        # Case A: list of availability groups — [{"slots": [...], ...}, ...]
        all_slots = []
        for group in parsed:
            if isinstance(group, dict) and "slots" in group:
                all_slots.extend(group["slots"])
        # Case B: bare list of slot objects — [{"start_time": ..., "end_time": ...}, ...]
        if not all_slots and parsed and isinstance(parsed[0], dict) and "start_time" in parsed[0]:
            all_slots = parsed
        return all_slots

    elif isinstance(parsed, dict):
        # Case C: single dict with a "slots" key
        if "slots" in parsed:
            return parsed["slots"]
        # Case D: the dict itself is a single slot
        if "start_time" in parsed and "end_time" in parsed:
            return [parsed]
        # Case E: other wrapping keys the API might use
        for key in ("availability", "available_slots", "appointments", "data", "results"):
            if key in parsed and isinstance(parsed[key], list):
                return parsed[key]
        # Log the actual keys so we can diagnose the real structure
        logger.warning(
            "[BOOKING_GRAPH] Unexpected slot response dict keys: %s — content: %s",
            list(parsed.keys()),
            result_text[:200],
        )
    
    return []


def _parse_appointments(result_text: str) -> List[Dict[str, Any]]:
    """Extract appointment list from get_appointments_list response."""
    parsed = _parse_json(result_text)
    
    if isinstance(parsed, list):
        return parsed
    elif isinstance(parsed, dict):
        # Check for common response wrapper keys
        for key in ["appointments", "data", "results"]:
            if key in parsed and isinstance(parsed[key], list):
                return parsed[key]
    
    logger.warning(f"[BOOKING_GRAPH] Could not parse appointments from: {result_text[:200]}")
    return []


def _is_booking_success(parsed: Any, raw_text: str) -> bool:
    """Check if create_appointment response indicates success."""
    # Success indicators:
    # 1. Response contains appointment object with id
    if isinstance(parsed, dict):
        if parsed.get("id") or parsed.get("appointment_id"):
            return True
        # Check for explicit success status
        if parsed.get("success") is True:
            return True
    
    # 2. Raw text contains success keywords
    lower = raw_text.lower()
    success_keywords = ["success", "created", "booked", "confirmed"]
    error_keywords = ["error", "failed", "invalid", "unauthorized"]
    
    has_success = any(kw in lower for kw in success_keywords)
    has_error = any(kw in lower for kw in error_keywords)
    
    return has_success and not has_error


def _extract_blockout_occurrences(
    blockout_response: str,
    location_id: str,
    resource_id: str
) -> List[Dict[str, str]]:
    """
    Parse blockout response and extract blockout occurrence windows.
    Returns list of {start_time, end_time} dicts in ISO format.
    """
    try:
        parsed = _parse_json(blockout_response)
        occurrences = []
        
        if isinstance(parsed, list):
            for blockout in parsed:
                if isinstance(blockout, dict):
                    # Extract blockout_occurrences array
                    for occ in blockout.get("blockout_occurrences", []):
                        start = occ.get("start_time")
                        end = occ.get("end_time")
                        if start and end:
                            occurrences.append({"start_time": start, "end_time": end})
        
        return occurrences
    except Exception as e:
        logger.warning(f"[BOOKING_GRAPH] Blockout parsing failed: {e}")
        return []


def _filter_blockout_slots(
    slots: List[Dict[str, Any]],
    blockouts: List[Dict[str, str]]
) -> List[Dict[str, Any]]:
    """
    Remove slots that overlap with blockout windows.
    A slot overlaps if its start OR end time falls inside a blockout window.
    """
    if not blockouts:
        return slots
    
    filtered = []
    for slot in slots:
        slot_start = slot.get("start_time", "")
        slot_end = slot.get("end_time", "")
        
        if not slot_start or not slot_end:
            filtered.append(slot)
            continue
        
        # Check if slot overlaps with any blockout
        overlaps = False
        for blockout in blockouts:
            b_start = blockout["start_time"]
            b_end = blockout["end_time"]
            
            # Overlap detection: slot starts before blockout ends AND slot ends after blockout starts
            if slot_start < b_end and slot_end > b_start:
                overlaps = True
                break
        
        if not overlaps:
            filtered.append(slot)
    
    return filtered


# ─── Node Functions ──────────────────────────────────────────────────────────
# Each node receives state and returns a partial state update dict.
# Async nodes call MCP tools through the injected caller.

def _build_nodes(mcp_caller: MCPToolCaller):
    """
    Build node functions with the MCP caller bound via closure.
    Returns a dict of {node_name: async_function}.
    """

    async def check_availability(state: BookingState) -> dict:
        """Check available appointment slots with full date validation and blockout filtering."""
        resource_id = str(state.get("resource_id", "") or "")
        location_id = str(state.get("location_id", "") or "")
        date = str(state.get("requested_date", "") or "")
        nature_of_visit_id = str(state.get("nature_of_visit_id", "") or "")

        RESOURCE_ELISE = "25784"  # ELISE CALL — Thu/Fri only

        try:
            pacific = ZoneInfo("America/Los_Angeles")
            now = datetime.now(pacific)
            today_str = now.strftime("%Y-%m-%d")
            logger.info(f"[BOOKING_GRAPH] check_availability: date={date!r} resource={resource_id!r}")

            # ── default to today ──────────────────────────────────────────
            if not date:
                date = today_str

            # ── PAST DATE GATE ────────────────────────────────────────────
            if date < today_str:
                return {
                    "requested_date": date,
                    "available_slots": [],
                    "status": "past_date",
                    "error": f"Requested date {date} is in the past.",
                    "response_message": (
                        f"That date has already passed. I cannot book appointments in the past. "
                        f"Today is {datetime.now(pacific).strftime('%B %d, %Y')}. "
                        f"Please provide today's date or any future date."
                    ),
                    "action_required": "ask_for_future_date",
                }

            # ── WEEKEND GATE ──────────────────────────────────────────────
            req_dt = datetime.strptime(date, "%Y-%m-%d")
            wday = req_dt.weekday()  # 0=Mon … 6=Sun
            if wday >= 5:  # Sat=5, Sun=6
                days_to_mon = 7 - wday
                req_dt = req_dt + timedelta(days=days_to_mon)
                date = req_dt.strftime("%Y-%m-%d")
                wday = req_dt.weekday()
                logger.info(f"[BOOKING_GRAPH] WEEKEND GATE: redirected to {date} (Monday)")

            # ── ELISE CALL SCHEDULE GATE (Thu/Fri only) ───────────────────
            if resource_id == RESOURCE_ELISE and wday not in (3, 4):
                days_to_thu = (3 - wday) % 7 or 7
                days_to_fri = (4 - wday) % 7 or 7
                req_dt = req_dt + timedelta(days=min(days_to_thu, days_to_fri))
                # Ensure the redirect is never a weekend (shouldn't happen, but safe)
                while req_dt.weekday() >= 5:
                    req_dt += timedelta(days=1)
                date = req_dt.strftime("%Y-%m-%d")
                wday = req_dt.weekday()
                logger.info(f"[BOOKING_GRAPH] ELISE GATE: redirected to {date} ({req_dt.strftime('%A')})")

            # ── STEP 1: Fetch Blockout for this exact date ────────────────
            blockout_occurrences = []
            try:
                blockout_response = await mcp_caller.call("Blockout", {
                    "location_id": location_id,
                    "resource_id": resource_id,
                    "start_date": date,
                    "end_date": date,
                })
                blockout_occurrences = _extract_blockout_occurrences(
                    blockout_response, location_id, resource_id
                )
                logger.info(f"[BOOKING_GRAPH] Blockout: {len(blockout_occurrences)} occurrence(s) on {date}")
            except Exception as e:
                logger.warning(f"[BOOKING_GRAPH] Blockout fetch failed (non-blocking): {e}")

            # ── STEP 2: Fetch Available_time_slots for this exact date ────
            # Using a single-day window (end_date = start_date) so the result
            # only contains slots for the requested day. The retry/suggest_alternative
            # mechanism advances one business day at a time when a day has no slots.
            provider_id = str(state.get("provider_id", "") or "")
            business_id = os.environ.get("BUSINESS_ID", "4944")

            avail_params = {
                "resource_ids": resource_id,
                "location_ids": location_id,
                "start_date": date,
                "end_date": date,
                "nature_of_visit_id": nature_of_visit_id,
                "business_entity_id": business_id,
            }
            if provider_id:
                avail_params["provider_id"] = provider_id

            # NOTE: The MCP server tool is named "Available time slots" (with a space).
            # The sanitized name "Available_time_slots" is only for OpenAI; server.call_tool
            # must receive the original name.
            result_text = await mcp_caller.call("Available time slots", avail_params)

            # Convert to Pacific Time and populate _pacific_to_original_slot for
            # TZ restoration in book_appointment → create_appointment.
            result_text = _convert_slots_to_pacific(result_text)
            slots = _parse_slots(result_text)

            # Remove slots that overlap with blockout windows
            if slots and blockout_occurrences:
                pre_filter = len(slots)
                slots = _filter_blockout_slots(slots, blockout_occurrences)
                removed = pre_filter - len(slots)
                if removed:
                    logger.info(f"[BOOKING_GRAPH] Removed {removed} blockout-overlapping slot(s)")

            if slots:
                return {
                    "requested_date": date,  # carry back any redirected date
                    "available_slots": slots,
                    "status": "slots_found",
                    "response_message": f"I found {len(slots)} available time slot(s) for {date}.",
                    "action_required": "present_slots",
                    "action_data": {"slots": slots, "date": date},
                }

            retry = state.get("retry_count", 0)
            max_r = state.get("max_retries", 3)
            if retry >= max_r:
                return {
                    "requested_date": date,
                    "available_slots": [],
                    "status": "no_slots",
                    "response_message": (
                        f"I was not able to find any available appointments near {date}. "
                        "Would you like to try a different date or a different provider?"
                    ),
                    "action_required": "ask_alternative_date",
                }
            return {
                "requested_date": date,
                "available_slots": [],
                "status": "no_slots",
                "response_message": f"I don't see any availability for {date}.",
                "action_required": "suggest_alternative",
            }
        except Exception as e:
            error_type = type(e).__name__
            logger.error(f"[BOOKING_GRAPH] check_availability error ({error_type}): {e}")
            return {
                "available_slots": [],
                "status": "error",
                "error": f"{error_type}: {e}",
                "response_message": (
                    "I\u2019m having trouble checking availability right now. "
                    "Let me connect you with the office."
                ),
                "action_required": "transfer",
            }

    async def create_appointment(state: BookingState) -> dict:
        """Create appointment via MCP."""
        slot = state.get("selected_slot", {})
        business_id = os.environ.get("BUSINESS_ID", "4944")

        # Known resource → provider mappings for this practice
        RESOURCE_TO_PROVIDER = {
            "24133": "24506",  # DR. KELLY OB  → DR. GEORGE T KELLY MD
            "24132": "24506",  # DR. KELLY     → DR. GEORGE T KELLY MD
            "25784": "26123",  # ELISE CALL    → ELISE K CALL
        }

        # Ensure all ID fields are strings (LLM may send ints, None, or omit them)
        resource_id  = str(state.get("resource_id",  "") or "")
        location_id  = str(state.get("location_id",  "") or "")
        patient_id   = str(state.get("patient_id",   "") or "")
        nature_id    = str(state.get("nature_of_visit_id", "") or "")
        reason       = str(state.get("reason_for_visit",   "") or "")

        # Derive provider_id from resource_id when not explicitly set
        provider_id = str(state.get("provider_id", "") or "")
        if not provider_id and resource_id in RESOURCE_TO_PROVIDER:
            provider_id = RESOURCE_TO_PROVIDER[resource_id]
            logger.info(f"[BOOKING_GRAPH] Derived provider_id={provider_id} from resource_id={resource_id}")

        try:
            result_text = await mcp_caller.call("create_appointment", {
                "patient_id":        patient_id,
                "resource_id":       resource_id,
                "location_id":       location_id,
                "provider_id":       provider_id,
                "nature_of_visit_id": nature_id,
                "reason_for_visit":  reason,
                "start_time":        slot.get("start_time", ""),
                "end_time":          slot.get("end_time", ""),
                "business_entity_id": business_id,
            })

            logger.info(f"[BOOKING_GRAPH] create_appointment raw response (first 500 chars): {result_text[:500]}")

            parsed = _parse_json(result_text)

            # Check for success
            success = _is_booking_success(parsed, result_text)
            logger.info(f"[BOOKING_GRAPH] create_appointment success={success}, parsed_type={type(parsed).__name__}")
            
            if success:
                # Extract appointment_id from response
                appt_id = ""
                if isinstance(parsed, dict):
                    appt_id = str(parsed.get("id", "") or parsed.get("appointment_id", "") or "")
                return {
                    "booking_result": parsed,
                    "appointment_id": appt_id,
                    "status": "booked",
                    "response_message": "Your appointment has been booked successfully.",
                    "action_required": "confirm_booking",
                    "action_data": parsed,
                }
            
            # Check for in-progress
            if isinstance(parsed, dict) and parsed.get("status") == "in_progress":
                return {
                    "booking_result": parsed,
                    "status": "booking_in_progress",
                    "response_message": "I'm still processing your appointment, one moment.",
                    "action_required": "wait",
                }
            
            # Failure
            return {
                "booking_result": parsed,
                "status": "booking_failed",
                "error": result_text[:200],
                "response_message": "I'm having trouble booking that appointment.",
                "action_required": "handle_failure",
            }
        except Exception as e:
            logger.error(f"[BOOKING_GRAPH] create_appointment error: {e}")
            return {
                "status": "booking_failed",
                "error": str(e),
                "response_message": "I encountered an error while booking the appointment.",
                "action_required": "handle_failure",
            }

    async def cancel_appointment(state: BookingState) -> dict:
        """Cancel appointment via MCP."""
        business_id = os.environ.get("BUSINESS_ID", "4944")

        try:
            result_text = await mcp_caller.call("Cancel_Appointment", {
                "appointment_id": str(state.get("appointment_id", "") or ""),
                "business_entity_id": business_id,
                "appointment_cancellation_reason_id": "1",
                "cancellation_comments": "Cancelled by Sara AI",
            })

            parsed = _parse_json(result_text)
            result_lower = result_text.strip().lower()

            # Hard failure indicators (auth errors or domain-specific rejections)
            hard_fail_keywords = [
                "unauthorized", "401", "403", "forbidden",
                "invalid token", "authentication failed",
                "not found", "invalid appointment",
                "cannot cancel", "already cancelled", "already canceled",
            ]
            if any(kw in result_lower for kw in hard_fail_keywords):
                return {
                    "cancel_result": parsed,
                    "status": "cancel_failed",
                    "error": result_text[:200],
                    "response_message": "I'm having trouble cancelling that appointment.",
                    "action_required": "transfer",
                }

            # Success: empty body (204 No Content) or no generic error keywords
            if not result_lower or "error" not in result_lower:
                return {
                    "cancel_result": parsed,
                    "status": "cancelled",
                    "response_message": "Your appointment has been cancelled successfully.",
                    "action_required": "confirm_cancellation",
                    "action_data": parsed,
                }

            # Fallback: has "error" in body — treat as failure
            return {
                "cancel_result": parsed,
                "status": "cancel_failed",
                "error": result_text[:200],
                "response_message": "I'm having trouble cancelling that appointment.",
                "action_required": "transfer",
            }
        except Exception as e:
            logger.error(f"[BOOKING_GRAPH] cancel_appointment error: {e}")
            return {
                "status": "cancel_failed",
                "error": str(e),
                "response_message": "I encountered an error while cancelling.",
                "action_required": "transfer",
            }

    async def view_appointments(state: BookingState) -> dict:
        """Fetch patient appointments via MCP."""
        try:
            # Use requested_date if available, otherwise default to today + 90 days
            pacific = ZoneInfo("America/Los_Angeles")
            today = datetime.now(pacific).strftime("%Y-%m-%d")
            start = state.get("requested_date", "") or today
            end_default = (datetime.strptime(start, "%Y-%m-%d") + timedelta(days=90)).strftime("%Y-%m-%d")
            
            result_text = await mcp_caller.call("get_appointments_list", {
                "patient_ids": str(state.get("patient_id", "") or ""),
                "start_date": start,
                "end_date": end_default,
                "business_entity_id": os.environ.get("BUSINESS_ID", "4944"),
            })

            appointments = _parse_appointments(result_text)
            return {
                "existing_appointments": appointments,
                "status": "viewed",
                "response_message": f"I found {len(appointments)} upcoming appointment(s).",
                "action_required": "present_appointments",
                "action_data": {"appointments": appointments},
            }
        except Exception as e:
            logger.error(f"[BOOKING_GRAPH] view_appointments error: {e}")
            return {
                "existing_appointments": [],
                "status": "view_failed",
                "error": str(e),
                "response_message": "I'm having trouble looking up your appointments.",
            }

    def suggest_alternative(state: BookingState) -> dict:
        """Suggest next valid business day when requested date has no slots."""
        retry_count = state.get("retry_count", 0) + 1
        current_date = state.get("requested_date", "")
        resource_id = str(state.get("resource_id", "") or "")
        RESOURCE_ELISE = "25784"  # ELISE CALL — Thu/Fri only

        try:
            dt = datetime.strptime(current_date, "%Y-%m-%d")
            next_date = dt + timedelta(days=1)
            # Always skip weekends
            while next_date.weekday() >= 5:
                next_date += timedelta(days=1)
            # For Elise: also skip Mon/Tue/Wed
            if resource_id == RESOURCE_ELISE:
                while next_date.weekday() not in (3, 4):  # 3=Thu, 4=Fri
                    next_date += timedelta(days=1)
            next_date_str = next_date.strftime("%Y-%m-%d")
            pretty_date = next_date.strftime("%A, %B %d")
        except ValueError:
            next_date_str = current_date
            pretty_date = current_date

        return {
            "retry_count": retry_count,
            "requested_date": next_date_str,
            "status": "retrying",
            "response_message": f"Let me check {pretty_date} instead.",
            "action_required": "retry_availability",
        }

    def booking_failure(state: BookingState) -> dict:
        """Handle failed booking — decide retry vs escalate."""
        retry_count = state.get("retry_count", 0)
        max_retries = state.get("max_retries", 3)

        if retry_count < max_retries:
            return {
                "retry_count": retry_count + 1,
                "status": "retrying",
                "response_message": "Let me try another available slot for you.",
                "action_required": "retry_booking",
            }
        return {
            "status": "failed",
            "response_message": "I wasn't able to complete the booking after several attempts.",
            "action_required": "transfer",
        }

    def transfer_to_human(state: BookingState) -> dict:
        """Escalate to human agent."""
        return {
            "status": "transferred",
            "response_message": "Let me connect you with the office.",
            "action_required": "transfer",
            "action_data": {
                "reason": state.get("error", "Booking workflow exhausted retries"),
                "location_id": state.get("location_id", ""),
            },
        }

    return {
        "check_availability": check_availability,
        "create_appointment": create_appointment,
        "cancel_appointment": cancel_appointment,
        "cancel_for_reschedule": cancel_appointment,  # Same logic, different routing
        "view_appointments": view_appointments,
        "suggest_alternative": suggest_alternative,
        "booking_failure": booking_failure,
        "transfer": transfer_to_human,
    }


# ─── Conditional Edge Functions ──────────────────────────────────────────────

def route_by_intent(state: BookingState) -> str:
    """Entry router: direct to correct subgraph based on patient intent."""
    intent = state.get("intent", "schedule")
    if intent == "cancel":
        return "cancel_appointment"
    if intent == "view":
        return "view_appointments"
    if intent == "reschedule":
        return "cancel_for_reschedule"
    return "check_availability"


def after_availability(state: BookingState) -> str:
    """After checking slots: present them, suggest alternative, or return no-slots."""
    slots = state.get("available_slots", [])
    status = state.get("status", "")
    retry = state.get("retry_count", 0)
    max_r = state.get("max_retries", 3)

    if slots:
        return END  # Return slots to voice agent for user selection

    # Hard stops — do NOT retry, return control to agent immediately
    # "past_date": caller gave a past date; agent must ask for a future date
    # "error": MCP/connection error; agent should transfer after speaking the message
    if status in ("past_date", "error"):
        return END

    if retry < max_r:
        return "suggest_alternative"
    return END  # No slots after retries — return to LLM to inform patient


def after_booking(state: BookingState) -> str:
    """After appointment creation: confirm success or handle failure."""
    status = state.get("status", "")
    if status == "booked":
        return END
    if status == "booking_failed":
        return "booking_failure"
    return END  # in_progress — return control to voice agent


def after_cancellation(state: BookingState) -> str:
    """After cancellation: end, rebook (reschedule), or escalate."""
    status = state.get("status", "")
    intent = state.get("intent", "")

    if status == "cancelled" and intent == "reschedule":
        return "check_availability"  # Now book the replacement
    if status == "cancelled":
        return END
    return "transfer"


def after_booking_failure(state: BookingState) -> str:
    """After a booking failure: retry or give up."""
    if state.get("status") == "retrying":
        return "check_availability"
    return "transfer"


def after_alternative(state: BookingState) -> str:
    """After suggesting an alternative date, retry availability."""
    return "check_availability"


# ─── Graph Builder ───────────────────────────────────────────────────────────

def build_booking_graph(mcp_caller: MCPToolCaller) -> Any:
    """
    Compile the appointment booking workflow graph.

    Graph topology:

        START ──[route_by_intent]──┬→ check_availability ──[after_availability]──┬→ END (slots found)
                                   │                                              ├→ suggest_alternative → check_availability
                                   │                                              └→ transfer → END
                                   │
                                   ├→ cancel_appointment ──[after_cancellation]──┬→ END
                                   │                                              └→ transfer → END
                                   │
                                   ├→ cancel_for_reschedule ──[after_cancellation]──┬→ check_availability
                                   │                                                 └→ transfer → END
                                   │
                                   └→ view_appointments → END

        create_appointment ──[after_booking]──┬→ END (success)
                                               └→ booking_failure ──[after_booking_failure]──┬→ check_availability
                                                                                              └→ transfer → END
    """
    nodes = _build_nodes(mcp_caller)
    graph = StateGraph(BookingState)

    # Register all nodes
    for name, fn in nodes.items():
        graph.add_node(name, fn)

    # ── Entry: route by intent ──
    graph.add_conditional_edges(
        START,
        route_by_intent,
        ["check_availability", "cancel_appointment",
         "view_appointments", "cancel_for_reschedule"],
    )

    # ── Availability flow ──
    graph.add_conditional_edges(
        "check_availability",
        after_availability,
        ["suggest_alternative", END],
    )
    graph.add_edge("suggest_alternative", "check_availability")

    # ── Booking flow (invoked separately after slot selection) ──
    graph.add_conditional_edges(
        "create_appointment",
        after_booking,
        ["booking_failure", END],
    )
    graph.add_conditional_edges(
        "booking_failure",
        after_booking_failure,
        ["check_availability", "transfer"],
    )

    # ── Cancellation flow ──
    graph.add_conditional_edges(
        "cancel_appointment",
        after_cancellation,
        ["check_availability", "transfer", END],
    )
    graph.add_conditional_edges(
        "cancel_for_reschedule",
        after_cancellation,
        ["check_availability", "transfer", END],
    )

    # ── Terminal nodes ──
    graph.add_edge("view_appointments", END)
    graph.add_edge("transfer", END)

    return graph.compile()


# ─── Booking Workflow Manager (1 per call) ───────────────────────────────────

class BookingWorkflow:
    """
    Session-scoped booking workflow backed by a LangGraph StateGraph.
    One instance is created per call and maintains state across the entire
    call lifecycle.

    Usage from LiveKit agent tools:
        workflow = BookingWorkflow(mcp_server)
        result = await workflow.check_availability(patient_id=..., ...)
        result = await workflow.book_appointment(selected_slot={...})
        result = await workflow.cancel(appointment_id=...)
        result = await workflow.reschedule(appointment_id=..., ...)
        result = await workflow.view(patient_id=...)
    """

    def __init__(self, mcp_server):
        self._caller = MCPToolCaller(mcp_server)
        self._graph = build_booking_graph(self._caller)
        self._state: Dict[str, Any] = {
            "patient_id": "",
            "patient_external_id": "",
            "patient_name": "",
            "is_new_patient": False,
            "intent": "schedule",
            "location_id": "",
            "provider_id": "",
            "resource_id": "",
            "nature_of_visit_id": "",
            "reason_for_visit": "",
            "requested_date": "",
            "available_slots": [],
            "selected_slot": {},
            "appointment_id": "",
            "existing_appointments": [],
            "booking_result": {},
            "cancel_result": {},
            "retry_count": 0,
            "max_retries": 3,
            "status": "pending",
            "error": "",
            "response_message": "",
            "action_required": "",
            "action_data": {},
        }

    # ── Public API ───────────────────────────────────────────────────────

    @traceable(run_type="chain", name="booking_check_availability_graph")
    async def check_availability(
        self,
        patient_id: str,
        resource_id: str,
        location_id: str,
        requested_date: str,
        nature_of_visit_id: str,
        provider_id: str = "",
        reason_for_visit: str = "",
    ) -> Dict[str, Any]:
        """Run availability check with automatic retry on fallback dates."""
        self._update(
            patient_id=patient_id,
            resource_id=resource_id,
            location_id=location_id,
            requested_date=requested_date,
            nature_of_visit_id=nature_of_visit_id,
            provider_id=provider_id,
            reason_for_visit=reason_for_visit,
            intent="schedule",
            retry_count=0,
        )
        result = await self._graph.ainvoke(dict(self._state))
        self._merge(result)
        return self._safe_state()

    @traceable(run_type="chain", name="booking_create_appointment_graph")
    async def book_appointment(
        self,
        selected_slot: dict,
        patient_id: str = "",
    ) -> Dict[str, Any]:
        """Create appointment for the selected time slot."""
        updates = {"selected_slot": selected_slot}
        if patient_id:
            updates["patient_id"] = patient_id
        self._update(**updates)

        # Restore original API timezone for start_time/end_time.
        # The LLM always sends Pacific (PDT/PST) offsets, but CareCloud's
        # create_appointment API expects times in the exact timezone offset
        # that Available_time_slots originally returned (-04:00 EDT, etc.).
        # _pacific_to_original_slot is populated by _convert_slots_to_pacific
        # (which runs in both the booking_graph check_availability node and
        # MCPToolsIntegration's Available_time_slots post-processor).
        _slot_start = selected_slot.get("start_time", "")
        _slot_end   = selected_slot.get("end_time", "")
        _orig_start = _pacific_to_original_slot.get(_slot_start, _slot_start)
        _orig_end   = _pacific_to_original_slot.get(_slot_end, _slot_end)
        if _orig_start != _slot_start or _orig_end != _slot_end:
            logger.info(
                f"[BOOKING_GRAPH] Slot TZ restored for create_appointment: "
                f"{_slot_start} → {_orig_start}, {_slot_end} → {_orig_end}"
            )
            selected_slot = {"start_time": _orig_start, "end_time": _orig_end}
            self._update(selected_slot=selected_slot)

        # Validate existing appointments to prevent double-booking on same day
        try:
            slot_date = selected_slot.get("start_time", "")[:10]  # YYYY-MM-DD
            if slot_date and self._state.get("patient_id"):
                next_day = (datetime.strptime(slot_date, "%Y-%m-%d") + timedelta(days=1)).strftime("%Y-%m-%d")
                existing_text = await self._caller.call("get_appointments_list", {
                    "patient_ids": str(self._state.get("patient_id", "") or ""),
                    "start_date": slot_date,
                    "end_date": next_day,
                    "business_entity_id": os.environ.get("BUSINESS_ID", "4944"),
                })
                existing = _parse_appointments(existing_text)
                # Filter out cancelled appointments
                active = [a for a in existing if str(a.get("status", "")).lower() not in ("cancelled", "canceled")]
                if active:
                    self._update(
                        existing_appointments=active,
                        status="duplicate_detected",
                        response_message=(
                            f"You already have an appointment on {slot_date}. "
                            "You cannot have multiple appointments on the same day. "
                            "Would you like to keep the existing one, or reschedule to a different date?"
                        ),
                        action_required="resolve_duplicate",
                        action_data={"existing": active, "requested_slot": selected_slot},
                    )
                    return self._safe_state()
                logger.info(f"[BOOKING_GRAPH] No existing appointments on {slot_date}, proceeding")
        except Exception as e:
            logger.warning(f"[BOOKING_GRAPH] Validation failed (non-blocking): {e}")

        # Create appointment
        input_state = dict(self._state)
        input_state["intent"] = "book"  # Direct booking — bypass intent router
        nodes = _build_nodes(self._caller)
        result = await nodes["create_appointment"](input_state)
        self._merge(result)

        return self._safe_state()

    @traceable(run_type="chain", name="booking_cancel_graph")
    async def cancel(self, appointment_id: str, patient_id: str = "") -> Dict[str, Any]:
        """Cancel an existing appointment."""
        self._update(
            appointment_id=appointment_id,
            intent="cancel",
            status="pending",
            error="",
            cancel_result={},
        )
        if patient_id:
            self._update(patient_id=patient_id)
        result = await self._graph.ainvoke(dict(self._state))
        self._merge(result)
        return self._safe_state()

    @traceable(run_type="chain", name="booking_reschedule_graph")
    async def reschedule(
        self,
        appointment_id: str,
        patient_id: str,
        resource_id: str,
        location_id: str,
        requested_date: str,
        nature_of_visit_id: str,
        provider_id: str = "",
        reason_for_visit: str = "",
    ) -> Dict[str, Any]:
        """Reschedule: cancel old appointment then check availability for new one."""
        self._update(
            appointment_id=appointment_id,
            patient_id=patient_id,
            resource_id=resource_id,
            location_id=location_id,
            requested_date=requested_date,
            nature_of_visit_id=nature_of_visit_id,
            provider_id=provider_id,
            reason_for_visit=reason_for_visit,
            intent="reschedule",
            retry_count=0,
            status="pending",
            error="",
            cancel_result={},
            booking_result={},
            available_slots=[],
        )
        result = await self._graph.ainvoke(dict(self._state))
        self._merge(result)
        return self._safe_state()

    @traceable(run_type="chain", name="booking_view_graph")
    async def view(self, patient_id: str) -> Dict[str, Any]:
        """View patient's upcoming appointments."""
        self._update(patient_id=patient_id, intent="view")
        result = await self._graph.ainvoke(dict(self._state))
        self._merge(result)
        return self._safe_state()

    def get_state(self) -> Dict[str, Any]:
        """Return current workflow state."""
        return self._safe_state()

    # ── Internal helpers ─────────────────────────────────────────────────

    def _update(self, **kwargs) -> None:
        """Update workflow state with given key-value pairs."""
        self._state.update(kwargs)

    def _merge(self, result: Dict[str, Any]) -> None:
        """Merge graph result into workflow state."""
        if result:
            self._state.update(result)

    def _safe_state(self) -> Dict[str, Any]:
        """Return a copy of the state for external consumption."""
        return dict(self._state)
