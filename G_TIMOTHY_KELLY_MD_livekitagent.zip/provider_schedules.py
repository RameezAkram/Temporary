"""
Provider Scheduling Configuration
===================================
Centralized, single-source-of-truth for all provider scheduling rules.

Practice:  G. Timothy Kelly MD  —  Las Vegas, NV

Used by:
  - mcp_client/agent_tools.py  (slot filtering engine)
  - tools.py                   (get_location_resources schedule info)
  - prompts.py                 (agent instructions)

IDs
  Location:    Main Office = 29414

  Provider IDs (used for create_appointment, billing):
    DR. GEORGE T KELLY MD (GKELL) = 24506
    ELISE K CALL          (KELLY) = 26123

  Resource IDs (scheduling calendars — used for Available_time_slots,
                get_provider_appointments, Blockout):
    DR. KELLY OB  = 24133  →  provider 24506 (DR. GEORGE T KELLY MD)
    ELISE CALL    = 25784  →  provider 26123 (ELISE K CALL)

  Default Nature of Visit:
    ESTABLISHED PATIENT/FOLLOW-U EXTENDED = 79304  (30 min, Active)
"""

from datetime import time

# ───────────────────────────────────────────
# Location IDs
# ───────────────────────────────────────────
LOC_MAIN_OFFICE = 29414

LOCATION_NAMES = {
    LOC_MAIN_OFFICE: "Main Office",
}

# ───────────────────────────────────────────
# Provider IDs  (billing / create_appointment)
# ───────────────────────────────────────────
PROVIDER_KELLY = 24506   # DR. GEORGE T KELLY MD  (mnemonic: GKELL)
PROVIDER_ELISE = 26123   # ELISE K CALL           (mnemonic: KELLY)

# Backward-compat aliases kept so existing imports don't break
RES_KELLY = PROVIDER_KELLY
RES_ELISE = PROVIDER_ELISE

# ───────────────────────────────────────────
# Resource IDs  (scheduling — Available_time_slots, get_provider_appointments, Blockout)
# ───────────────────────────────────────────
RESOURCE_KELLY_OB = 24133   # DR. KELLY OB  →  provider 24506
RESOURCE_ELISE    = 25784   # ELISE CALL    →  provider 26123

RESOURCE_NAMES = {
    RESOURCE_KELLY_OB: "DR. KELLY OB",
    RESOURCE_ELISE:    "ELISE CALL",
}

# Bidirectional provider ↔ resource mappings
PROVIDER_TO_RESOURCE = {
    PROVIDER_KELLY: RESOURCE_KELLY_OB,
    PROVIDER_ELISE: RESOURCE_ELISE,
}
RESOURCE_TO_PROVIDER = {
    RESOURCE_KELLY_OB: PROVIDER_KELLY,
    RESOURCE_ELISE:    PROVIDER_ELISE,
}

# ───────────────────────────────────────────
# Default Nature of Visit
# ───────────────────────────────────────────
DEFAULT_NATURE_OF_VISIT_ID   = 79304
DEFAULT_NATURE_OF_VISIT_NAME = "ESTABLISHED PATIENT/FOLLOW-U EXTENDED"  # 30 min, Active


# ═══════════════════════════════════════════
# MASTER SLOT FILTER
# ═══════════════════════════════════════════
def is_slot_allowed(slot_start_dt, resource_id, location_id):
    """
    Return True if the slot is at an allowed location for the given resource.
    resource_id here is the scheduling resource ID (e.g. 24133, 25784),
    NOT the provider ID.
    Both resources work exclusively at Main Office (29414).
    """
    # Only Main Office is valid
    if location_id != LOC_MAIN_OFFICE:
        return False

    if resource_id in (RESOURCE_KELLY_OB, RESOURCE_ELISE):
        # Allow all slots — CareCloud Available_time_slots already enforces
        # the actual working hours; no additional filtering needed here.
        return True

    # Unknown resource: allow (let the API decide)
    return True


# ═══════════════════════════════════════════
# HUMAN-READABLE SCHEDULE DESCRIPTIONS
# ═══════════════════════════════════════════

def get_provider_schedule_text(resource_id):
    """Return a human-readable schedule description for a resource (scheduling calendar)."""

    if resource_id == RESOURCE_KELLY_OB:
        return (
            "DR. GEORGE T KELLY MD (Resource: DR. KELLY OB, ID: 24133) — "
            "Main Office (7200 W Cathedral Rock Dr, Suite 110, Las Vegas, NV 89128)\n"
            "  Please call the office or use the scheduling system for available appointment times."
        )

    if resource_id == RESOURCE_ELISE:
        return (
            "ELISE K CALL (Resource: ELISE CALL, ID: 25784) — "
            "Main Office (7200 W Cathedral Rock Dr, Suite 110, Las Vegas, NV 89128)\n"
            "  Please call the office or use the scheduling system for available appointment times."
        )

    return "Main Office (7200 W Cathedral Rock Dr, Suite 110, Las Vegas, NV 89128): Please call for schedule details."


def get_provider_schedule_for_location(resource_id, location_id):
    """Return schedule text filtered to a specific location."""

    loc_name = LOCATION_NAMES.get(location_id, "this location")

    if resource_id == RESOURCE_KELLY_OB:
        return (
            f"DR. GEORGE T KELLY MD at {loc_name}:\n"
            "  Please use the scheduling system for current available times."
        )

    if resource_id == RESOURCE_ELISE:
        return (
            f"ELISE K CALL at {loc_name}:\n"
            "  Please use the scheduling system for current available times."
        )

    return f"Provider at {loc_name}: Please use the scheduling system for available times."


def get_all_schedules_summary():
    """Full summary of both providers for agent context."""
    return (
        "═══════════════════════════════════════════\n"
        "PROVIDER SCHEDULE REFERENCE\n"
        "Practice: G. Timothy Kelly MD\n"
        "═══════════════════════════════════════════\n\n"
        + get_provider_schedule_text(RESOURCE_KELLY_OB) + "\n\n"
        + get_provider_schedule_text(RESOURCE_ELISE) + "\n\n"
        "📍 Main Office: 7200 W Cathedral Rock Drive, Suite 110, Las Vegas, NV 89128\n"
        "   Both providers see patients exclusively at this location.\n"
    )
