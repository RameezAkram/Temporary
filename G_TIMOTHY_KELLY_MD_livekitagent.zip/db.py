"""
db.py — MySQL + SQL Server database helper
Provides execute_update() / execute_query() for MySQL (primary)
and mssql_execute_update() / mssql_execute_query() for SQL Server (secondary).
Token operations use both databases for redundancy.
Connection parameters are read from environment variables (see .env).
"""

import os
import logging
import mysql.connector
from mysql.connector import Error
import pyodbc
from typing import Optional, List, Dict, Any
from dotenv import load_dotenv

# Always load .env relative to this file's location, regardless of cwd
load_dotenv(dotenv_path=os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env"), override=True)

logger = logging.getLogger("db")

# ---------------------------------------------------------------------------
# MySQL connection config (from .env)
# ---------------------------------------------------------------------------
_DB_CONFIG = {
    "host":     os.getenv("MYSQL_HOST",     "10.20.35.65"),
    "port":     int(os.getenv("MYSQL_PORT", "3306")),
    "database": os.getenv("MYSQL_DATABASE", "ai_database"),
    "user":     os.getenv("MYSQL_USER",     "ai_user"),
    "password": os.getenv("MYSQL_PASSWORD", ""),
    "connect_timeout": 3,
    "autocommit": False,
}

# ---------------------------------------------------------------------------
# SQL Server connection config (from .env)
# ---------------------------------------------------------------------------
_MSSQL_CONFIG = {
    "server":   os.getenv("DB_SERVER",   "10.10.30.57"),
    "port":     int(os.getenv("DB_PORT",  "1433")),
    "database": os.getenv("DB_DATABASE", "MIS_DB"),
    "user":     os.getenv("DB_USER",     "COE_AI"),
    "password": os.getenv("DB_PASSWORD", ""),
}

_MYSQL_LABEL  = f"{_DB_CONFIG['host']}:{_DB_CONFIG['port']}/{_DB_CONFIG['database']}"
_MSSQL_LABEL  = f"{_MSSQL_CONFIG['server']}:{_MSSQL_CONFIG['port']}/{_MSSQL_CONFIG['database']}"


def _get_connection() -> mysql.connector.MySQLConnection:
    """Open and return a new MySQL connection."""
    return mysql.connector.connect(**_DB_CONFIG)


def _get_mssql_connection() -> pyodbc.Connection:
    """Open and return a new SQL Server connection via pyodbc."""
    # Use Driver 18 in Docker (msodbcsql18), Driver 17 on Windows
    driver = "ODBC Driver 18 for SQL Server" if not os.path.exists("C:\\") else "ODBC Driver 17 for SQL Server"
    conn_str = (
        f"DRIVER={{{driver}}};"
        f"SERVER={_MSSQL_CONFIG['server']},{_MSSQL_CONFIG['port']};"
        f"DATABASE={_MSSQL_CONFIG['database']};"
        f"UID={_MSSQL_CONFIG['user']};"
        f"PWD={_MSSQL_CONFIG['password']};"
        f"Connection Timeout=3;"
        f"TrustServerCertificate=yes;"
    )
    return pyodbc.connect(conn_str)


def execute_update(query: str, params: tuple = ()) -> bool:
    """
    Execute a single DML statement (UPDATE / INSERT / DELETE).

    Parameters
    ----------
    query : str
        The SQL statement with optional %s placeholders.
    params : tuple
        Values to bind to the placeholders (prevents SQL injection).

    Returns
    -------
    bool
        True on success, False on any database error.
    """
    conn = None
    try:
        conn = _get_connection()
        cursor = conn.cursor()
        cursor.execute(query, params)
        conn.commit()
        logger.debug("execute_update succeeded: rows_affected=%d", cursor.rowcount)
        return True
    except Error as exc:
        logger.error("DB execute_update failed: %s | query=%s", exc, query[:200])
        if conn:
            try:
                conn.rollback()
            except Error:
                pass
        return False
    finally:
        if conn and conn.is_connected():
            conn.close()


def execute_query(query: str, params: tuple = ()) -> list[dict] | None:
    """
    Execute a SELECT statement and return rows as a list of dicts.

    Parameters
    ----------
    query : str
        The SQL statement with optional %s placeholders.
    params : tuple
        Values to bind to the placeholders (prevents SQL injection).

    Returns None on error.
    """
    conn = None
    try:
        conn = _get_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute(query, params)
        rows = cursor.fetchall()
        return rows
    except Error as exc:
        logger.error("DB execute_query failed: %s | query=%s", exc, query[:200])
        return None
    finally:
        if conn and conn.is_connected():
            conn.close()


# ---------------------------------------------------------------------------
# SQL Server helpers
# ---------------------------------------------------------------------------

def mssql_execute_update(query: str, params: tuple = ()) -> bool:
    """Execute a DML statement on SQL Server. Uses ? placeholders."""
    conn = None
    try:
        conn = _get_mssql_connection()
        cursor = conn.cursor()
        cursor.execute(query, params)
        conn.commit()
        logger.debug("mssql_execute_update succeeded: rows_affected=%d", cursor.rowcount)
        return True
    except Exception as exc:
        logger.error("[SQL_SERVER] execute_update failed: %s | query=%s", exc, query[:200])
        if conn:
            try:
                conn.rollback()
            except Exception:
                pass
        return False
    finally:
        if conn:
            try:
                conn.close()
            except Exception:
                pass


def mssql_execute_query(query: str, params: tuple = ()) -> list[dict] | None:
    """Execute a SELECT on SQL Server and return rows as a list of dicts."""
    conn = None
    try:
        conn = _get_mssql_connection()
        cursor = conn.cursor()
        cursor.execute(query, params)
        columns = [desc[0] for desc in cursor.description]
        rows = [dict(zip(columns, row)) for row in cursor.fetchall()]
        return rows
    except Exception as exc:
        logger.error("[SQL_SERVER] execute_query failed: %s | query=%s", exc, query[:200])
        return None
    finally:
        if conn:
            try:
                conn.close()
            except Exception:
                pass


# ---------------------------------------------------------------------------
# Dual-DB token helpers (MySQL primary, SQL Server secondary)
# ---------------------------------------------------------------------------

def persist_both_tokens(ex_token: str, ws_token: str, business_entity: str = "3684") -> bool:
    """
    Write ex_auth_token and ws_auth_token to BOTH MySQL and SQL Server.
    Tries both DBs regardless of the other's outcome.
    Logs which DB connected and whether the record was written.
    Returns True if at least one DB succeeded.
    """
    mysql_ok = False
    mssql_ok = False

    # ---- MySQL ----
    try:
        rows = execute_query(
            "SELECT id FROM TokenTable WHERE business_entity = %s LIMIT 1",
            (business_entity,),
        )
        if rows is None:
            logger.error("[MYSQL] Connection failed — could not reach %s", _MYSQL_LABEL)
        elif rows:
            ok = execute_update(
                "UPDATE TokenTable SET ex_auth_token = %s, ws_auth_token = %s WHERE business_entity = %s",
                (ex_token, ws_token, business_entity),
            )
            if ok:
                mysql_ok = True
                logger.info("[MYSQL] Connected to %s — both tokens updated for business_entity=%s", _MYSQL_LABEL, business_entity)
            else:
                logger.error("[MYSQL] UPDATE failed for business_entity=%s on %s", business_entity, _MYSQL_LABEL)
        else:
            ok = execute_update(
                "INSERT INTO TokenTable (business_entity, ex_auth_token, ws_auth_token) VALUES (%s, %s, %s)",
                (business_entity, ex_token, ws_token),
            )
            if ok:
                mysql_ok = True
                logger.info("[MYSQL] Connected to %s — both tokens inserted for business_entity=%s", _MYSQL_LABEL, business_entity)
            else:
                logger.error("[MYSQL] INSERT failed for business_entity=%s on %s", business_entity, _MYSQL_LABEL)
    except Exception as exc:
        logger.error("[MYSQL] persist_both_tokens error: %s", exc)

    # ---- SQL Server ----
    try:
        rows = mssql_execute_query(
            "SELECT TOP 1 id FROM TokenTable WHERE business_entity = ?",
            (business_entity,),
        )
        if rows is None:
            logger.error("[SQL_SERVER] Connection failed — could not reach %s", _MSSQL_LABEL)
        elif rows:
            ok = mssql_execute_update(
                "UPDATE TokenTable SET ex_auth_token = ?, ws_auth_token = ? WHERE business_entity = ?",
                (ex_token, ws_token, business_entity),
            )
            if ok:
                mssql_ok = True
                logger.info("[SQL_SERVER] Connected to %s — both tokens updated for business_entity=%s", _MSSQL_LABEL, business_entity)
            else:
                logger.error("[SQL_SERVER] UPDATE failed for business_entity=%s on %s", business_entity, _MSSQL_LABEL)
        else:
            ok = mssql_execute_update(
                "INSERT INTO TokenTable (business_entity, ex_auth_token, ws_auth_token) VALUES (?, ?, ?)",
                (business_entity, ex_token, ws_token),
            )
            if ok:
                mssql_ok = True
                logger.info("[SQL_SERVER] Connected to %s — both tokens inserted for business_entity=%s", _MSSQL_LABEL, business_entity)
            else:
                logger.error("[SQL_SERVER] INSERT failed for business_entity=%s on %s", business_entity, _MSSQL_LABEL)
    except Exception as exc:
        logger.error("[SQL_SERVER] persist_both_tokens error: %s", exc)

    if mysql_ok and mssql_ok:
        logger.info("[DB] Both databases updated successfully for business_entity=%s", business_entity)
    elif mysql_ok:
        logger.warning("[DB] Only MySQL updated — SQL Server unavailable for business_entity=%s", business_entity)
    elif mssql_ok:
        logger.warning("[DB] Only SQL Server updated — MySQL unavailable for business_entity=%s", business_entity)
    else:
        logger.error("[DB] Both databases failed to update for business_entity=%s", business_entity)

    return mysql_ok or mssql_ok


def save_token_to_both_dbs(token_column: str, token_value: str, business_entity: str = "3684") -> bool:
    """
    Save a single token column to BOTH MySQL and SQL Server.
    If one DB fails, log the error and still try the other.
    Returns True if at least one DB succeeded.
    """
    mysql_ok = False
    mssql_ok = False

    # ---- MySQL ----
    try:
        rows = execute_query(
            "SELECT id FROM TokenTable WHERE business_entity = %s LIMIT 1",
            (business_entity,),
        )
        if rows is None:
            logger.error("[MYSQL] Connection failed — could not reach %s", _MYSQL_LABEL)
        elif rows:
            q = f"UPDATE TokenTable SET {token_column} = %s WHERE business_entity = %s"
            mysql_ok = execute_update(q, (token_value, business_entity))
            if mysql_ok:
                logger.info("[MYSQL] Connected to %s — %s saved for business_entity=%s", _MYSQL_LABEL, token_column, business_entity)
            else:
                logger.error("[MYSQL] Failed to save %s for business_entity=%s on %s", token_column, business_entity, _MYSQL_LABEL)
        else:
            q = f"INSERT INTO TokenTable (business_entity, {token_column}) VALUES (%s, %s)"
            mysql_ok = execute_update(q, (business_entity, token_value))
            if mysql_ok:
                logger.info("[MYSQL] Connected to %s — %s inserted for business_entity=%s", _MYSQL_LABEL, token_column, business_entity)
            else:
                logger.error("[MYSQL] Failed to insert %s for business_entity=%s on %s", token_column, business_entity, _MYSQL_LABEL)
    except Exception as exc:
        logger.error("[MYSQL] save_token_to_both_dbs error (%s): %s", token_column, exc)

    # ---- SQL Server ----
    try:
        rows = mssql_execute_query(
            "SELECT TOP 1 id FROM TokenTable WHERE business_entity = ?",
            (business_entity,),
        )
        if rows is None:
            logger.error("[SQL_SERVER] Connection failed — could not reach %s", _MSSQL_LABEL)
        elif rows:
            q = f"UPDATE TokenTable SET {token_column} = ? WHERE business_entity = ?"
            mssql_ok = mssql_execute_update(q, (token_value, business_entity))
            if mssql_ok:
                logger.info("[SQL_SERVER] Connected to %s — %s saved for business_entity=%s", _MSSQL_LABEL, token_column, business_entity)
            else:
                logger.error("[SQL_SERVER] Failed to save %s for business_entity=%s on %s", token_column, business_entity, _MSSQL_LABEL)
        else:
            q = f"INSERT INTO TokenTable (business_entity, {token_column}) VALUES (?, ?)"
            mssql_ok = mssql_execute_update(q, (business_entity, token_value))
            if mssql_ok:
                logger.info("[SQL_SERVER] Connected to %s — %s inserted for business_entity=%s", _MSSQL_LABEL, token_column, business_entity)
            else:
                logger.error("[SQL_SERVER] Failed to insert %s for business_entity=%s on %s", token_column, business_entity, _MSSQL_LABEL)
    except Exception as exc:
        logger.error("[SQL_SERVER] save_token_to_both_dbs error (%s): %s", token_column, exc)

    return mysql_ok or mssql_ok


def fetch_tokens_from_both_dbs(business_entity: str = "3684") -> dict:
    """
    Fetch ex_auth_token and ws_auth_token.
    Priority: MySQL first. If MySQL fails or returns empty, fallback to SQL Server.
    Returns dict with keys 'ex_auth_token' and 'ws_auth_token' (may be empty strings).
    """
    result = {"ex_auth_token": "", "ws_auth_token": ""}

    # ---- Try MySQL first (priority) ----
    mysql_ok = False
    try:
        rows = execute_query(
            "SELECT ex_auth_token, ws_auth_token FROM TokenTable WHERE business_entity = %s LIMIT 1",
            (business_entity,),
        )
        if rows is None:
            logger.error("[MYSQL] Connection failed — could not reach %s", _MYSQL_LABEL)
        elif rows and rows[0]:
            ex = rows[0].get("ex_auth_token") or ""
            ws = rows[0].get("ws_auth_token") or ""
            if ex or ws:
                result["ex_auth_token"] = ex
                result["ws_auth_token"] = ws
                mysql_ok = True
                logger.info("[MYSQL] Connected to %s — tokens fetched (ex_len=%d, ws_len=%d)", _MYSQL_LABEL, len(ex), len(ws))
            else:
                logger.warning("[MYSQL] Connected to %s — tokens present but empty for business_entity=%s", _MYSQL_LABEL, business_entity)
        else:
            logger.warning("[MYSQL] Connected to %s — no token rows found for business_entity=%s", _MYSQL_LABEL, business_entity)
    except Exception as exc:
        logger.error("[MYSQL] fetch_tokens error: %s", exc)

    if mysql_ok:
        return result

    # ---- Fallback to SQL Server ----
    logger.warning("[DB] MySQL tokens unavailable — falling back to SQL Server (%s)", _MSSQL_LABEL)
    try:
        rows = mssql_execute_query(
            "SELECT TOP 1 ex_auth_token, ws_auth_token FROM TokenTable WHERE business_entity = ?",
            (business_entity,),
        )
        if rows is None:
            logger.error("[SQL_SERVER] Connection failed — could not reach %s", _MSSQL_LABEL)
        elif rows and rows[0]:
            ex = rows[0].get("ex_auth_token") or ""
            ws = rows[0].get("ws_auth_token") or ""
            result["ex_auth_token"] = ex
            result["ws_auth_token"] = ws
            logger.info("[SQL_SERVER] Connected to %s — tokens fetched (ex_len=%d, ws_len=%d)", _MSSQL_LABEL, len(ex), len(ws))
        else:
            logger.warning("[SQL_SERVER] Connected to %s — no token rows found for business_entity=%s", _MSSQL_LABEL, business_entity)
    except Exception as exc:
        logger.error("[SQL_SERVER] fetch_tokens error: %s", exc)

    return result
