"""
LangGraph-backed LiveKit function tools for the booking workflow.

These tools are exposed to the LiveKit agent's LLM (OpenAI Realtime)
as callable functions. Each tool invokes the LangGraph booking workflow which
manages state, retries, and fallback logic internally.

Architecture:
    LLM tool call → booking_tools function → BookingWorkflow → LangGraph → MCP API
"""

import json
import logging
from datetime import datetime, timedelta, date as _date
from zoneinfo import ZoneInfo
from typing import Optional

from livekit.agents import RunContext
from livekit.agents.llm import function_tool

from booking_graph import BookingWorkflow

logger = logging.getLogger("booking-tools")

# Module-level workflow reference — set per call from agent.py
_workflow: Optional[BookingWorkflow] = None

# Dedup: simple flag + key to prevent parallel duplicate booking calls
_booking_in_progress: bool = False
_last_booking_key: Optional[str] = None


def set_booking_workflow(workflow: BookingWorkflow) -> None:
    """Set the active BookingWorkflow instance for this call session."""
    global _workflow, _last_booking_key, _booking_in_progress
    _workflow = workflow
    _last_booking_key = None
    _booking_in_progress = False
    logger.info("[BOOKING_TOOLS] BookingWorkflow set for this call session")


def get_booking_workflow() -> Optional[BookingWorkflow]:
    """Get the active BookingWorkflow."""
    return _workflow


# ─── LiveKit Function Tools ──────────────────────────────────────────────────


@function_tool()
async def booking_check_availability(
    patient_id: str,
    resource_id: str,
    location_id: str,
    requested_date: str,
    nature_of_visit_id: str,
    provider_id: str = "",
    reason_for_visit: str = "",
    context: RunContext = None,
) -> str:
    """Check available appointment time slots for a patient using the booking workflow.

    This tool checks availability through the LangGraph booking engine which
    automatically handles blockout filtering and retries with the next available
    business day if no slots are found on the requested date. It will try up to
    3 alternative dates before giving up.

    Use this INSTEAD of calling Available_time_slots directly when you want
    automatic fallback to next available dates and blockout filtering.

    IMPORTANT: You MUST call Patient_Verification first to get a valid patient_id.
    Never use user_profile_id as patient_id.

    Args:
        patient_id: The patient's unique ID (from Patient_Verification). REQUIRED.
        resource_id: The calendar/schedule resource ID (24133 for DR. KELLY, 25784 for ELISE).
        location_id: Location ID (29414 for Main Office).
        requested_date: Desired date in YYYY-MM-DD format.
        nature_of_visit_id: Nature of visit ID (79304 = ESTABLISHED PATIENT 30min).
        provider_id: Optional provider doctor ID (24506 for DR. KELLY, 26123 for ELISE).
        reason_for_visit: The patient's reason for visit. Stored for appointment creation.
    """
    if not _workflow:
        return json.dumps({"error": "Booking workflow not initialized"})

    # ── Pre-validation: reject past dates and weekends BEFORE hitting the API ──
    _pacific = ZoneInfo("America/Los_Angeles")
    _today = datetime.now(_pacific).date()
    try:
        _req_dt = datetime.strptime(requested_date, "%Y-%m-%d").date()
        if _req_dt < _today:
            _today_str = _today.strftime("%B %d, %Y")
            return json.dumps({
                "status": "past_date",
                "available_slots": [],
                "earliest_slots_formatted": [],
                "all_slots_count": 0,
                "response_message": (
                    f"That date has already passed. I cannot book appointments in the past. "
                    f"Today is {_today_str}. Please provide today's date or a future date."
                ),
                "action_required": "ask_for_future_date",
                "checked_date": requested_date,
                "retry_count": 0,
            })
        if _req_dt.weekday() >= 5:  # 5=Saturday, 6=Sunday
            _days_to_monday = 7 - _req_dt.weekday()
            _next_weekday = _req_dt + timedelta(days=_days_to_monday)
            return json.dumps({
                "status": "weekend",
                "available_slots": [],
                "earliest_slots_formatted": [],
                "all_slots_count": 0,
                "response_message": (
                    f"Our office is closed on weekends. "
                    f"The next available weekday is {_next_weekday.strftime('%A, %B %d, %Y')}. "
                    f"Would you like me to check availability for that date?"
                ),
                "action_required": "confirm_next_weekday",
                "checked_date": requested_date,
                "retry_count": 0,
                "suggested_date": _next_weekday.strftime("%Y-%m-%d"),
            })
    except ValueError:
        pass  # Invalid date format — let the workflow handle it

    try:
        result = await _workflow.check_availability(
            patient_id=patient_id,
            resource_id=resource_id,
            location_id=location_id,
            requested_date=requested_date,
            nature_of_visit_id=nature_of_visit_id,
            provider_id=provider_id,
            reason_for_visit=reason_for_visit,
        )

        all_slots = result.get("available_slots", [])

        # Pre-format the first 3 slot start times as readable 12-hour strings
        # (e.g. "8:30 AM", "1:00 PM") so the LLM can speak them immediately
        # without parsing raw ISO timestamps — reduces response latency.
        def _fmt_time(iso: str) -> str:
            try:
                t = datetime.fromisoformat(iso)
                h = t.strftime("%I").lstrip("0") or "12"
                return f"{h}:{t.strftime('%M %p')}"
            except Exception:
                return iso

        earliest_slots_formatted = [
            _fmt_time(s.get("start_time", ""))
            for s in all_slots[:3]
            if s.get("start_time")
        ]

        return json.dumps({
            "status": result.get("status", ""),
            "available_slots": all_slots,
            "earliest_slots_formatted": earliest_slots_formatted,
            "all_slots_count": len(all_slots),
            "response_message": result.get("response_message", ""),
            "action_required": result.get("action_required", ""),
            "checked_date": result.get("requested_date", requested_date),
            "retry_count": result.get("retry_count", 0),
        })
    except Exception as e:
        logger.error(f"[BOOKING_TOOLS] check_availability failed: {e}")
        return json.dumps({"error": str(e), "status": "failed"})


@function_tool()
async def booking_create_appointment(
    start_time: str,
    end_time: str,
    patient_id: str = "",
    context: RunContext = None,
) -> str:
    """Book an appointment for the previously selected time slot.

    PREREQUISITE: You must call booking_check_availability first to get
    available slots. Then pass the start_time and end_time from the slot
    the patient selected.

    IMPORTANT: You MUST always pass patient_id. This is the ID from
    Patient_Verification. Booking WILL FAIL without a valid patient_id.

    This tool automatically:
    - Validates no existing appointments on the same day (prevents double-booking)
    - Creates the appointment via MCP
    - Returns confirmation or error details

    Args:
        start_time: Appointment start time (ISO format from the selected slot).
        end_time: Appointment end time (ISO format from the selected slot).
        patient_id: The patient ID from Patient_Verification. REQUIRED for booking.
    """
    if not _workflow:
        return json.dumps({"error": "Booking workflow not initialized"})

    # ── Dedup: prevent parallel duplicate calls from the LLM ──
    global _last_booking_key, _booking_in_progress
    booking_key = f"{patient_id}|{start_time}|{end_time}"

    # Check 1: another booking call is currently in progress
    if _booking_in_progress:
        logger.warning(f"[BOOKING_TOOLS] Duplicate booking call BLOCKED (in progress): {booking_key}")
        return json.dumps({
            "status": "in_progress",
            "response_message": "Your appointment is still being processed. Please wait a moment.",
            "action_required": "wait",
        })

    # Check 2: same exact booking was already completed
    if booking_key == _last_booking_key:
        logger.warning(f"[BOOKING_TOOLS] Duplicate booking call BLOCKED (already completed): {booking_key}")
        return json.dumps({
            "status": _workflow.get_state().get("status", ""),
            "booking_result": _workflow.get_state().get("booking_result", {}),
            "response_message": _workflow.get_state().get("response_message", ""),
            "action_required": _workflow.get_state().get("action_required", ""),
        })

    # Mark in progress BEFORE any await
    _booking_in_progress = True
    try:
        _last_booking_key = booking_key
        result = await _workflow.book_appointment(
            selected_slot={"start_time": start_time, "end_time": end_time},
            patient_id=patient_id,
        )
        return json.dumps({
            "status": result.get("status", ""),
            "booking_result": result.get("booking_result", {}),
            "existing_appointments": result.get("existing_appointments", []),
            "response_message": result.get("response_message", ""),
            "action_required": result.get("action_required", ""),
        })
    except Exception as e:
        logger.error(f"[BOOKING_TOOLS] create_appointment failed: {e}")
        return json.dumps({"error": str(e), "status": "failed"})
    finally:
        _booking_in_progress = False


@function_tool()
async def booking_cancel_appointment(
    appointment_id: str,
    patient_id: str = "",
    context: RunContext = None,
) -> str:
    """Cancel an existing appointment through the booking workflow.

    The workflow tracks the cancellation state and handles error/retry logic.

    Args:
        appointment_id: The appointment ID to cancel (patient_external_id UUID format).
        patient_id: Optional patient ID for context tracking.
    """
    if not _workflow:
        return json.dumps({"error": "Booking workflow not initialized"})

    try:
        result = await _workflow.cancel(
            appointment_id=appointment_id,
            patient_id=patient_id,
        )
        return json.dumps({
            "status": result.get("status", ""),
            "cancel_result": result.get("cancel_result", {}),
            "response_message": result.get("response_message", ""),
            "action_required": result.get("action_required", ""),
        })
    except Exception as e:
        logger.error(f"[BOOKING_TOOLS] cancel_appointment failed: {e}")
        return json.dumps({"error": str(e), "status": "failed"})


@function_tool()
async def booking_reschedule_appointment(
    appointment_id: str,
    patient_id: str,
    resource_id: str,
    location_id: str,
    requested_date: str,
    nature_of_visit_id: str,
    provider_id: str = "",
    reason_for_visit: str = "",
    context: RunContext = None,
) -> str:
    """Reschedule an appointment through the booking workflow.

    This tool:
    1. Cancels the old appointment
    2. Checks availability for the new date (with automatic retry on fallback dates)
    3. Returns available slots for the patient to select

    After receiving slots, use booking_create_appointment to complete the rescheduling.

    Args:
        appointment_id: The appointment ID to cancel/reschedule.
        patient_id: The patient's ID from Patient_Verification.
        resource_id: The resource ID for the new appointment.
        location_id: The location ID for the new appointment.
        requested_date: Desired new date in YYYY-MM-DD format.
        nature_of_visit_id: Nature of visit ID for the new appointment.
        provider_id: Optional provider ID for the new appointment.
        reason_for_visit: The patient's reason for the new appointment.
    """
    if not _workflow:
        return json.dumps({"error": "Booking workflow not initialized"})

    try:
        result = await _workflow.reschedule(
            appointment_id=appointment_id,
            patient_id=patient_id,
            resource_id=resource_id,
            location_id=location_id,
            requested_date=requested_date,
            nature_of_visit_id=nature_of_visit_id,
            provider_id=provider_id,
            reason_for_visit=reason_for_visit,
        )
        return json.dumps({
            "status": result.get("status", ""),
            "cancel_result": result.get("cancel_result", {}),
            "available_slots": result.get("available_slots", []),
            "response_message": result.get("response_message", ""),
            "action_required": result.get("action_required", ""),
        })
    except Exception as e:
        logger.error(f"[BOOKING_TOOLS] reschedule_appointment failed: {e}")
        return json.dumps({"error": str(e), "status": "failed"})


@function_tool()
async def booking_view_appointments(
    patient_id: str,
    context: RunContext = None,
) -> str:
    """View a patient's upcoming appointments.

    Retrieves all appointments for the patient starting from today
    through the next 90 days.

    Args:
        patient_id: The patient's ID from Patient_Verification.
    """
    if not _workflow:
        return json.dumps({"error": "Booking workflow not initialized"})

    try:
        result = await _workflow.view(patient_id=patient_id)
        return json.dumps({
            "status": result.get("status", ""),
            "existing_appointments": result.get("existing_appointments", []),
            "response_message": result.get("response_message", ""),
            "action_required": result.get("action_required", ""),
        })
    except Exception as e:
        logger.error(f"[BOOKING_TOOLS] view_appointments failed: {e}")
        return json.dumps({"error": str(e), "status": "failed"})


@function_tool()
async def booking_get_state(
    context: RunContext = None,
) -> str:
    """Get the current state of the booking workflow.

    Useful for debugging or understanding what context the workflow has stored.

    Returns:
        JSON string with current workflow state including patient_id, location_id,
        provider_id, resource_id, available_slots, and booking status.
    """
    if not _workflow:
        return json.dumps({"error": "Booking workflow not initialized"})

    try:
        state = _workflow.get_state()
        return json.dumps({
            "patient_id": state.get("patient_id", ""),
            "location_id": state.get("location_id", ""),
            "provider_id": state.get("provider_id", ""),
            "resource_id": state.get("resource_id", ""),
            "nature_of_visit_id": state.get("nature_of_visit_id", ""),
            "requested_date": state.get("requested_date", ""),
            "status": state.get("status", ""),
            "available_slots_count": len(state.get("available_slots", [])),
            "has_selected_slot": bool(state.get("selected_slot", {})),
            "action_required": state.get("action_required", ""),
        })
    except Exception as e:
        logger.error(f"[BOOKING_TOOLS] get_state failed: {e}")
        return json.dumps({"error": str(e)})
