import json
import os
from typing import Optional, Dict, Any, List
from livekit.agents import function_tool, RunContext


# ============================================================
# ALLOWED PROVIDERS WHITELIST
# Only the two client-confirmed providers are shown.
#   24506 → DR. GEORGE T KELLY MD  (mnemonic: GKELL)
#   26123 → ELISE K CALL           (mnemonic: KELLY)
# ============================================================
ALLOWED_PROVIDER_IDS = {24506, 26123}


def get_location_resource_types_with_visits(
    data: Dict[str, Any], 
    location_id: int, 
    visit_reason_id: Optional[int] = None
) -> Dict[str, Any]:
    """
    Get resources at a location with their providers and visit reasons.
    
    Filtering logic:
      - ALL resources are considered (no resource ID whitelist).
      - Only providers in ALLOWED_PROVIDER_IDS are included per resource.
      - If a resource has NO providers in ALLOWED_PROVIDER_IDS, it is excluded entirely.
      - Inactive resources (status != "A") are excluded.
      - Uses HYBRID approach: Check location.location_resources first, then resource.resource_locations
    
    Args:
        data: Business entity data (from data.txt or API)
        location_id: Location ID to filter resources
        visit_reason_id: Optional - If provided, only returns resources that support this visit reason
        
    Returns:
        Dictionary with default_resources and alternative_resources
    """
    default_resources = []
    alternative_resources = []

    # Build Provider ID → Name Mapping (only ACTIVE providers)
    provider_id_to_name = {}
    for provider in data.get("providers", []):
        pid = provider.get("id")
        
        # FILTER 1: Check ALLOWED_PROVIDER_IDS whitelist (if configured)
        if ALLOWED_PROVIDER_IDS is not None and pid not in ALLOWED_PROVIDER_IDS:
            continue
        
        # FILTER 2: Only include ACTIVE providers (status = "A")
        # This prevents duplicate provider names when old/inactive records exist
        provider_status = provider.get("status", "")
        if provider_status != "A":
            continue
        
        first_name = provider.get("first_name", "")
        last_name = provider.get("last_name", "")
        full_name = f"{first_name} {last_name}".strip()
        if pid:
            provider_id_to_name[pid] = full_name if full_name else f"Provider {pid}"

    # Build Resource → Visit Reason Mapping
    resource_to_visit_reasons = {}
    for visit_item in data.get("nature_of_visits", []):
        visit = visit_item.get("nature_of_visit", {})
        
        for resource_obj in visit.get("nature_of_visit_resources", []):
            rid = resource_obj.get("id")
            if rid is None:
                continue
                
            if rid not in resource_to_visit_reasons:
                resource_to_visit_reasons[rid] = []

            resource_to_visit_reasons[rid].append({
                "id": visit["id"],
                "name": visit["name"]
            })

    # ═══════════════════════════════════════════════════════════════
    # HYBRID APPROACH: Use location.location_resources as primary source
    # ═══════════════════════════════════════════════════════════════
    
    # Step 1: Find the target location and get its location_resources
    target_location = None
    location_resource_ids = set()
    
    for location in data.get("locations", []):
        if location.get("id") == location_id:
            target_location = location
            # Extract resource IDs from location_resources
            for loc_res in location.get("location_resources", []):
                rid = loc_res.get("id")
                if rid:
                    location_resource_ids.add(rid)
            break
    
    # Step 2: Build resource ID to resource object mapping
    resource_map = {}
    for item in data.get("resources", []):
        r = item["resource"]
        resource_map[r["id"]] = r
    
    # Step 3: Process resources that location lists in location_resources
    for resource_id in location_resource_ids:
        r = resource_map.get(resource_id)
        if not r:
            continue
        
        # ── FILTER 1: Only active resources ──
        if r.get("status") != "A":
            continue

        # ── FILTER 2: Build providers list (only ACTIVE and allowed) ──
        providers = []
        for p in r.get("resource_providers", []):
            pid = p["id"]
            
            # Skip if not in whitelist
            if ALLOWED_PROVIDER_IDS is not None and pid not in ALLOWED_PROVIDER_IDS:
                continue
            
            # Skip if provider is INACTIVE (not in provider_id_to_name mapping)
            # provider_id_to_name only contains active providers (status = "A")
            if pid not in provider_id_to_name:
                continue
            
            providers.append({
                "id": pid,
                "name": provider_id_to_name[pid]
            })

        # ── FILTER 3: Skip resource if no allowed providers found ──
        if not providers:
            continue

        # Filter by visit_reason_id if provided
        if visit_reason_id is not None:
            visit_reasons = resource_to_visit_reasons.get(r["id"], [])
            has_visit_reason = any(vr["id"] == visit_reason_id for vr in visit_reasons)
            if not has_visit_reason:
                continue

        # Determine if this resource is default at this location
        # Check the resource's resource_locations for is_default flag
        is_default_at_location = False
        for loc in r.get("resource_locations", []):
            if loc["id"] == location_id and loc.get("is_default"):
                is_default_at_location = True
                break

        entry = {
            "resource_id": r["id"],
            "resource_name": r["name"],
            "providers": providers
        }

        if is_default_at_location:
            default_resources.append(entry)
        else:
            alternative_resources.append(entry)
    
    # Step 4: FALLBACK - Check resources that have this location in resource_locations
    # but weren't in the location's location_resources list
    for item in data.get("resources", []):
        r = item["resource"]
        
        # Skip if already processed via location_resources
        if r["id"] in location_resource_ids:
            continue

        # ── FILTER 1: Only active resources ──
        if r.get("status") != "A":
            continue

        # Check if this resource has the target location
        has_location = False
        is_default_at_location = False
        for loc in r.get("resource_locations", []):
            if loc["id"] == location_id:
                has_location = True
                is_default_at_location = loc.get("is_default", False)
                break
        
        if not has_location:
            continue

        # ── FILTER 2: Build providers list (only ACTIVE and allowed) ──
        providers = []
        for p in r.get("resource_providers", []):
            pid = p["id"]
            
            # Skip if not in whitelist
            if ALLOWED_PROVIDER_IDS is not None and pid not in ALLOWED_PROVIDER_IDS:
                continue
            
            # Skip if provider is INACTIVE (not in provider_id_to_name mapping)
            # provider_id_to_name only contains active providers (status = "A")
            if pid not in provider_id_to_name:
                continue
            
            providers.append({
                "id": pid,
                "name": provider_id_to_name[pid]
            })

        # ── FILTER 3: Skip resource if no allowed providers found ──
        if not providers:
            continue

        # Filter by visit_reason_id if provided
        if visit_reason_id is not None:
            visit_reasons = resource_to_visit_reasons.get(r["id"], [])
            has_visit_reason = any(vr["id"] == visit_reason_id for vr in visit_reasons)
            if not has_visit_reason:
                continue

        entry = {
            "resource_id": r["id"],
            "resource_name": r["name"],
            "providers": providers
        }

        if is_default_at_location:
            default_resources.append(entry)
        else:
            alternative_resources.append(entry)

    # Final Output
    result = {
        "location_id": location_id,
        "default_resources": default_resources,
        "alternative_resources": alternative_resources
    }
    
    if visit_reason_id is not None:
        result["filtered_by_visit_reason_id"] = visit_reason_id
    
    return result


@function_tool
async def get_location_resources(
    location_id: int,
    provider_id: Optional[int] = None,
    visit_reason_id: Optional[int] = None,
    business_entity_data: Optional[str] = None,
    context: RunContext = None
) -> str:
    """
    Get resources at a location with their associated providers.
    This tool helps verify which resources are available at a specific location and which providers are associated with those resources.
    
    Args:
        location_id: Location ID to filter resources (REQUIRED)
        provider_id: Optional - Filter to show only resources associated with this provider
        visit_reason_id: Optional - If provided, only returns resources that support this visit reason
        business_entity_data: Optional - JSON string of business entity data. If not provided, will try to load from data.txt file
        
    Returns:
        JSON string containing:
        - location_id: The location ID queried
        - default_resources: List of default resources at this location with their providers
        - alternative_resources: List of alternative resources at this location with their providers
        - Each resource includes: resource_id, resource_name, and providers (with id and name)
    """
    try:
        data_dict = None
        
        # Try to get business entity data
        if business_entity_data:
            # Parse provided JSON string
            if isinstance(business_entity_data, str):
                data_dict = json.loads(business_entity_data)
            else:
                data_dict = business_entity_data
        else:
            # Try to load from data.txt file
            data_file = os.path.join(os.path.dirname(__file__), "data.txt")
            if os.path.exists(data_file):
                with open(data_file, "r", encoding="utf-8") as f:
                    data_dict = json.load(f)
            else:
                return "Error: Business entity data not provided and data.txt file not found. Please provide business_entity_data parameter or ensure data.txt exists."
        
        if not data_dict:
            return "Error: Could not load business entity data."
            
        # Call the main function
        result = get_location_resource_types_with_visits(
            data_dict, 
            location_id, 
            visit_reason_id
        )
        
        # If provider_id is specified, filter results to show only resources with that provider
        if provider_id is not None:
            filtered_default = []
            filtered_alternative = []
            
            for resource in result.get("default_resources", []):
                provider_ids = [p.get("id") for p in resource.get("providers", [])]
                if provider_id in provider_ids:
                    filtered_default.append(resource)
            
            for resource in result.get("alternative_resources", []):
                provider_ids = [p.get("id") for p in resource.get("providers", [])]
                if provider_id in provider_ids:
                    filtered_alternative.append(resource)
            
            result["default_resources"] = filtered_default
            result["alternative_resources"] = filtered_alternative
            result["filtered_by_provider_id"] = provider_id
        
        # Return as formatted JSON string
        return json.dumps(result, indent=2)
    except json.JSONDecodeError as e:
        return f"Error: Invalid JSON data - {str(e)}"
    except FileNotFoundError:
        return "Error: data.txt file not found. Please provide business_entity_data parameter."
    except Exception as e:
        return f"Error: {str(e)}"
