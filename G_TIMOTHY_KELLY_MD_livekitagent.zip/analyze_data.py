import json

with open("data.txt", "r") as f:
    data = json.load(f)

print("=" * 70)
print("DATA.TXT FILE STRUCTURE ANALYSIS")
print("=" * 70)

# Top-level keys
print("\n1. TOP-LEVEL KEYS:")
for key in data.keys():
    if isinstance(data[key], list):
        print(f"   - {key}: {len(data[key])} items")
    else:
        print(f"   - {key}: {data[key]}")

# Resources structure
print("\n2. RESOURCES STRUCTURE:")
if data.get("resources"):
    sample_resource = data["resources"][0]["resource"]
    print(f"   Total Resources: {len(data['resources'])}")
    print(f"   Sample Resource Keys: {list(sample_resource.keys())}")
    print(f"   Sample Resource ID: {sample_resource['id']}")
    print(f"   Sample Resource Name: {sample_resource['name']}")
    print(f"   Has resource_locations: {len(sample_resource.get('resource_locations', []))} locations")
    print(f"   Has resource_providers: {len(sample_resource.get('resource_providers', []))} providers")

# Nature of Visits structure
print("\n3. NATURE OF VISITS STRUCTURE:")
if data.get("nature_of_visits"):
    sample_visit = data["nature_of_visits"][0]["nature_of_visit"]
    print(f"   Total Visit Reasons: {len(data['nature_of_visits'])}")
    print(f"   Sample Visit Keys: {list(sample_visit.keys())}")
    print(f"   Sample Visit ID: {sample_visit['id']}")
    print(f"   Sample Visit Name: {sample_visit['name']}")
    print(f"   Has nature_of_visit_resources: {len(sample_visit.get('nature_of_visit_resources', []))} resources")
    
# Locations structure
print("\n4. LOCATIONS STRUCTURE:")
if data.get("locations"):
    sample_location = data["locations"][0]
    print(f"   Total Locations: {len(data['locations'])}")
    print(f"   Sample Location Keys: {list(sample_location.keys())}")
    print(f"   Sample Location ID: {sample_location['id']}")
    print(f"   Sample Location Name: {sample_location['name']}")

# Providers structure
print("\n5. PROVIDERS STRUCTURE:")
if data.get("providers"):
    sample_provider = data["providers"][0]
    print(f"   Total Providers: {len(data['providers'])}")
    print(f"   Sample Provider Keys: {list(sample_provider.keys())}")
    print(f"   Sample Provider ID: {sample_provider['id']}")
    print(f"   Sample Provider physician_id: {sample_provider.get('physician_id', 'N/A')}")

# Document Sources
print("\n6. DOCUMENT SOURCES:")
if data.get("document_sources"):
    print(f"   Total: {len(data['document_sources'])}")

# Transportations
print("\n7. TRANSPORTATIONS:")
if data.get("transportations"):
    print(f"   Total: {len(data['transportations'])}")

# Recall Types
print("\n8. RECALL TYPES:")
if data.get("recall_types"):
    print(f"   Total: {len(data['recall_types'])}")

# Patient Statuses
print("\n9. PATIENT STATUSES:")
if data.get("patient_statuses"):
    print(f"   Total: {len(data['patient_statuses'])}")

# Other Adjustment Reasons
print("\n10. OTHER ADJUSTMENT REASONS:")
if data.get("other_adjustment_reasons"):
    print(f"   Total: {len(data['other_adjustment_reasons'])}")

print("\n" + "=" * 70)
print("RELATIONSHIPS:")
print("=" * 70)
print("""
1. Resources ←→ Locations (Many-to-Many)
   - resource_locations field in resources
   
2. Resources ←→ Providers (Many-to-Many)
   - resource_providers field in resources
   
3. Nature of Visits ←→ Resources (Many-to-Many)
   - nature_of_visit_resources field in nature_of_visits
   
4. NO direct relationship between:
   - Nature of Visits ←→ Locations
   (Visit reasons are location-independent)
""")

print("=" * 70)
