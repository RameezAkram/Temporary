"""
Business Entity Data Fetcher
Fetches data from Business_entity tool and stores it in data.txt
"""

import json
import asyncio
from datetime import datetime
import os
import logging
from dotenv import load_dotenv

load_dotenv()

logger = logging.getLogger(__name__)


async def fetch_and_store_business_entity_data(mcp_server=None):
    """
    Fetch business entity data and store it in data.txt
    
    Args:
        mcp_server: MCP server instance to call Business_entity tool
        
    Returns:
        bool: True if successful, False otherwise
    """
    try:
        logger.info("🔄 Fetching business entity data...")
        
        # If MCP server provided, call the Business_entity tool
        if mcp_server:
            # First, list available tools to find the correct tool name
            available_tools = await mcp_server.list_tools()
            tool_names = [tool.name for tool in available_tools]
            logger.info(f"📋 Available MCP tools: {', '.join(tool_names)}")
            
            # Try different possible names for the business entity tool
            possible_names = ["Universal-Business-entity", "Business_entity", "Business-entity", "business_entity", "business-entity", "BusinessEntity"]
            tool_name = None
            
            for name in possible_names:
                if name in tool_names:
                    tool_name = name
                    break
            
            if not tool_name:
                logger.error(f"❌ Business entity tool not found. Available tools: {', '.join(tool_names)}")
                return False
            
            logger.info(f"✅ Found tool: {tool_name}")
            
            # Call Business_entity tool through MCP server
            # Use the same BUSINESS_ID as used for token refresh
            business_id = os.environ.get("BUSINESS_ID", "4944")
            user_profile_id = os.environ.get("USER_PROFILE_ID", "1320000")
            token = os.environ.get("CARECLOUD_BEARER_TOKEN", "")

            if not token:
                # read the ex_auth_token from the database as a fallback
                from db import execute_query
                query_result = execute_query("SELECT ex_auth_token FROM TokenTable WHERE business_entity = ?", [business_id])
                if query_result and len(query_result) > 0:
                    token = query_result[0].get("ex_auth_token", "")
                    logger.info(f"🔍 Fetched ex_auth_token from DB for business_entity={business_id} (length={len(token)})")
                else:
                    logger.warning(f"⚠️ No ex_auth_token found in DB for business_entity={business_id}")
            
            logger.info(f"🔍 DEBUG: Using business_entity_id: {business_id}")
            logger.info(f"🔍 DEBUG: Using user_profile_id: {user_profile_id}")
            logger.info(f"🔍 DEBUG: Token length: {len(token) if token else 0}")
            
            result = await mcp_server.call_tool(tool_name, {
                "web_token": token,
                "user_profile_id": user_profile_id,
                "business_entity_id": business_id
            })
            
            if result and hasattr(result, 'content') and len(result.content) > 0:
                # Extract data from MCP response (TextContent object)
                content_item = result.content[0]
                
                # Access the text attribute directly from TextContent
                response_text = content_item.text.strip()
                logger.info(f"🔍 Tool response: {response_text[:200]}...")  # Debug first 200 chars
                
                if not response_text:
                    logger.warning("⚠️ Empty response from Business_entity tool")
                    return False
                
                try:
                    business_data = json.loads(response_text)
                    logger.info(f"✅ Successfully parsed JSON from business entity data")
                except json.JSONDecodeError as e:
                    logger.warning(f"⚠️ Response is not valid JSON: {e}")
                    logger.warning(f"⚠️ Treating response as plain text and wrapping in dict")
                    business_data = {"raw_response": response_text}
                
                logger.info(f"🔍 Data type: {type(business_data)}")
                
                # Check if we got an error response
                if isinstance(business_data, dict) and business_data.get("raw_response", "").startswith("Error"):
                    logger.warning("⚠️ Business entity tool returned an error - creating minimal data structure")
                    # Create minimal data structure to allow agent to function
                    business_data = {
                        "locations": [],
                        "resources": [],
                        "providers": [],
                        "nature_of_visits": [],
                        "error": "Business entity not found - using dynamic tools instead"
                    }
                elif isinstance(business_data, list):
                    logger.info(f"🔍 Data is a list with {len(business_data)} items")
                    if len(business_data) > 0:
                        business_data = business_data[0]
                        logger.info(f"✅ Using first item from list")
                    else:
                        logger.warning("⚠️ Empty list returned from Business_entity tool")
                        business_data = {
                            "locations": [],
                            "resources": [],
                            "providers": [],
                            "nature_of_visits": [],
                            "error": "Empty response from business entity tool"
                        }
            else:
                logger.warning("⚠️ No data returned from Business_entity tool")
                return False
        else:
            # Fallback: If no MCP server, use existing data.txt
            logger.warning("⚠️ No MCP server provided, keeping existing data.txt")
            return False
        
        # Add metadata
        business_data['_metadata'] = {
            'last_updated': datetime.now().isoformat(),
            'source': 'Business_entity_tool',
            'version': '1.0'
        }
        
        # Store in data.txt
        with open("data.txt", "w") as f:
            json.dump(business_data, f, indent=4)
        
        logger.info(f"✅ Business entity data saved to data.txt")
        logger.info(f"   - Total locations: {len(business_data.get('locations', []))}")
        logger.info(f"   - Total resources: {len(business_data.get('resources', []))}")
        logger.info(f"   - Total providers: {len(business_data.get('providers', []))}")
        logger.info(f"   - Last updated: {business_data['_metadata']['last_updated']}")
        
        return True
        
    except Exception as e:
        logger.error(f"❌ Error fetching/storing business entity data: {e}")
        return False


async def get_business_entity_summary():
    """Get summary of stored business entity data"""
    try:
        if not os.path.exists("data.txt"):
            return "⚠️ No business entity data found"
        
        with open("data.txt", "r") as f:
            data = json.load(f)
        
        metadata = data.get('_metadata', {})
        last_updated = metadata.get('last_updated', 'Unknown')
        
        summary = f"""
📊 Business Entity Data Summary:
   - Locations: {len(data.get('locations', []))}
   - Resources: {len(data.get('resources', []))}
   - Providers: {len(data.get('providers', []))}
   - Visit Reasons: {len(data.get('nature_of_visits', []))}
   - Last Updated: {last_updated}
"""
        return summary
        
    except Exception as e:
        return f"❌ Error reading business entity data: {e}"


if __name__ == "__main__":
    # Test without MCP server (just shows summary)
    summary = asyncio.run(get_business_entity_summary())
    print(summary)
