import asyncio
import json
from dotenv import load_dotenv
import os
from mcp_client import MCPServerSse

# Load environment variables
load_dotenv()

MCP_SERVER_URL = os.getenv("N8N_MCP_SERVER_URL")

async def fetch_mcp_schema():
    """Fetch the schema of all tools from the N8N MCP server"""
    try:
        print(f"🔄 Connecting to MCP Server: {MCP_SERVER_URL}")
        
        # Create MCP SSE server instance
        mcp_server = MCPServerSse(
            params={"url": MCP_SERVER_URL},
            cache_tools_list=False,
            name="N8N MCP Server"
        )
        
        # Connect to the server
        await mcp_server.connect()
        print("✅ Connected successfully!\n")
        
        # Fetch tools list
        tools = await mcp_server.list_tools()
        print(f"📋 Found {len(tools)} tools:\n")
        
        # Convert tools to dict format
        tools_schema = []
        for tool in tools:
            tool_dict = {
                "name": tool.name,
                "description": tool.description,
                "inputSchema": tool.inputSchema
            }
            tools_schema.append(tool_dict)
            
            print(f"Tool: {tool.name}")
            print(f"Description: {tool.description}")
            print(f"Input Schema: {json.dumps(tool.inputSchema, indent=2)}")
            print("-" * 80)
        
        # Save to file
        with open("mcp_schema.json", "w") as f:
            json.dump(tools_schema, f, indent=2)
        print("\n✅ Schema saved to mcp_schema.json")
        
        # Cleanup
        await mcp_server.cleanup()
        return tools_schema
        
    except Exception as e:
        print(f"❌ Error: {str(e)}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(fetch_mcp_schema())
