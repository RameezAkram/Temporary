from difflib import SequenceMatcher
from typing import Optional


def fuzzy_match_payer(name: str, threshold: float = 0.4, state: Optional[str] = None) -> Optional[dict]:
    """
    Fuzzy match a name against the PAYER list and return the best match.
    Optionally filter by state before matching (e.g. state="GA").
    Also checks sender_number as a secondary match field.
    Returns the best matching payer dict (with id, name, sender_number, address, phone, score)
    or None if no match meets the threshold.
    """
    if not name:
        return None

    name_upper = name.upper().strip()
    best_match = None
    best_score = 0.0

    candidates = PAYER
    if state:
        state_upper = state.upper().strip()
        filtered = [p for p in PAYER if p.get("address", {}).get("state", "").upper() == state_upper]
        if filtered:
            candidates = filtered

    for payer in candidates:
        name_score = SequenceMatcher(None, name_upper, payer["name"].upper()).ratio()
        sender = payer.get("sender_number") or ""
        sender_score = SequenceMatcher(None, name_upper, sender.upper()).ratio() if sender else 0.0
        score = max(name_score, sender_score)
        if score > best_score:
            best_score = score
            best_match = payer

    if best_score >= threshold:
        return {**best_match, "score": round(best_score, 4)}
    return None


def fuzzy_match_insurance_policy_type(name: str, threshold: float = 0.4) -> Optional[dict]:
    """
    Fuzzy match a name against the INSURANCE_POLICY_TYPES list and return the best match.
    Matches against both the 'name' and 'code' fields.
    Returns the best matching policy type dict or None if no match meets the threshold.
    """
    if not name:
        return None

    name_upper = name.upper().strip()
    best_match = None
    best_score = 0.0

    for policy in INSURANCE_POLICY_TYPES:
        name_score = SequenceMatcher(None, name_upper, policy["name"].upper()).ratio()
        code_score = SequenceMatcher(None, name_upper, policy["code"].upper()).ratio()
        score = max(name_score, code_score)
        if score > best_score:
            best_score = score
            best_match = policy

    if best_score >= threshold:
        return {**best_match, "score": round(best_score, 4)}
    return None


PAYER = [
    {"id": "20853", "name": "100 CLUB OF ARIZONA", "sender_number": None, "address": {"line1": "333 N 44TH ST STE 100", "city": "PHOENIX", "state": "AZ", "zip": "850086603"}, "phone": "6024850100"},
    {"id": "22384", "name": "10 ROADS EXPRESS", "sender_number": None, "address": {"line1": "2200 ABBOTT DR", "city": "CARTER LAKE", "state": "IA", "zip": "515101551"}, "phone": "7083338400"},
    {"id": "15193", "name": "1199 J BEHAVIORAL HEALTH", "sender_number": None, "address": {"line1": "PO BOX 998", "city": "NEWARK", "state": "NJ", "zip": "071010998"}, "phone": "9732424450"},
    {"id": "9996", "name": "1199 NATIONAL BENEFIT FUND", "sender_number": "13162", "address": {"line1": "PO BOX 933", "city": "NEW YORK", "state": "NY", "zip": "10108-0933"}, "phone": "8888191199"},
    {"id": "6825", "name": "1199 NATIONAL BENEFIT FUND", "sender_number": "13162", "address": {"line1": "PO BOX 1007", "city": "NEW YORK", "state": "NY", "zip": "101081007"}, "phone": "6464737160"},
    {"id": "3457", "name": "1199 NATIONAL BENEFIT FUND", "sender_number": "13162", "address": {"line1": "PO BOX 1007", "city": "NEW YORK", "state": "NY", "zip": "10108-1007"}, "phone": "8888191199"},
    {"id": "10015", "name": "1 - 2 -1 CLAIMS", "sender_number": None, "address": {"line1": "PO BOX 2392", "city": "BOERNE", "state": "TX", "zip": "78006-6392"}, "phone": "2106956947"},
    {"id": "18951", "name": "1800MEDWRECKS LLC", "sender_number": None, "address": {"line1": "10440 N CENTRAL EXPY STE 400", "city": "DALLAS", "state": "TX", "zip": "752312228"}, "phone": "9723540997"},
    {"id": "19546", "name": "180 MEDICAL", "sender_number": None, "address": {"line1": "PO BOX 186", "city": "LA FONTAINE", "state": "IN", "zip": "469400186"}, "phone": "7652435180"},
    {"id": "5646", "name": "1 888 OHIOCOMP", "sender_number": None, "address": {"line1": "2900 CARNEGIE AVE", "city": "CLEVELAND", "state": "OH", "zip": "44115-2649"}, "phone": "8886446266"},
    {"id": "3496", "name": "1 BUC", "sender_number": None, "address": {"line1": "1 BUC PLACE", "city": "TAMPA", "state": "FL", "zip": "33607"}, "phone": "8135541319"},
    {"id": "20927", "name": "1 SOURCE", "sender_number": None, "address": {"line1": "1573 N CLINE AVE", "city": "GRIFFITH", "state": "IN", "zip": "463191567"}, "phone": "8555176872"},
    {"id": "11340", "name": "1ST CHOICE", "sender_number": None, "address": {"line1": "10591 LINCOLN HWY", "city": "EVERETT", "state": "PA", "zip": "155377047"}, "phone": "8887178090"},
    {"id": "8734", "name": "1ST MCO", "sender_number": None, "address": {"line1": "PO BOX 5967", "city": "PARSIPPANY", "state": "NJ", "zip": "07054-6967"}, "phone": "9732575218"},
    {"id": "9371", "name": "215 SURGERY CENTER", "sender_number": None, "address": {"line1": "6120 S FORT APACHE RD SUITE 200", "city": "LAS VEGAS", "state": "NV", "zip": "89148"}, "phone": "7029488894"},
    {"id": "3436", "name": "21ST CENTURY INSURANCE", "sender_number": None, "address": {"line1": "PO BOX 268994", "city": "OKLAHOMA CITY", "state": "OK", "zip": "731268994"}, "phone": "8882446163"},
    {"id": "2", "name": "21ST CENTURY INSURANCE GROUP", "sender_number": None, "address": {"line1": "PO BOX 2020", "city": "WOODLAND HILLS", "state": "CA", "zip": "91365-2020"}, "phone": "8002117283"},
    {"id": "22109", "name": "2210 SANTA ANA OPCO, LLC", "sender_number": None, "address": {"line1": "11440 VENTURA BLVDSTE 220", "city": "N HOLLYWOOD", "state": "CA", "zip": "91604"}, "phone": "8189856600"},
    {"id": "22944", "name": "22 HEALTH CLAIMS DEPARTMENT", "sender_number": "22HLT", "address": {"line1": "PO BOX 849029", "city": "HOLLYWOOD", "state": "FL", "zip": "330841029"}, "phone": "8002824548"},
    {"id": "17596", "name": "24/7 ATTORNEYS", "sender_number": None, "address": {"line1": "713 N EASTERN AVE", "city": "LAS VEGAS", "state": "NV", "zip": "891012821"}, "phone": "7029454500"},
    {"id": "19262", "name": "24TH STREET HEALTHCARE ASSOCIATES", "sender_number": None, "address": {"line1": "2509 N 24TH ST", "city": "PHOENIX", "state": "AZ", "zip": "850081805"}, "phone": "6022731347"},
    {"id": "10340", "name": "355th MEDICAL GROUP SGSB", "sender_number": None, "address": {"line1": "4175 S ALAMO AVE", "city": "TUCSON", "state": "AZ", "zip": "857074402"}, "phone": "5202282634"},
    {"id": "5597", "name": "3 HAB", "sender_number": "3HAB", "address": {"line1": "PO BOX 429540", "city": "CINCINNATI", "state": "OH", "zip": "45242-9540"}, "phone": "8008691871"},
    {"id": "12486", "name": "3HC Home Health & Hospice Care Inc", "sender_number": None, "address": {"line1": "2402 WAYNE MEMORIAL DR", "city": "GOLDSBORO", "state": "NC", "zip": "275341728"}, "phone": "9197351387"},
    {"id": "9105", "name": "3M SAFETY EYEWEAR", "sender_number": None, "address": {"line1": "PO BOX 844190", "city": "DALLAS", "state": "TX", "zip": "75284-4190"}, "phone": "8003281667"},
    {"id": "7587", "name": "44 NORTH", "sender_number": None, "address": {"line1": "PO BOX 700", "city": "CADILLAC", "state": "MI", "zip": "49601-0700"}, "phone": "8553061099"},
    {"id": "12522", "name": "59 HARRINGTON COURT OPERATIONS LLC", "sender_number": None, "address": {"line1": "59 HARRINGTON CT", "city": "COLCHESTER", "state": "CT", "zip": "064151207"}, "phone": "8605372339"},
    {"id": "22247", "name": "60 West", "sender_number": None, "address": {"line1": "60 WEST ST", "city": "ROCKY HILL", "state": "CT", "zip": "060673518"}, "phone": "8605290880"},
    {"id": "17358", "name": "655 TRANSPORTATION COMPANY", "sender_number": None, "address": {"line1": "5722 INTEGRITY DR BLD", "city": "MILLINGTON", "state": "TN", "zip": "38054"}, "phone": "9018724992"},
    {"id": "15179", "name": "6 DEGREES HEALTH INC", "sender_number": "20446", "address": {"line1": "PO BOX 271", "city": "ARNOLD", "state": "MD", "zip": "210120271"}, "phone": "8886156398"},
    {"id": "16433", "name": "702 HOSPICE CORP", "sender_number": None, "address": {"line1": "3305 SPRING MOUNTAIN RD STE 40", "city": "LAS VEGAS", "state": "NV", "zip": "891028622"}, "phone": "7025347840"},
    {"id": "21033", "name": "702 LAW FIRM", "sender_number": None, "address": {"line1": "8335 W FLAMINGO RD", "city": "LAS VEGAS", "state": "NV", "zip": "891474134"}, "phone": "7024107574"},
    {"id": "20225", "name": "90 DEGREE BENEFITS", "sender_number": "58102", "address": {"line1": "PO BOX 211348", "city": "EAGAN", "state": "MN", "zip": "551210306"}, "phone": "2038761660"},
    {"id": "21255", "name": "90 DEGREE BENEFITS", "sender_number": "58102", "address": {"line1": "PO BOX 71120", "city": "BOSSIER CITY", "state": "LA", "zip": "711711120"}, "phone": "2287622500"},
    {"id": "21257", "name": "90 DEGREE BENEFITS", "sender_number": "58102", "address": {"line1": "PO BOX 71120", "city": "BOSSIER CITY", "state": "LA", "zip": "711711120"}, "phone": "2287622500"},
    {"id": "8168", "name": "90 DEGREE BENEFITS", "sender_number": "36878", "address": {"line1": "22322 GRAND CORNER DR STE 200", "city": "KATY", "state": "TX", "zip": "77494-5941"}, "phone": "8004368787"},
    {"id": "5118", "name": "90 DEGREE BENEFITS", "sender_number": "CAPHP", "address": {"line1": "PO BOX 21548", "city": "EAGAN", "state": "MN", "zip": "55121-0548"}, "phone": "9802210122"},
    {"id": "920", "name": "90 DEGREES BENEFITS", "sender_number": "58102", "address": {"line1": "PO BOX 105738", "city": "ATLANTA", "state": "GA", "zip": "30348-5738"}, "phone": "8006808728"},
    {"id": "22797", "name": "91ST AVENUE OPERATIONS LLC", "sender_number": None, "address": {"line1": "3000 N 91ST AVE", "city": "PHOENIX", "state": "AZ", "zip": "850374037"}, "phone": "6233032882"},
    {"id": "19631", "name": "AAA", "sender_number": "E3748", "address": {"line1": "2650 CARPENTER RD", "city": "ANN ARBOR", "state": "MI", "zip": "481081108"}, "phone": "7348445002"},
    {"id": "5207", "name": "AAA", "sender_number": "E3748", "address": {"line1": "PO BOX 24523", "city": "OAKLAND", "state": "CA", "zip": "94623-1523"}, "phone": "8002073618"},
    {"id": "5586", "name": "AAA", "sender_number": "E3748", "address": {"line1": "1 AUTO CLUB DR", "city": "DEARBORN", "state": "MI", "zip": "48126-4213"}, "phone": "8002226424"},
    {"id": "14020", "name": "AAA", "sender_number": "E3748", "address": {"line1": "PO BOX 24524", "city": "OAKLAND", "state": "CA", "zip": "946231524"}, "phone": "8002073618"},
    {"id": "5038", "name": "AAA", "sender_number": "E3748", "address": {"line1": "25510 W 11 MILE RD", "city": "SOUTHFIELD", "state": "MI", "zip": "48034-2261"}, "phone": "2484236350"},
    {"id": "19634", "name": "AAA", "sender_number": None, "address": {"line1": "PO BOX 7000", "city": "DAPHNE", "state": "AL", "zip": "365265070"}, "phone": "8889809422"},
    {"id": "15394", "name": "AAA", "sender_number": "E3748", "address": {"line1": "10501 MONTGOMERY BLVD. NE", "city": "ALBUQUERQUE", "state": "NM", "zip": "87111"}, "phone": "5052916643"},
    {"id": "16702", "name": "AAA", "sender_number": "E3748", "address": {"line1": "100 W 5TH AVE", "city": "KNOXVILLE", "state": "TN", "zip": "379177448"}, "phone": "4704366250"},
    {"id": "7478", "name": "AAA", "sender_number": "E3748", "address": {"line1": "975 MERIDIAN LAKE DR", "city": "AURORA", "state": "IL", "zip": "60504"}, "phone": "6303287043"},
    {"id": "19048", "name": "AAA", "sender_number": "E3748", "address": {"line1": "PO BOX 25210", "city": "SANTA ANA", "state": "CA", "zip": "927995210"}, "phone": "6612913832"},
    {"id": "3342", "name": "AAA AUTO CLUB", "sender_number": None, "address": {"line1": "PO BOX 31107", "city": "TAMPA", "state": "FL", "zip": "33631-3107"}, "phone": "8002891325"},
]


INSURANCE_POLICY_TYPES = [
    {"id": "1", "name": "Attorney", "code": "ATT"},
    {"id": "2", "name": "Auto Insurance", "code": "AUI"},
    {"id": "3", "name": "Champus", "code": "CHM"},
    {"id": "4", "name": "ChampVA", "code": "CHV"},
    {"id": "5", "name": "Indemnity Insurance", "code": "CID"},
    {"id": "6", "name": "Flat Fee Arrangement", "code": "FFA"},
    {"id": "7", "name": "HMO", "code": "HMO"},
    {"id": "8", "name": "Medicaid", "code": "MDC"},
    {"id": "9", "name": "Medicaid HMO", "code": "MDH"},
    {"id": "10", "name": "Medicaid Newborn", "code": "MDN"},
    {"id": "11", "name": "MEDICARE B", "code": "MCA"},
    {"id": "12", "name": "Medicare HMO", "code": "MCH"},
    {"id": "13", "name": "Medicare Railroad", "code": "MCR"},
    {"id": "14", "name": "Medicare Supplement", "code": "MCS"},
    {"id": "15", "name": "Medikids", "code": "MDK"},
    {"id": "16", "name": "Medipass or PSN", "code": "MDP"},
    {"id": "17", "name": "POS", "code": "POS"},
    {"id": "18", "name": "PPO", "code": "PPO"},
    {"id": "19", "name": "Workers Compensation", "code": "WCO"},
    {"id": "20", "name": "Choice Plus", "code": "CHP"},
    {"id": "21", "name": "Choice EPO", "code": "CEP"},
    {"id": "22", "name": "Capitation", "code": "CAP"},
    {"id": "23", "name": "Open Access", "code": "OAC"},
    {"id": "24", "name": "Medicare PPO", "code": "MPP"},
    {"id": "25", "name": "Healthy Kids", "code": "HKD"},
    {"id": "26", "name": "Blue Cross Blue Shield", "code": "BCB"},
    {"id": "27", "name": "Exclusive Provider Organization (EPO)", "code": "EPO"},
    {"id": "28", "name": "Commercial Insurance", "code": "CIC"},
    {"id": "29", "name": "Federal Employees Program", "code": "FIP"},
    {"id": "30", "name": "OTHER FEDERAL PROGRAM", "code": "OFP"},
    {"id": "31", "name": "MEDICARE A", "code": "MA"},
    {"id": "33", "name": "MUTUALLY DEFINED", "code": "ZZ"},
    {"id": "34", "name": "MEDICARE POS", "code": "MPOS"},
    {"id": "35", "name": "HMO MEDICARE RISK", "code": "HMR"},
    {"id": "36", "name": "OUT OF STATE", "code": "OST"},
    {"id": "44", "name": "VISION POLICY", "code": "VPP"},
    {"id": "73", "name": "OTHER NON-FEDERAL PROGRAMS", "code": "ONF"},
]