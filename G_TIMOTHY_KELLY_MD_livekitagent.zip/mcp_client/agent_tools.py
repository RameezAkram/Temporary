import asyncio
import logging
import json
import inspect
import traceback
import typing
import os
from datetime import datetime, timedelta, timezone, date
from zoneinfo import ZoneInfo
from typing import Any, List, Dict, Callable, Optional, Awaitable, Sequence, Tuple, Type, Union, cast
from uuid import uuid4

# Import from the MCP module
from .util import MCPUtil, FunctionTool
from .server import MCPServer, MCPServerSse
from livekit.agents import ChatContext, AgentSession, JobContext, FunctionTool as Tool
from mcp import CallToolRequest

logger = logging.getLogger("mcp-agent-tools")

# Agent session reference — set by agent.py after AgentSession creation.
# Used by the thinking-feedback timer to say "One moment please" on long tool calls.
_agent_session: Optional[Any] = None


def set_agent_session(session) -> None:
    """Set the AgentSession reference so tool wrappers can provide verbal feedback."""
    global _agent_session
    _agent_session = session


# Stores the FINAL (post-fuzzy-matched) kwargs for each tool name.
# Keyed by tool name; agent.py reads this after function_tools_executed fires
# so the transcript shows the real resolved values, not the raw LLM args.
_processed_kwargs_store: Dict[str, dict] = {}

# In-flight deduplication for create_appointment.
# Maps a parameter-fingerprint → asyncio.Future that resolves to the result string.
# If the LLM fires a second identical call before the first returns, the second
# caller awaits the same Future and gets the same response — preventing double-booking.
_inflight_create_appointment: Dict[str, "asyncio.Future[str]"] = {}

# ── Pacific-Time Slot Mapping ─────────────────────────────────────────────────
# When Available_time_slots returns slots, we convert start/end times to Pacific
# before feeding them to the LLM.  This dict maps every Pacific ISO string back
# to the original ISO string (same instant, original UTC offset e.g. -05:00).
# On create_appointment, start_time/end_time are looked up here so the API
# always receives times in the exact same format it originally provided.
_pacific_to_original_slot: Dict[str, str] = {}

# Stores verified patient data from Patient_Verification.
# Populated after a successful verification; auto-injected into
# create_appointment, get_appointments_list, Cancel_Appointment, etc.
# Keys: patient_id (int), patient_external_id (str/UUID), name (str)
_verified_patient: Dict[str, Any] = {}

# Per-service auth-failure counters (reset each call in clear_session_state).
# When >= 1, the pre-emptive guard in tool_impl skips the HTTP call entirely
# and returns a terminal LLM instruction to call transfer_to_human().
_companion_auth_fail_count: int = 0
_carecloud_auth_fail_count: int = 0

_PACIFIC_TZ = ZoneInfo("America/Los_Angeles")


def clear_session_state() -> None:
    """Reset all per-call module-level state.

    Must be called at the start of every new call so that data from a
    previous caller (patient IDs, slot mappings, in-flight guards, etc.)
    never leaks into the next session.
    """
    _processed_kwargs_store.clear()
    _inflight_create_appointment.clear()
    _pacific_to_original_slot.clear()
    _verified_patient.clear()
    global _companion_auth_fail_count, _carecloud_auth_fail_count
    _companion_auth_fail_count = 0
    _carecloud_auth_fail_count = 0
    logger.info("SESSION STATE CLEARED: all per-call caches reset")


def reset_auth_fail_count(service: str) -> None:
    """Reset the auth-failure counter for a service after a successful token refresh.

    Called by token_refresh_service when the LLM-initiated refresh succeeds so the
    pre-emptive guard allows the subsequent tool retry through.

    Args:
        service: "companion" or "carecloud"
    """
    global _companion_auth_fail_count, _carecloud_auth_fail_count
    if service == "companion":
        _companion_auth_fail_count = 0
        logger.info("[AUTH] Companion auth-fail counter reset after successful refresh")
    elif service == "carecloud":
        _carecloud_auth_fail_count = 0
        logger.info("[AUTH] CareCloud auth-fail counter reset after successful refresh")


def _to_pacific(iso_string: str) -> str:
    """Convert any ISO-8601 timestamp to America/Los_Angeles (PST/PDT)."""
    dt = datetime.fromisoformat(iso_string)
    return dt.astimezone(_PACIFIC_TZ).isoformat()


def _tz_label(iso_string: str) -> str:
    """Return a human-readable timezone label for an ISO string (e.g. 'EST (-05:00)')."""
    dt = datetime.fromisoformat(iso_string)
    offset_hours = dt.utcoffset().total_seconds() / 3600
    labels = {-4.0: "EDT", -5.0: "EST", -7.0: "PDT", -8.0: "PST"}
    abbr = labels.get(offset_hours, f"UTC{int(offset_hours):+d}")
    mins = int(abs(dt.utcoffset().total_seconds()) % 60)
    offset_str = f"{int(offset_hours):+03d}:{mins:02d}"
    return f"{abbr} ({offset_str})"


def _convert_slots_to_pacific(raw_result: str) -> str:
    """
    Parse Available_time_slots JSON, convert every slot start_time/end_time
    to Pacific Time, register the reverse mapping, and return the modified JSON.
    Works whether the API returns a list or a dict with a 'slots' key.
    """
    try:
        data = json.loads(raw_result)
    except Exception:
        return raw_result  # not JSON — return as-is

    def _overlaps_lunch(pac_start: str, pac_end: str) -> bool:
        """
        Return True if the slot STARTS inside the lunch window [12:00, 13:00) PT.
        Slots that start before noon are kept even if they end after noon
        (e.g. 11:45–12:15 is offered; 12:00–12:30 is not).
        A slot starting exactly at 13:00 is kept (break ends at 1 PM).
        """
        try:
            s = datetime.fromisoformat(pac_start)
            return s.hour == 12
        except Exception:
            return False

    def _after_closing_time(pac_start: str) -> bool:
        """
        Return True if the slot START exceeds the daily office closing cutoff (PT).
        Cutoffs are the last *allowed* start times per provider schedule:
          Mon–Thu : last start = 3:15 PM  → drop slots starting at 3:30 PM or later
          Friday  : last start = 3:00 PM  → drop slots starting at 3:15 PM or later
          Sat/Sun : practice closed        → drop all slots
        """
        try:
            s = datetime.fromisoformat(pac_start)
            wd = s.weekday()  # 0=Mon … 6=Sun
            hm = (s.hour, s.minute)
            if wd in (5, 6):          # Sat / Sun — practice closed
                return True
            if wd == 4:               # Friday: cutoff after 3:00 PM
                return hm > (15, 0)
            return hm > (15, 15)      # Mon–Thu: cutoff after 3:15 PM
        except Exception:
            return False

    def _process_slot_list(slots: list) -> list:
        converted = []
        filtered_lunch = 0
        filtered_closing = 0
        for slot in slots:
            raw_start = slot.get("start_time", "")
            raw_end   = slot.get("end_time", "")
            if not raw_start:
                converted.append(slot)
                continue
            pac_start = _to_pacific(raw_start)
            pac_end   = _to_pacific(raw_end) if raw_end else ""

            # Drop any slot whose time window overlaps with the lunch break
            # [12:00, 13:00) Pacific Time.  This includes slots that start
            # before noon but end inside the break (e.g. 11:45–12:15).
            if _overlaps_lunch(pac_start, pac_end):
                filtered_lunch += 1
                continue

            # Drop any slot whose start time is past the daily closing cutoff.
            # Mon–Thu last start: 3:15 PM PT; Friday last start: 3:00 PM PT.
            if _after_closing_time(pac_start):
                filtered_closing += 1
                continue

            # Register both directions in the map
            _pacific_to_original_slot[pac_start] = raw_start
            if raw_end:
                _pacific_to_original_slot[pac_end] = raw_end
            new_slot = dict(slot)
            new_slot["start_time"] = pac_start
            new_slot["end_time"]   = pac_end
            # Surface the original timezone label so LLM can mention it if needed
            new_slot["_original_tz"] = _tz_label(raw_start)
            converted.append(new_slot)
        if filtered_lunch:
            logger.info(f"LUNCH FILTER: removed {filtered_lunch} lunch slot(s) [12:00–13:00 PT]")
        if filtered_closing:
            logger.info(f"CLOSING FILTER: removed {filtered_closing} slot(s) past daily cutoff (Mon–Thu >3:15 PM / Fri >3:00 PM PT)")
        return converted

    # Case 1: list of availability groups  [{"slots": [...], ...}, ...]
    if isinstance(data, list):
        for group in data:
            if isinstance(group, dict) and "slots" in group:
                group["slots"] = _process_slot_list(group["slots"])
        return json.dumps(data)

    # Case 2: single dict with "slots" key  {"slots": [...], ...}
    if isinstance(data, dict) and "slots" in data:
        data["slots"] = _process_slot_list(data["slots"])
        return json.dumps(data)

    # Case 3: bare list of slot objects  [{"start_time": ..., "end_time": ...}, ...]
    if isinstance(data, list) and data and "start_time" in data[0]:
        return json.dumps(_process_slot_list(data))

    return raw_result  # unknown structure — return unchanged


_HUMAN_AGENT_SIP = "sip:8817023415444@10.10.30.39:5160;user=phone"


def create_transfer_to_human_tool(ctx, session):
    """
    Factory that creates and returns a decorated transfer_to_human function_tool.
    Must be called after ctx.connect() so that ctx.room is available.

    Args:
        ctx:     LiveKit JobContext (provides ctx.room after connect)
        session: LiveKit AgentSession (used to speak the transfer phrase)

    Returns:
        A @function_tool-decorated async callable ready to append to agent._tools.
    """
    from livekit.agents.llm import function_tool

    # Ensures the "connecting to office" announcement is spoken exactly once
    # per call, even if the LLM invokes the tool multiple times.
    _announced = {"flag": False}

    @function_tool
    async def transfer_to_human(reason: str, call_summary: str = "") -> str:
        """Transfer the caller to a live human agent at the front desk.
        Call this tool whenever:
        - Any API error, timeout, 502, or unexpected failure occurs
        - Patient cannot be verified or is not found in the system
        - Any booking, rescheduling, or cancellation fails
        - The patient asks to speak with a human or the front desk
        - The patient is new (never been seen before)
        AFTER CALLING: STOP immediately — do NOT say anything further."""
        from livekit import api as _lk_api_mod
        from livekit.api import LiveKitAPI

        logger.info(f"[HUMAN TRANSFER] Initiating transfer. Reason: {reason}")

        try:
            room = ctx.room
            participants = list(room.remote_participants.values())
            if not participants:
                logger.error("[HUMAN TRANSFER] No remote participants found")
                return "Transfer failed: no participants in room."

            SIP_KIND = 3
            sip_participant = None
            for p in participants:
                if p.kind == SIP_KIND or p.identity.startswith("sip_"):
                    sip_participant = p
                    break

            if not sip_participant:
                sip_participant = participants[0]
                logger.warning(
                    f"[HUMAN TRANSFER] No SIP participant found, using: {sip_participant.identity}"
                )

            # Speak the transfer announcement exactly once before connecting.
            if not _announced["flag"]:
                _announced["flag"] = True
                try:
                    await session.say("Let me connect you with the office.", allow_interruptions=False)
                except Exception as _say_err:
                    logger.warning(f"[HUMAN TRANSFER] say() failed (non-fatal): {_say_err}")
            await asyncio.sleep(0.5)  # brief pause to let the phrase finish playing

            logger.info(
                f"[HUMAN TRANSFER] Transferring {sip_participant.identity} to {_HUMAN_AGENT_SIP}"
            )

            lk = LiveKitAPI()
            transfer_req = _lk_api_mod.TransferSIPParticipantRequest(
                room_name=room.name,
                participant_identity=sip_participant.identity,
                transfer_to=_HUMAN_AGENT_SIP,
            )
            try:
                await lk.sip.transfer_sip_participant(transfer_req)
            finally:
                try:
                    await lk.aclose()
                except Exception:
                    pass

            logger.info("[HUMAN TRANSFER] Transfer initiated successfully")
            return "[TRANSFER_COMPLETE_REMAIN_SILENT]"

        except Exception as _e:
            logger.error(f"[HUMAN TRANSFER ERROR] {_e}\n{traceback.format_exc()}")
            return "Transfer failed. Please ask the patient to hold or call back."

    return transfer_to_human


class MCPToolsIntegration:
    """
    Helper class for integrating MCP tools with LiveKit agents.
    Provides utilities for registering custom tools from MCP servers.
    """

    @staticmethod
    async def prepare_dynamic_tools(mcp_servers: List[MCPServer],
                                   convert_schemas_to_strict: bool = True,
                                   auto_connect: bool = True) -> List[Callable]:
        """
        Fetches tools from multiple MCP servers and prepares them for use with LiveKit agents.

        Args:
            mcp_servers: List of MCPServer instances
            convert_schemas_to_strict: Whether to convert JSON schemas to strict format
            auto_connect: Whether to automatically connect to servers if they're not connected

        Returns:
            List of decorated tool functions ready to be added to a LiveKit agent
        """
        prepared_tools = []

        # Ensure all servers are connected if auto_connect is True
        if auto_connect:
            for server in mcp_servers:
                if not getattr(server, 'connected', False):
                    try:
                        logger.debug(f"Auto-connecting to MCP server: {server.name}")
                        await server.connect()
                    except Exception as e:
                        logger.error(f"Failed to connect to MCP server {server.name}: {e}")

        # Process each server
        for server in mcp_servers:
            logger.info(f"Fetching tools from MCP server: {server.name}")
            try:
                mcp_tools = await MCPUtil.get_function_tools(
                    server, convert_schemas_to_strict=convert_schemas_to_strict
                )
                logger.info(f"Received {len(mcp_tools)} tools from {server.name}")
            except Exception as e:
                logger.error(f"Failed to fetch tools from {server.name}: {e}")
                continue

            # Process each tool from this server
            for tool_instance in mcp_tools:
                # BUGFIX: Skip the MCP Locations tool because it only returns names, not IDs.
                # Use the local get_available_locations() tool from tools.py instead, which returns
                # complete location data including IDs, names, addresses, etc.
                if tool_instance.name == 'Locations':
                    logger.info(f"⚠️ Skipping broken MCP 'Locations' tool (returns names only, no IDs). Using local get_available_locations() instead.")
                    continue
                
                try:
                    decorated_tool = MCPToolsIntegration._create_decorated_tool(tool_instance)
                    prepared_tools.append(decorated_tool)
                    logger.debug(f"Successfully prepared tool: {tool_instance.name}")
                except Exception as e:
                    logger.error(f"Failed to prepare tool '{tool_instance.name}': {e}")

        return prepared_tools

    @staticmethod
    def _create_decorated_tool(tool: FunctionTool) -> Callable:
        """
        Creates a decorated function for a single MCP tool that can be used with LiveKit agents.

        Args:
            tool: The FunctionTool instance to convert

        Returns:
            A decorated async function that can be added to a LiveKit agent's tools
        """
        # Get function_tool decorator from LiveKit
        # Import locally to avoid circular imports
        from livekit.agents.llm import function_tool

        # Create parameters list from JSON schema
        params = []
        annotations = {}
        schema_props = tool.params_json_schema.get("properties", {})
        schema_required = set(tool.params_json_schema.get("required", []))
        type_map = {
            "string": str, "integer": int, "number": float,
            "boolean": bool, "array": list, "object": dict,
        }

        # For create_insurance, fields resolved by fuzzy matching must be optional so that
        # LiveKit's argument validator doesn't crash when the LLM sends null for them.
        # The pre-processing block inside tool_impl will fill them in before the API call.
        if tool.name == 'create_insurance':
            FUZZY_RESOLVED_FIELDS = {
                'payer_id', 'payer_name', 'line1', 'city', 'zip_code', 'payer_phone_number',
                'insurance_policy_type_id', 'insurance_policy_type_name', 'insurance_policy_type_code',
            }
            schema_required = schema_required - FUZZY_RESOLVED_FIELDS

        # ── Token lists ────────────────────────────────────────────────────────────
        # web_token is always auto-injected from env — the LLM never needs to supply it.
        # CareCloud tools  → CARECLOUD_BEARER_TOKEN
        # Companion tools  → COMPANION_TOKEN
        # Routing sets imported from single authoritative source in token_refresh_service.
        from token_refresh_service import CARECLOUD_TOOLS, COMPANION_TOOLS
        ALL_TOKEN_TOOLS = CARECLOUD_TOOLS | COMPANION_TOOLS
        if tool.name in ALL_TOKEN_TOOLS:
            schema_required = schema_required - {'web_token'}
        # ──────────────────────────────────────────────────────────────────────────

        # Build parameters from the schema properties.
        # IMPORTANT (Python 3.14 compat): typing.get_type_hints() fails on **kwargs closures
        # when annotations contain Union / Optional / typing.Any — it silently drops them,
        # causing KeyError in LiveKit's schema builder.  We therefore use ONLY simple builtin
        # types (str, int, float, bool, list, dict) so that get_type_hints() always succeeds.
        # Runtime type coercion (int→str for IDs, None for optional fields) is handled inside
        # tool_impl itself, so schema precision is not required here.
        for p_name, p_details in schema_props.items():
            json_type = p_details.get("type", "string")
            # Map JSON types to simple builtins only — no Union/Optional/Any
            _simple_type_map = {
                "string": str, "integer": int, "number": float,
                "boolean": bool, "array": list, "object": dict,
            }
            py_type = _simple_type_map.get(json_type, str)

            # For singular *_id fields (e.g. location_id, resource_id, provider_id):
            # annotate as int so pydantic v2 accepts the integers the LLM always sends.
            # The AUTO-FIX block inside tool_impl converts int → str before the MCP call.
            # Array *_ids fields (resource_ids, location_ids) keep their list annotation.
            #
            # EXCEPTION: Cancel_Appointment.appointment_id is a UUID string (not an int).
            # Annotating it as int causes pydantic to reject the UUID — keep it as str.
            _UUID_ID_PARAMS = {('Cancel_Appointment', 'appointment_id')}
            if (p_name.endswith('_id') and json_type in ('string', 'integer', 'number')
                    and (tool.name, p_name) not in _UUID_ID_PARAMS):
                py_type = int

            # web_token: keep it in the schema as an OPTIONAL str with default "".
            # Completely excluding it (via continue) caused "Received tool input did not
            # match expected schema" errors in prolonged conversations: after seeing
            # web_token in earlier tool results the LLM starts including it in subsequent
            # function calls, and LiveKit's strict validator then rejects those calls
            # before tool_impl even runs.  By keeping web_token in the schema (optional,
            # default "") we accept whatever the LLM sends — tool_impl always overwrites
            # the value from env vars anyway, so LLM-supplied tokens are never used.
            if tool.name in ALL_TOKEN_TOOLS and p_name == 'web_token':
                annotations[p_name] = str
                params.append(inspect.Parameter(
                    name=p_name,
                    kind=inspect.Parameter.KEYWORD_ONLY,
                    annotation=str,
                    default="",   # always optional; overwritten by token-injection block below
                ))
                continue

            annotations[p_name] = py_type

            # Use inspect.Parameter.empty for required params, None otherwise
            default = inspect.Parameter.empty if p_name in schema_required else p_details.get("default", None)
            params.append(inspect.Parameter(
                name=p_name,
                kind=inspect.Parameter.KEYWORD_ONLY,
                annotation=py_type,
                default=default
            ))

        # Define the actual function that will be called by the agent
        async def tool_impl(**kwargs):
            global _companion_auth_fail_count, _carecloud_auth_fail_count
            # SAFETY NET: Strip any kwargs that are NOT in the tool's MCP schema.
            # In long conversations the LLM occasionally hallucinates extra parameters
            # (e.g. web_token, user_profile_id) that aren't in the declared schema.
            # Removing them here prevents downstream validation or API errors.
            # web_token is always re-injected from env vars a few lines below, so
            # stripping a LLM-supplied web_token here is intentional and safe.
            _allowed = set(schema_props.keys())
            _extra = [k for k in list(kwargs.keys()) if k not in _allowed]
            for _k in _extra:
                logger.warning(
                    f"HALLUCINATED PARAM STRIPPED: tool='{tool.name}' "
                    f"param='{_k}' value='{kwargs[_k]}' (not in schema)"
                )
                del kwargs[_k]

            # AUTO-FIX: Convert integer IDs to strings (OpenAI sends ints, MCP expects strings)
            for key, value in kwargs.items():
                if key.endswith('_id') or key.endswith('_ids'):
                    if isinstance(value, int):
                        kwargs[key] = str(value)
                        logger.debug(f"AUTO-FIX: Converted {key} from int {value} to string '{value}'")
            
            # VALIDATION: Ensure IDs are real values, not placeholders
            import re
            placeholder_words = ['xxx', 'placeholder', 'unknown', 'tbd', 'n/a', 'temp', 'test']
            for key, value in kwargs.items():
                if key.endswith('_id') or key.endswith('_ids'):
                    if isinstance(value, str):
                        value_lower = value.lower().strip()
                        
                        # Check for placeholder words
                        if any(word in value_lower for word in placeholder_words):
                            error_msg = f"""❌ INVALID {key}: "{value}"

This appears to be a placeholder value, not a real ID.

🚨 CRITICAL: NEVER assume or make up IDs!
✅ Always use actual IDs from tool responses
✅ Extract IDs from previous API calls
✅ Ask user to select from available options

If you don't have the real {key}, call the appropriate tool to get it first."""
                            logger.error(f"VALIDATION FAILED: Placeholder/fake value detected for {key}: {value}")
                            return error_msg
                        
                        # Check if ID is all repeating digits (e.g., "0000", "1111", "9999")
                        if value.isdigit() and len(set(value)) == 1 and len(value) >= 3:
                            error_msg = f"""❌ INVALID {key}: "{value}"

This appears to be a placeholder value (repeating digits), not a real ID.

🚨 CRITICAL: NEVER assume or make up IDs!
✅ Always use actual IDs from tool responses
✅ Extract IDs from previous API calls
✅ Ask user to select from available options

If you don't have the real {key}, call the appropriate tool to get it first."""
                            logger.error(f"VALIDATION FAILED: Placeholder/fake value detected for {key}: {value}")
                            return error_msg
            
            # PRE-PROCESS: Patient_Verification — sanitize search_term
            # Strip all special characters (periods, commas, apostrophes, hyphens, etc.)
            # from the patient name before sending to the API.  The API only needs
            # plain alphabetic tokens separated by a single space (format: "FirstName LastName").
            # Example: "A.I. Agent" → "AI Agent"
            if tool.name == 'Patient_Verification' and 'search_term' in kwargs:
                raw_search = kwargs['search_term']
                # Remove every character that is not a letter, digit, or whitespace
                import re as _re
                cleaned = _re.sub(r'[^A-Za-z0-9\s]', '', raw_search)
                # Collapse multiple consecutive spaces into one and strip leading/trailing
                cleaned = ' '.join(cleaned.split())
                if cleaned != raw_search:
                    logger.info(
                        f"Patient_Verification search_term sanitized: "
                        f"'{raw_search}' → '{cleaned}'"
                    )
                kwargs['search_term'] = cleaned

            # Guard: ensure patient_id is provided and valid for appointment creation
            if tool.name in ['universal_create_appointment', 'Universal_create_appointment', 'create_appointment']:
                user_profile_env = os.environ.get('USER_PROFILE_ID', '25819082').strip()
                patient_id_val = kwargs.get('patient_id')
                stored_pid = _verified_patient.get('patient_id')

                # AUTO-FIX: If patient_id is missing or equals user_profile_id,
                # replace it with the stored verified patient_id.
                _needs_fix = (
                    patient_id_val is None
                    or (isinstance(patient_id_val, str) and patient_id_val.strip() == "")
                    or (user_profile_env and str(patient_id_val).strip() == user_profile_env)
                )
                if _needs_fix and stored_pid:
                    logger.warning(
                        f"AUTO-FIX patient_id: LLM sent '{patient_id_val}' "
                        f"→ replacing with verified patient_id '{stored_pid}'"
                    )
                    kwargs['patient_id'] = stored_pid
                elif _needs_fix:
                    # No stored patient — cannot auto-fix
                    if patient_id_val is None or (isinstance(patient_id_val, str) and patient_id_val.strip() == ""):
                        return "❌ Missing patient_id. Use the verified patient_id from Patient_Verification before booking."
                    return "❌ patient_id must be the verified patient ID, not user_profile_id. Please select a patient from verification results."

            # Apply date validation for create_appointment to prevent past date bookings
            if tool.name == 'create_appointment':
                # Check if start_time is in the past
                if 'start_time' in kwargs:
                    start_time_str = kwargs['start_time']
                    try:
                        # Parse the start_time (handle both -05:00 and Z formats)
                        if start_time_str.endswith('Z'):
                            start_dt = datetime.fromisoformat(start_time_str.replace('Z', '+00:00'))
                        else:
                            start_dt = datetime.fromisoformat(start_time_str)
                        
                        # Get current time in UTC
                        now_utc = datetime.now(timezone.utc)
                        
                        # Compare dates (ignoring timezone for date comparison)
                        start_date = start_dt.date()
                        today = now_utc.date()
                        
                        if start_date < today:
                            error_msg = f"❌ Cannot book appointment on {start_date.strftime('%B %d, %Y')}. This date is in the past. Please choose a date from today onwards."
                            logger.error(f"VALIDATION FAILED: Attempted to book appointment on past date: {start_date}")
                            return error_msg
                        
                        logger.info(f"DATE VALIDATION: Appointment date {start_date} is valid (today or future)")
                    except Exception as date_error:
                        logger.warning(f"Could not parse date for validation: {date_error}")
                        # Continue with booking if date parsing fails
            
            # AUTO-FIX: Available_time_slots requires 'nature_of_visit_id' but the LLM
            # sometimes sends 'visit_reason_id' — rename it transparently before validation.
            if tool.name == 'Available_time_slots' and 'visit_reason_id' in kwargs and 'nature_of_visit_id' not in kwargs:
                kwargs['nature_of_visit_id'] = kwargs.pop('visit_reason_id')
                logger.info("AUTO-FIX: Renamed 'visit_reason_id' → 'nature_of_visit_id' for Available_time_slots")

            # Apply auto-validation for Available_time_slots to prevent checking past dates
            if tool.name == 'Available_time_slots':
                # Check if start_date is in the past
                if 'start_date' in kwargs:
                    start_date_str = kwargs['start_date']
                    try:
                        # Parse the start_date (format: YYYY-MM-DD)
                        start_date = datetime.strptime(start_date_str, '%Y-%m-%d').date()
                        
                        # Get current date in UTC
                        now_utc = datetime.now(timezone.utc)
                        today = now_utc.date()
                        
                        if start_date < today:
                            error_msg = f"❌ Cannot check availability for {start_date.strftime('%B %d, %Y')}. This date is in the past. Please choose a date from today onwards."
                            logger.error(f"VALIDATION FAILED: Attempted to check slots for past date: {start_date}")
                            return error_msg
                        
                        logger.info(f"DATE VALIDATION: Availability check date {start_date} is valid (today or future)")
                    except Exception as date_error:
                        logger.warning(f"Could not parse date for validation: {date_error}")
                        # Continue if date parsing fails

            # ── WEEKEND GATE for Available_time_slots ─────────────────────────────
            # Practice is closed Sat/Sun. Block the API call and redirect to next Monday.
            if tool.name == 'Available_time_slots':
              _ats_date_str = kwargs.get('start_date', '')
              if _ats_date_str:
                try:
                    _ats_date = datetime.strptime(_ats_date_str, '%Y-%m-%d').date()
                    _ats_wday = _ats_date.weekday()  # 5=Sat, 6=Sun
                    if _ats_wday in (5, 6):
                        _next_mon = _ats_date + timedelta(days=(7 - _ats_wday))
                        _day_name = _ats_date.strftime('%A')
                        logger.info(f"WEEKEND GATE (Available_time_slots): {_ats_date} is {_day_name} — redirecting to {_next_mon}")
                        return (
                            f"❌ OFFICE CLOSED: {_ats_date.strftime('%A, %B %d, %Y')} is a {_day_name}.\n\n"
                            f"The practice is closed on weekends (Saturday & Sunday).\n\n"
                            f"📅 NEXT AVAILABLE DAY: Monday, {_next_mon.strftime('%B %d, %Y')}\n\n"
                            f"Please ask the patient if Monday {_next_mon.strftime('%B %d, %Y')} works, "
                            f"then re-call Available_time_slots with "
                            f"start_date='{_next_mon.isoformat()}' and end_date='{_next_mon.isoformat()}'."
                        )
                except Exception as _wk_err:
                    logger.warning(f"WEEKEND GATE (Available_time_slots): could not parse date — {_wk_err}")
            # ──────────────────────────────────────────────────────────────────────

            # ── ELISE CALL SCHEDULE GATE ──────────────────────────────────────────
            # resource_id 25784 = ELISE CALL — she sees patients THURSDAYS & FRIDAYS only.
            # If the requested date falls on any other weekday, block the call and return
            # a redirect message pointing the agent to the nearest Thu or Fri.
            if tool.name == 'Available_time_slots':
              resource_ids_val = str(kwargs.get('resource_ids', ''))
              if '25784' in resource_ids_val:
                _elise_date_str = kwargs.get('start_date', '')
                if _elise_date_str:
                    try:
                        _req_date  = datetime.strptime(_elise_date_str, '%Y-%m-%d').date()
                        _wday      = _req_date.weekday()  # Mon=0 … Sun=6; Thu=3, Fri=4
                        if _wday not in (3, 4):
                            # Compute next Thursday and next Friday from the requested date
                            _next_thu = _req_date + timedelta(days=(3 - _wday) % 7)
                            _next_fri = _req_date + timedelta(days=(4 - _wday) % 7)
                            # Both deltas are strictly positive because weekday ∉ {3, 4}
                            _closest      = _next_thu if _next_thu <= _next_fri else _next_fri
                            _closest_day  = _closest.strftime('%A')
                            _req_day_name = _req_date.strftime('%A')
                            logger.info(
                                f"ELISE SCHEDULE GATE: {_req_date} is {_req_day_name} "
                                f"— redirecting to {_closest} ({_closest_day})"
                            )
                            return (
                                f"❌ ELISE CALL SCHEDULE RESTRICTION: "
                                f"{_req_date.strftime('%A, %B %d, %Y')} is a {_req_day_name}.\n\n"
                                f"Dr. Elise K. Call sees patients on THURSDAYS and FRIDAYS only.\n\n"
                                f"📅 NEAREST AVAILABLE DAY: {_closest_day}, {_closest.strftime('%B %d, %Y')}\n\n"
                                f"⚠️  INSTRUCTION TO AGENT — say to the caller:\n"
                                f"  \"Dr. Elise K. Call is available on Thursdays and Fridays only. "
                                f"The closest day I can offer you would be {_closest_day}, "
                                f"{_closest.strftime('%B %d, %Y')}. Would that work for you?\"\n\n"
                                f"If the caller agrees, re-call Available_time_slots with "
                                f"start_date='{_closest.isoformat()}' and end_date='{_closest.isoformat()}'."
                            )
                    except Exception as _elise_gate_err:
                        logger.warning(f"ELISE SCHEDULE GATE: could not parse date — {_elise_gate_err}")
            # ──────────────────────────────────────────────────────────────────────

            # Apply auto-validation for create_patient - remove invalid parameters
            if tool.name == 'create_patient':
                original_kwargs = kwargs.copy()
                
                # AUTO-SET: Optional physician/referral/location fields - always use empty string
                physician_fields = ['primary_provider_id', 'referring_physician_id', 'referral_source_id', 'primary_care_physician_id', 'primary_location_id']
                for field in physician_fields:
                    if field not in kwargs or not kwargs[field]:
                        kwargs[field] = ""
                        logger.info(f"AUTO-SET: {field} = '' (not required from user)")
                
                # AUTO-FIX: Convert date_of_birth_string from "2002-01-01" to "2002,01,01"
                if 'date_of_birth_string' in kwargs:
                    dob_string = kwargs['date_of_birth_string']
                    if isinstance(dob_string, str) and '-' in dob_string:
                        # Convert YYYY-MM-DD to YYYY,MM,DD
                        kwargs['date_of_birth_string'] = dob_string.replace('-', ',')
                        logger.info(f"AUTO-FIX: date_of_birth_string '{dob_string}' → '{kwargs['date_of_birth_string']}'")
                
                # VALIDATION: Reject non-numeric state_id values - force agent to call get_state_codes
                if 'state_id' in kwargs:
                    state_value = kwargs['state_id']
                    
                    # CRITICAL FIX: Convert integer to string (LLM sometimes sends as int)
                    if isinstance(state_value, int):
                        kwargs['state_id'] = str(state_value)
                        logger.info(f"AUTO-FIX: Converted state_id from int {state_value} → string '{kwargs['state_id']}'")
                    elif isinstance(state_value, str):
                        # Check if it's not already a numeric ID
                        if not state_value.isdigit():
                            # Convert full state name to abbreviation (API returns abbreviations in "name" field)
                            STATE_NAME_TO_ABBR = {
                                'ALABAMA': 'AL', 'ALASKA': 'AK', 'ARIZONA': 'AZ', 'ARKANSAS': 'AR',
                                'CALIFORNIA': 'CA', 'COLORADO': 'CO', 'CONNECTICUT': 'CT', 'DELAWARE': 'DE',
                                'FLORIDA': 'FL', 'GEORGIA': 'GA', 'HAWAII': 'HI', 'IDAHO': 'ID',
                                'ILLINOIS': 'IL', 'INDIANA': 'IN', 'IOWA': 'IA', 'KANSAS': 'KS',
                                'KENTUCKY': 'KY', 'LOUISIANA': 'LA', 'MAINE': 'ME', 'MARYLAND': 'MD',
                                'MASSACHUSETTS': 'MA', 'MICHIGAN': 'MI', 'MINNESOTA': 'MN', 'MISSISSIPPI': 'MS',
                                'MISSOURI': 'MO', 'MONTANA': 'MT', 'NEBRASKA': 'NE', 'NEVADA': 'NV',
                                'NEW HAMPSHIRE': 'NH', 'NEW JERSEY': 'NJ', 'NEW MEXICO': 'NM', 'NEW YORK': 'NY',
                                'NORTH CAROLINA': 'NC', 'NORTH DAKOTA': 'ND', 'OHIO': 'OH', 'OKLAHOMA': 'OK',
                                'OREGON': 'OR', 'PENNSYLVANIA': 'PA', 'RHODE ISLAND': 'RI', 'SOUTH CAROLINA': 'SC',
                                'SOUTH DAKOTA': 'SD', 'TENNESSEE': 'TN', 'TEXAS': 'TX', 'UTAH': 'UT',
                                'VERMONT': 'VT', 'VIRGINIA': 'VA', 'WASHINGTON': 'WA', 'WEST VIRGINIA': 'WV',
                                'WISCONSIN': 'WI', 'WYOMING': 'WY', 'DISTRICT OF COLUMBIA': 'DC',
                                'PUERTO RICO': 'PR', 'VIRGIN ISLANDS': 'VI'
                            }
                            
                            state_upper = state_value.upper().strip()
                            state_abbr = STATE_NAME_TO_ABBR.get(state_upper, state_value.upper())
                            
                            # REJECT: Force the agent to call get_state_codes tool
                            error_msg = f"""❌ INVALID state_id: \"{state_value}\"

🚨 CRITICAL: Never pass state names or abbreviations to state_id!

✅ REQUIRED STEPS:
1. Call get_state_codes tool first
2. Search for state abbreviation \"{state_abbr}\" in the response (API returns abbreviations)
3. Extract the numeric 'id' field from that state
4. Use that ID for state_id parameter

Example:
- User says: \"New Jersey\"
- Call: get_state_codes()
- Search in response for: \"NJ\" (abbreviation)
- Find: {{\"id\": 31, \"name\": \"NJ\", \"code\": \"NJ\"}}
- Use: state_id=\"31\"

⛔ NEVER use hardcoded mappings or state names directly!
⚠️ NOTE: The API returns abbreviations (NJ, CA, NY) in the "name" field, not full state names."""
                            logger.error(f"VALIDATION FAILED: Non-numeric state_id '{state_value}' (abbreviation: {state_abbr}) - agent must call get_state_codes tool")
                            return error_msg
                
                # Get the schema properties to check which parameters are allowed
                allowed_params = set(schema_props.keys())
                
                # Only keep parameters that are in the schema
                # The MCP server expects: first_name, last_name, date_of_birth, gender_id
                params_to_remove = [k for k in kwargs.keys() if k not in allowed_params]
                for param in params_to_remove:
                    logger.warning(f"SCHEMA MISMATCH: Removing parameter '{param}' (value: {kwargs[param]}) - not in tool schema")
                    del kwargs[param]
                
                # Log what we're sending
                if kwargs != original_kwargs:
                    logger.info(f"VALIDATION APPLIED: Cleaned parameters for create_patient. Sending: {list(kwargs.keys())}")
            
            # Apply auto-validation for create_appointment to fix timezone format
            elif tool.name == 'create_appointment':
                original_kwargs = kwargs.copy()

                # ── SCHEDULE GATE: DISABLED - Dynamic system allows all providers/locations ──
                # Removed hardcoded schedule restrictions to allow dynamic access to all providers and locations
                # The CareCloud API will handle actual availability checking
                logger.info("SCHEDULE GATE DISABLED: Allowing booking")
                
                # ── TIMEZONE RESTORATION ─────────────────────────────────────────
                # The LLM received slot times in Pacific Time (from our POST-
                # PROCESS of Available_time_slots).  Before calling the API we
                # must restore the original UTC offset (e.g. -05:00 / -04:00).
                # We do this via the _pacific_to_original_slot lookup table that
                # was populated when we converted the slots.
                for time_field in ['start_time', 'end_time']:
                    if time_field in kwargs:
                        time_value = kwargs[time_field]
                        if isinstance(time_value, str) and time_value:
                            original = _pacific_to_original_slot.get(time_value)
                            if original:
                                kwargs[time_field] = original
                                logger.info(
                                    f"TZ RESTORE: {time_field} '{time_value}' "
                                    f"→ original '{original}'"
                                )
                            else:
                                # Fallback: the map has no exact entry. This happens when
                                # the LLM constructs a time string that doesn't exactly
                                # match what Available_time_slots returned (e.g. it picks
                                # a different slot's end_time, or reformats slightly).
                                # Convert from whatever timezone (Pacific, UTC, etc.) to
                                # the API's native Eastern Time (-05:00 / -04:00).
                                try:
                                    _dt_fb = datetime.fromisoformat(time_value)
                                    _eastern = ZoneInfo("America/New_York")
                                    _dt_eastern = _dt_fb.astimezone(_eastern)
                                    kwargs[time_field] = _dt_eastern.isoformat()
                                    logger.info(
                                        f"TZ RESTORE FALLBACK: {time_field} "
                                        f"'{time_value}' → '{kwargs[time_field]}' (converted to Eastern)"
                                    )
                                except Exception as _tz_fb_err:
                                    logger.warning(
                                        f"TZ RESTORE: no map entry for {time_field}='{time_value}' "
                                        f"and fallback conversion failed ({_tz_fb_err}) — sending as-is"
                                    )
                
                # Mapping: resource_id → correct provider_id
                # This mapping is now dynamically loaded from business entity data
                # Keeping minimal fallback for backward compatibility
                RESOURCE_TO_PROVIDER = {}

                # Fix: if provider_id was supplied but is actually a resource_id, correct it
                raw_pid = kwargs.get('provider_id')
                if raw_pid is not None and str(raw_pid) in {str(k) for k in RESOURCE_TO_PROVIDER}:
                    corrected = RESOURCE_TO_PROVIDER.get(raw_pid) or RESOURCE_TO_PROVIDER.get(str(raw_pid))
                    logger.warning(
                        f"AUTO-FIX: provider_id='{raw_pid}' looks like a resource_id — "
                        f"replacing with correct provider_id='{corrected}'"
                    )
                    kwargs['provider_id'] = corrected

                # Ensure provider_id is included; derive from resource_id when possible
                if 'provider_id' not in kwargs or not kwargs.get('provider_id'):
                    rid = str(kwargs.get('resource_id', ''))
                    derived = RESOURCE_TO_PROVIDER.get(rid)
                    if derived:
                        kwargs['provider_id'] = derived
                        logger.info(f"AUTO-FIX: Derived provider_id='{derived}' from resource_id='{rid}'")
                    else:
                        logger.warning(
                            f"AUTO-FIX: provider_id missing and resource_id='{rid}' "
                            f"has no known mapping — provider_id left empty"
                        )
                        kwargs['provider_id'] = ''

                # Log validation summary if any changes were made
                if kwargs != original_kwargs:
                    changes = []
                    for key in ['start_time', 'end_time', 'provider_id']:
                        if key in kwargs and original_kwargs.get(key) != kwargs.get(key):
                            changes.append(f"{key}: '{original_kwargs.get(key, 'missing')}' → '{kwargs[key]}'")
                    logger.info(f"VALIDATION APPLIED: Fixed {len(changes)} parameters for create_appointment")
            
            # PRE-PROCESS: Fix Blockout date parameters (BEFORE tool invocation)
            if tool.name == 'Blockout':
                # Blockout expects date format YYYY-MM-DD, not timestamp
                for date_field in ['start_date', 'end_date']:
                    if date_field in kwargs:
                        date_val = kwargs[date_field]
                        if isinstance(date_val, str) and 'T' in date_val:
                            kwargs[date_field] = date_val.split('T')[0]
                            logger.info(f"AUTO-FIX: Blockout {date_field} '{date_val}' → '{kwargs[date_field]}'")

                # ── WEEKEND GATE for Blockout ─────────────────────────────────────
                # Practice is closed Sat/Sun. Block the API call and redirect to next Monday.
                _blk_wk_date_str = kwargs.get('start_date', '')
                if _blk_wk_date_str:
                    try:
                        _blk_wk_date = datetime.strptime(_blk_wk_date_str, '%Y-%m-%d').date()
                        _blk_wk_wday = _blk_wk_date.weekday()
                        if _blk_wk_wday in (5, 6):
                            _blk_next_mon = _blk_wk_date + timedelta(days=(7 - _blk_wk_wday))
                            _blk_wk_day = _blk_wk_date.strftime('%A')
                            logger.info(f"WEEKEND GATE (Blockout): {_blk_wk_date} is {_blk_wk_day} — redirecting to {_blk_next_mon}")
                            return (
                                f"❌ OFFICE CLOSED: {_blk_wk_date.strftime('%A, %B %d, %Y')} is a {_blk_wk_day}.\n\n"
                                f"The practice is closed on weekends (Saturday & Sunday).\n\n"
                                f"📅 NEXT AVAILABLE DAY: Monday, {_blk_next_mon.strftime('%B %d, %Y')}\n\n"
                                f"Please re-run Blockout (and all other steps) using "
                                f"start_date='{_blk_next_mon.isoformat()}' and end_date='{_blk_next_mon.isoformat()}'."
                            )
                    except Exception as _blk_wk_err:
                        logger.warning(f"WEEKEND GATE (Blockout): could not parse date — {_blk_wk_err}")
                # ──────────────────────────────────────────────────────────────────

                # ── ELISE SCHEDULE GATE for Blockout ──────────────────────────────
                # Prevent fetching blockout data for non-Thu/Fri dates when Elise is selected.
                _blk_rid = str(kwargs.get('resource_id', ''))
                _blk_date_str = kwargs.get('start_date', '')
                if '25784' in _blk_rid and _blk_date_str:
                    try:
                        _blk_date = datetime.strptime(_blk_date_str, '%Y-%m-%d').date()
                        _blk_wday = _blk_date.weekday()
                        if _blk_wday not in (3, 4):
                            _blk_next_thu = _blk_date + timedelta(days=(3 - _blk_wday) % 7)
                            _blk_next_fri = _blk_date + timedelta(days=(4 - _blk_wday) % 7)
                            _blk_closest  = _blk_next_thu if _blk_next_thu <= _blk_next_fri else _blk_next_fri
                            _blk_day_name = _blk_date.strftime('%A')
                            logger.info(
                                f"ELISE SCHEDULE GATE (Blockout): {_blk_date} is {_blk_day_name} "
                                f"— redirecting to {_blk_closest}"
                            )
                            return (
                                f"❌ ELISE CALL SCHEDULE RESTRICTION: "
                                f"{_blk_date.strftime('%A, %B %d, %Y')} is a {_blk_day_name}.\n\n"
                                f"Dr. Elise K. Call is available on Thursdays and Fridays only.\n\n"
                                f"📅 NEAREST AVAILABLE DAY: {_blk_closest.strftime('%A, %B %d, %Y')}\n\n"
                                f"Please re-run Blockout (and all other steps) using "
                                f"start_date='{_blk_closest.isoformat()}' and end_date='{_blk_closest.isoformat()}'."
                            )
                    except Exception as _blk_err:
                        logger.warning(f"ELISE SCHEDULE GATE (Blockout): could not parse date — {_blk_err}")
                # ──────────────────────────────────────────────────────────────────

            # PRE-PROCESS: Fix get_appointments_list date parameters (BEFORE tool invocation)
            if tool.name == 'get_appointments_list':
                # Ensure date format is correct
                for date_field in ['start_date', 'end_date']:
                    if date_field in kwargs:
                        date_val = kwargs[date_field]
                        # Check if date is in correct format YYYY-MM-DD
                        if isinstance(date_val, str) and 'T' in date_val:
                            # Extract just the date part
                            kwargs[date_field] = date_val.split('T')[0]
                            logger.info(f"AUTO-FIX: {date_field} '{date_val}' → '{kwargs[date_field]}'")

            # PRE-PROCESS: Appoitment_template — weekend gate + Elise schedule gate
            if tool.name == 'Appoitment_template':
                # ── WEEKEND GATE for Appoitment_template ──────────────────────────
                _tmpl_wk_date_str = kwargs.get('start_date', '')
                if _tmpl_wk_date_str:
                    try:
                        _tmpl_wk_date = datetime.strptime(_tmpl_wk_date_str, '%Y-%m-%d').date()
                        _tmpl_wk_wday = _tmpl_wk_date.weekday()
                        if _tmpl_wk_wday in (5, 6):
                            _tmpl_next_mon = _tmpl_wk_date + timedelta(days=(7 - _tmpl_wk_wday))
                            _tmpl_wk_day = _tmpl_wk_date.strftime('%A')
                            logger.info(f"WEEKEND GATE (Appoitment_template): {_tmpl_wk_date} is {_tmpl_wk_day} — redirecting to {_tmpl_next_mon}")
                            return (
                                f"❌ OFFICE CLOSED: {_tmpl_wk_date.strftime('%A, %B %d, %Y')} is a {_tmpl_wk_day}.\n\n"
                                f"The practice is closed on weekends (Saturday & Sunday).\n\n"
                                f"📅 NEXT AVAILABLE DAY: Monday, {_tmpl_next_mon.strftime('%B %d, %Y')}\n\n"
                                f"Please re-run Appoitment_template (and all subsequent steps) using "
                                f"start_date='{_tmpl_next_mon.isoformat()}' and end_date='{_tmpl_next_mon.isoformat()}'."
                            )
                    except Exception as _tmpl_wk_err:
                        logger.warning(f"WEEKEND GATE (Appoitment_template): could not parse date — {_tmpl_wk_err}")
                # ──────────────────────────────────────────────────────────────────

                _tmpl_rid = str(kwargs.get('resource_id', ''))
                _tmpl_date_str = kwargs.get('start_date', '')
                if '25784' in _tmpl_rid and _tmpl_date_str:
                    try:
                        _tmpl_date = datetime.strptime(_tmpl_date_str, '%Y-%m-%d').date()
                        _tmpl_wday = _tmpl_date.weekday()
                        if _tmpl_wday not in (3, 4):
                            _tmpl_next_thu = _tmpl_date + timedelta(days=(3 - _tmpl_wday) % 7)
                            _tmpl_next_fri = _tmpl_date + timedelta(days=(4 - _tmpl_wday) % 7)
                            _tmpl_closest  = _tmpl_next_thu if _tmpl_next_thu <= _tmpl_next_fri else _tmpl_next_fri
                            _tmpl_day_name = _tmpl_date.strftime('%A')
                            logger.info(
                                f"ELISE SCHEDULE GATE (Appoitment_template): {_tmpl_date} is {_tmpl_day_name} "
                                f"— redirecting to {_tmpl_closest}"
                            )
                            return (
                                f"❌ ELISE CALL SCHEDULE RESTRICTION: "
                                f"{_tmpl_date.strftime('%A, %B %d, %Y')} is a {_tmpl_day_name}.\n\n"
                                f"Dr. Elise K. Call is available on Thursdays and Fridays only.\n\n"
                                f"📅 NEAREST AVAILABLE DAY: {_tmpl_closest.strftime('%A, %B %d, %Y')}\n\n"
                                f"Please re-run Appoitment_template (and all subsequent steps) using "
                                f"start_date='{_tmpl_closest.isoformat()}' and end_date='{_tmpl_closest.isoformat()}'."
                            )
                    except Exception as _tmpl_err:
                        logger.warning(f"ELISE SCHEDULE GATE (Appoitment_template): could not parse date — {_tmpl_err}")

            # PRE-PROCESS: create_insurance — resolve payer/policy IDs + auto-inject effective_from
            if tool.name == 'create_insurance':
                import sys as _sys
                import os as _os

                # Dynamically import Knowledge_base from project root
                try:
                    _kb_path = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
                    if _kb_path not in _sys.path:
                        _sys.path.insert(0, _kb_path)
                    from Knowledge_base import fuzzy_match_payer, fuzzy_match_insurance_policy_type
                    _kb_loaded = True
                except Exception as _kb_err:
                    logger.warning(f"create_insurance: Could not import Knowledge_base: {_kb_err}")
                    _kb_loaded = False

                # ── 1. ALWAYS fuzzy_match_payer when payer_name is provided ──────────
                #  Normalize None → '' so comparisons and fuzzy match work correctly
                #  when the LLM sends null for payer_id / payer_name.
                raw_payer_id   = str(kwargs.get('payer_id') or '')
                raw_payer_name = str(kwargs.get('payer_name') or '')

                # Pick the best available search string (prefer name, fall back to id-as-name)
                _payer_search = raw_payer_name or (raw_payer_id if not raw_payer_id.isdigit() else '')

                if _kb_loaded and _payer_search:
                    matched_payer = fuzzy_match_payer(_payer_search)
                    if matched_payer:
                        addr = matched_payer.get('address', {})
                        logger.info(
                            f"INSURANCE PAYER MATCH: '{_payer_search}' → id={matched_payer['id']} "
                            f"name='{matched_payer['name']}' score={matched_payer['score']}"
                        )
                        # Save complete match object — always overwrite all payer fields
                        kwargs['payer_id']           = matched_payer['id']
                        kwargs['payer_name']         = matched_payer['name']
                        kwargs['line1']              = addr.get('line1', '')
                        kwargs['city']               = addr.get('city', '')
                        kwargs['zip_code']           = addr.get('zip', '')
                        kwargs['payer_phone_number'] = matched_payer.get('phone', '')
                        logger.info(
                            f"INSURANCE AUTO-FILL: line1={kwargs['line1']}, "
                            f"city={kwargs['city']}, zip={kwargs['zip_code']}, "
                            f"phone={kwargs['payer_phone_number']}"
                        )
                    else:
                        logger.warning(
                            f"create_insurance: fuzzy_match_payer('{_payer_search}') returned no match — "
                            f"payer_id sent as-is (may fail API validation)"
                        )
                elif _kb_loaded:
                    logger.warning("create_insurance: no payer_name or non-numeric payer_id provided — skipping payer fuzzy match")

                # ── 2. ALWAYS fuzzy_match_insurance_policy_type when name or code is provided ─
                #  Problem: LLM sends a plausible-looking numeric id (e.g. "3") together with
                #  the real type name ("PPO"). id=3 is actually "Champus" — completely wrong.
                #  Rule: if name OR code is present, ALWAYS fuzzy-match and overwrite the id.
                # Normalize None → '' so comparisons work when the LLM sends null
                raw_type_id   = str(kwargs.get('insurance_policy_type_id') or '')
                raw_type_name = str(kwargs.get('insurance_policy_type_name') or '')
                raw_type_code = str(kwargs.get('insurance_policy_type_code') or '')

                # Best search string: prefer full name, then code, then id-as-text if non-numeric
                _type_search = (raw_type_name or raw_type_code or
                                (raw_type_id if not raw_type_id.isdigit() else ''))

                if _kb_loaded and _type_search:
                    matched_type = fuzzy_match_insurance_policy_type(_type_search)
                    if matched_type:
                        logger.info(
                            f"INSURANCE TYPE MATCH: '{_type_search}' → id={matched_type['id']} "
                            f"({matched_type['name']}/{matched_type['code']}, score={matched_type['score']})"
                        )
                        kwargs['insurance_policy_type_id']   = matched_type['id']
                        kwargs['insurance_policy_type_name'] = matched_type['name']
                        kwargs['insurance_policy_type_code'] = matched_type['code']
                    else:
                        logger.warning(
                            f"create_insurance: fuzzy_match_insurance_policy_type('{_type_search}') "
                            f"returned no match — clearing to avoid FK violation"
                        )
                        kwargs['insurance_policy_type_id']   = ''
                        kwargs['insurance_policy_type_name'] = ''
                        kwargs['insurance_policy_type_code'] = ''

                # ── 3. Auto-inject effective_from = today if missing or empty ─────────
                if not kwargs.get('effective_from'):
                    today_str = date.today().strftime('%Y-%m-%d')
                    kwargs['effective_from'] = today_str
                    logger.info(f"INSURANCE AUTO-INJECT: effective_from = '{today_str}' (today)")

                # ── 4. Always send payer_address_id and policy_number as empty strings ──
                kwargs['payer_address_id'] = ''
                kwargs['policy_number'] = ''
                logger.info("INSURANCE AUTO-INJECT: payer_address_id='' and policy_number='' (always empty)")

            # PRE-PROCESS: eligibility — use default provider_id from environment or first available
            if tool.name == 'eligibility':
                # Use first available provider from business entity data
                default_provider_id = os.environ.get('DEFAULT_PROVIDER_ID', '24506')
                kwargs['provider_id'] = default_provider_id
                logger.info(f"ELIGIBILITY AUTO-INJECT: provider_id='{default_provider_id}' (default provider)")

            # PRE-PROCESS: Auto-inject correct token for CareCloud vs Companion tools.
            # The LLM never supplies web_token — it is always pulled from env.
            # Routing sets from single authoritative source in token_refresh_service.
            from token_refresh_service import CARECLOUD_TOOLS as _CARECLOUD_TOOLS, COMPANION_TOOLS as _COMPANION_TOOLS

            # Pre-emptive guard: if a full refresh already failed this session for this
            # service, skip the HTTP call and return a terminal LLM instruction immediately.
            _is_comp_tool = tool.name in _COMPANION_TOOLS
            _is_cc_tool   = tool.name in _CARECLOUD_TOOLS
            if (_is_comp_tool and _companion_auth_fail_count >= 1) or \
               (_is_cc_tool   and _carecloud_auth_fail_count >= 1):
                logger.warning(
                    f"[AUTH GUARD] Skipping '{tool.name}' — service auth failed earlier this session"
                )
                return (
                    "⚠️ SYSTEM ERROR: Authorization service unavailable for this call. "
                    "Say 'Let me connect you with the office.' and call transfer_to_human() immediately. "
                    "Do NOT retry any tool."
                )

            # PROACTIVE FRESHNESS CHECK: Refresh the CareCloud token before any
            # CareCloud tool call if the token is within 5 minutes of its expiry.
            # This prevents mid-call auth failures without waiting for a reactive retry.
            if _is_cc_tool:
                try:
                    from token_refresh_service import ensure_carecloud_token_fresh
                    await ensure_carecloud_token_fresh()
                except Exception as _fresh_exc:
                    logger.warning("[AUTH GUARD] ensure_carecloud_token_fresh failed (non-fatal): %s", _fresh_exc)

            if tool.name in _CARECLOUD_TOOLS:
                cc_token = os.environ.get('CARECLOUD_BEARER_TOKEN', '')
                kwargs['web_token'] = cc_token
                logger.info(f"CARECLOUD TOKEN AUTO-INJECT: web_token set for '{tool.name}' (len={len(cc_token)})")
            elif tool.name in _COMPANION_TOOLS:
                comp_token = os.environ.get('COMPANION_TOKEN', '')
                kwargs['web_token'] = comp_token
                logger.info(f"COMPANION TOKEN AUTO-INJECT: web_token set for '{tool.name}' (len={len(comp_token)})")

            # Snapshot the fully-processed kwargs so agent.py can use them for
            # transcript logging (transcription shows resolved values, not raw LLM args).
            _processed_kwargs_store[tool.name] = dict(kwargs)

            input_json = json.dumps(kwargs)
            logger.info(f"Invoking tool '{tool.name}' with args: {kwargs}")

            # ── THINKING FEEDBACK TIMER ─────────────────────────────────────────────
            # If a tool call takes longer than 8 seconds, say a verbal cue so the
            # caller doesn't experience dead air. Cancelled automatically on completion.
            _thinking_task = None

            async def _say_thinking_after_delay(delay_secs: float = 8.0):
                try:
                    await asyncio.sleep(delay_secs)
                    if _agent_session:
                        logger.info(f"[THINKING] Tool '{tool.name}' exceeds {delay_secs}s — saying verbal cue")
                        await _agent_session.say(
                            "One moment please, I'm looking that up.",
                            allow_interruptions=True,
                        )
                except asyncio.CancelledError:
                    pass
                except Exception as _te:
                    logger.warning(f"[THINKING] say() failed (non-fatal): {_te}")

            _thinking_task = asyncio.create_task(_say_thinking_after_delay(8.0))
            try:
                # ── IN-FLIGHT DEDUPLICATION for create_appointment ──────────────────
                # The create_appointment API can be slow.  If the LLM times out waiting
                # for the first response and fires a second identical call, this guard
                # makes the second caller await the first Future instead of hitting the
                # API again — so only ONE appointment is ever created per set of params.
                _appointment_was_dedup_hit = False  # True only for the second (redundant) call
                if tool.name == 'create_appointment':
                    fingerprint = json.dumps(
                        {k: kwargs[k] for k in sorted(kwargs)}, sort_keys=True
                    )
                    if fingerprint in _inflight_create_appointment:
                        logger.warning(
                            "DEDUP: create_appointment already in-flight with identical "
                            "params — awaiting existing call instead of re-calling API"
                        )
                        result_str = await _inflight_create_appointment[fingerprint]
                        _appointment_was_dedup_hit = True  # mark: this was a duplicate call
                        logger.info(f"DEDUP: reused in-flight result for create_appointment")
                    else:
                        future: asyncio.Future = asyncio.get_event_loop().create_future()
                        _inflight_create_appointment[fingerprint] = future
                        try:
                            result_str = await tool.on_invoke_tool(None, input_json)
                            if not future.done():
                                future.set_result(result_str)
                        except Exception as _exc:
                            if not future.done():
                                future.set_exception(_exc)
                            raise
                        finally:
                            _inflight_create_appointment.pop(fingerprint, None)
                else:
                    result_str = await tool.on_invoke_tool(None, input_json)
                # ────────────────────────────────────────────────────────────────────

                # AUTH ERROR RECOVERY: If the tool returns an authorization error (e.g. token
                # expired mid-call), silently refresh the appropriate token and retry once.
                def _is_auth_error(result: str) -> bool:
                    if not result:
                        return False
                    lower = result.lower()
                    # String-level patterns — covers HTTP-level 401/403 and generic API errors
                    _AUTH_STRINGS = [
                        "unauthorized", "401", "403", "forbidden",
                        "token expired", "token invalid", "invalid token",
                        "authentication failed", "authorization failed", "auth failed",
                        "not authenticated", "not authorized", "access denied",
                        "invalid credentials", "session expired",
                    ]
                    if any(kw in lower for kw in _AUTH_STRINGS):
                        return True
                    # CareCloud-specific JSON: {"error_code": "0037", "message": "Authorization Failed"}
                    try:
                        parsed = json.loads(result)
                        items = parsed if isinstance(parsed, list) else [parsed]
                        for item in items:
                            if not isinstance(item, dict):
                                continue
                            err = item.get('error')
                            if isinstance(err, dict):
                                code = str(err.get('error_code', ''))
                                msg = str(err.get('message', '')).lower()
                                if code == '0037' or 'authorization failed' in msg:
                                    return True
                    except Exception:
                        pass
                    return False

                if _is_auth_error(result_str):
                    logger.warning(
                        f"AUTH ERROR detected for tool '{tool.name}' — delegating to token_refresh_service "
                        f"(will refresh BOTH tokens)…"
                    )
                    try:
                        from token_refresh_service import refresh_token_for_tool
                        refresh_result = await refresh_token_for_tool(tool.name)

                        # Re-inject the triggering service's fresh token
                        kwargs['web_token'] = refresh_result["token"]

                        # Log dual-refresh status
                        logger.info(
                            f"DUAL TOKEN REFRESH: service={refresh_result['service']} "
                            f"refreshed={refresh_result['refreshed']} "
                            f"both_refreshed={refresh_result.get('both_refreshed')} "
                            f"token_len={len(refresh_result['token'])} — retrying tool '{tool.name}'"
                        )
                        input_json = json.dumps(kwargs)
                        result_str = await tool.on_invoke_tool(None, input_json)
                        logger.info(
                            f"AUTH RETRY result for '{tool.name}': {result_str[:200]}"
                        )
                        # If still failing after a full refresh, increment counter and
                        # return a terminal LLM instruction. The pre-emptive guard at
                        # the top of tool_impl will block all further calls this session.
                        if _is_auth_error(result_str):
                            if refresh_result["service"] == "companion":
                                _companion_auth_fail_count += 1
                                logger.error(
                                    f"[AUTH FAIL] Companion token still invalid after dual refresh — "
                                    f"_companion_auth_fail_count={_companion_auth_fail_count}"
                                )
                            else:
                                _carecloud_auth_fail_count += 1
                                logger.error(
                                    f"[AUTH FAIL] CareCloud token still invalid after dual refresh — "
                                    f"_carecloud_auth_fail_count={_carecloud_auth_fail_count}"
                                )
                            result_str = (
                                "⚠️ SYSTEM ERROR: Authorization service unavailable for this call. "
                                "Say 'Let me connect you with the office.' and call transfer_to_human() immediately. "
                                "Do NOT retry any tool."
                            )
                    except Exception as refresh_exc:
                        logger.error(
                            f"Token refresh/retry failed for '{tool.name}': {refresh_exc}"
                        )
            finally:
                # Cancel the thinking feedback timer once the tool call completes
                if _thinking_task and not _thinking_task.done():
                    _thinking_task.cancel()

            # POST-PROCESS: Filter Visit_Reasons to only the allowed visit types.
            # This practice only handles ESTABLISHED PATIENT/FOLLOW-U EXTENDED (id=79304).
            if tool.name == 'Visit_Reasons' and result_str:
                try:
                    _ALLOWED_VISIT_IDS = {79304}
                    visits_raw = json.loads(result_str)
                    if isinstance(visits_raw, list):
                        def _visit_id(v):
                            # Shape A: {"nature_of_visit": {"id": 79304, ...}}
                            nested = v.get("nature_of_visit")
                            if isinstance(nested, dict):
                                return nested.get("id")
                            # Shape B: flat {"id": 79304, "name": "..."}
                            return v.get("id")

                        filtered = [
                            v for v in visits_raw
                            if _visit_id(v) in _ALLOWED_VISIT_IDS
                        ]

                        # If none matched (API changed shape entirely), keep all and log a warning
                        if not filtered and visits_raw:
                            logger.warning(
                                f"VISIT_REASONS FILTER: 0 matches from {len(visits_raw)} items — "
                                f"falling back to full list. Sample item: {visits_raw[0]}"
                            )
                            filtered = visits_raw  # pass through unfiltered so agent can work

                        result_str = json.dumps(filtered)
                        logger.info(
                            f"VISIT_REASONS FILTER: reduced {len(visits_raw)} → {len(filtered)} "
                            f"visit types (allowed IDs: {_ALLOWED_VISIT_IDS})"
                        )
                except Exception as _vr_err:
                    logger.warning(f"VISIT_REASONS FILTER: could not parse result — {_vr_err}")

            # POST-PROCESS: get_appointments_list — extract & surface the UUID appointment_id
            # for every appointment so the LLM never confuses it with a numeric fragment.
            if tool.name == 'get_appointments_list' and result_str:
                try:
                    apts_raw = json.loads(result_str)
                    # Handle nested wrapper: [{"response": [...]}]
                    if (isinstance(apts_raw, list) and len(apts_raw) == 1
                            and isinstance(apts_raw[0], dict) and 'response' in apts_raw[0]):
                        apts_raw = apts_raw[0]['response']

                    # Build ID→name lookup tables from provider_schedules (parent package)
                    try:
                        import sys as _sys_ao, os as _os_ao
                        _ao_root = _os_ao.path.dirname(_os_ao.path.dirname(_os_ao.path.abspath(__file__)))
                        if _ao_root not in _sys_ao.path:
                            _sys_ao.path.insert(0, _ao_root)
                        from provider_schedules import RESOURCE_NAMES as _APT_RES_NAMES
                        _APT_PROV_NAMES = {24506: "DR. GEORGE T KELLY MD", 26123: "ELISE K CALL"}
                    except Exception as _psimport_err:
                        logger.warning(f"APPOINTMENTS POST-PROCESS: could not import provider_schedules — {_psimport_err}")
                        _APT_RES_NAMES = {}
                        _APT_PROV_NAMES = {}

                    if isinstance(apts_raw, list) and apts_raw:
                        lines = [
                            "✅ APPOINTMENTS FOUND\n",
                            "🔑 CRITICAL — SAVE THE UUID BELOW AND USE IT FOR CANCELLATION:\n",
                            "   The 'appointment_id' field is a UUID (xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx).\n",
                            "   ALWAYS use this UUID for Cancel_Appointment — NEVER a short number.\n",
                        ]
                        for i, entry in enumerate(apts_raw, 1):
                            apt      = entry.get("appointment", entry)
                            uuid_val = apt.get("id", "")
                            status   = (apt.get("appointment_status") or {}).get("name", "N/A")
                            start    = apt.get("start_time", "N/A")
                            end      = apt.get("end_time", "N/A")
                            loc      = (apt.get("location") or {}).get("name", "N/A")

                            # Provider name resolution:
                            # 1. Try nested object keys first (forward-compat).
                            # 2. Fall back to resolving raw provider_id / resource_id via lookup.
                            prov = "N/A"
                            for _pk in ("resource", "provider", "rendering_provider", "practitioner"):
                                _pv = apt.get(_pk)
                                if isinstance(_pv, dict) and _pv.get("name"):
                                    prov = _pv["name"]
                                    break
                            if prov == "N/A":
                                _pid = apt.get("provider_id")
                                _rid = apt.get("resource_id")
                                prov = (
                                    _APT_PROV_NAMES.get(_pid)
                                    or _APT_RES_NAMES.get(_rid)
                                    or (f"Provider #{_pid}" if _pid else None)
                                    or (f"Resource #{_rid}" if _rid else "N/A")
                                )

                            # Visit reason: chief_complaint is the pre-resolved human-readable
                            # string already present in the response. Fall back to a nested
                            # visit_reason/nature_of_visit object, then a raw ID label.
                            visit = apt.get("chief_complaint") or None
                            if not visit:
                                _nov = apt.get("nature_of_visit") or apt.get("visit_reason") or {}
                                visit = (_nov.get("name") if isinstance(_nov, dict) else None) or "N/A"

                            # Convert start/end to Pacific for display
                            start_display = start
                            end_display   = end
                            try:
                                if isinstance(start, str) and start not in ("N/A", ""):
                                    start_display = _to_pacific(start)
                                if isinstance(end, str) and end not in ("N/A", ""):
                                    end_display = _to_pacific(end)
                            except Exception:
                                pass

                            lines.append(
                                f"Appointment #{i}:\n"
                                f"   • appointment_id (UUID — USE THIS for Cancel_Appointment): \"{uuid_val}\"\n"
                                f"   • Status      : {status}\n"
                                f"   • Provider    : {prov}\n"
                                f"   • Visit Reason: {visit}\n"
                                f"   • Location    : {loc}\n"
                                f"   • Start       : {start_display} Pacific Time\n"
                                f"   • End         : {end_display} Pacific Time\n"
                            )
                        lines.append(
                            "\n⚠️  NEXT STEP: Save the UUID above as old_appointment_uuid.\n"
                            "   When cancelling: Cancel_Appointment(appointment_id=\"<UUID>\")\n"
                        )
                        result_str = "\n".join(lines)
                        logger.info(f"APPOINTMENTS POST-PROCESS: surfaced {len(apts_raw)} UUID(s) for LLM")
                except Exception as _apt_err:
                    logger.warning(f"APPOINTMENTS POST-PROCESS: could not parse — {_apt_err}")

            logger.info(f"Tool '{tool.name}' result: {result_str}")

            # POST-PROCESS: Convert Available_time_slots response to Pacific Time.
            # The API returns times in EST (-05:00) or EDT (-04:00).  We convert
            # every slot to America/Los_Angeles before the LLM sees them, and store
            # a reverse mapping so create_appointment can restore the original offset.
            if tool.name == 'Available_time_slots' and result_str:
                try:
                    converted = _convert_slots_to_pacific(result_str)
                    logger.info(
                        f"SLOT TZ CONVERT: Available_time_slots response converted to Pacific Time. "
                        f"Map size: {len(_pacific_to_original_slot)} entries"
                    )
                    result_str = converted

                    # ── SLOT SUMMARY ANNOTATION ──────────────────────────────────
                    # Parse the filtered slots and append a human-readable summary
                    # showing the ACTUAL first and last slot per day.  This prevents
                    # the LLM from guessing times based on hardcoded office hours.
                    try:
                        _sl_data = json.loads(converted)
                        _day_slots: Dict[str, list] = {}  # date_str → list of start times
                        _slot_items = []
                        if isinstance(_sl_data, list):
                            for group in _sl_data:
                                if isinstance(group, dict) and 'slots' in group:
                                    _slot_items.extend(group['slots'])
                                elif isinstance(group, dict) and 'start_time' in group:
                                    _slot_items.append(group)
                        elif isinstance(_sl_data, dict) and 'slots' in _sl_data:
                            _slot_items = _sl_data['slots']

                        for _s in _slot_items:
                            _st = _s.get('start_time', '')
                            _et = _s.get('end_time', '')
                            if _st:
                                try:
                                    _dt = datetime.fromisoformat(_st)
                                    _day_key = _dt.strftime('%Y-%m-%d (%A)')
                                    _time_str = _dt.strftime('%I:%M %p').lstrip('0')
                                    _end_str = ''
                                    if _et:
                                        _end_str = datetime.fromisoformat(_et).strftime('%I:%M %p').lstrip('0')
                                    _day_slots.setdefault(_day_key, []).append((_time_str, _et, _st, _end_str))
                                except Exception:
                                    pass

                        if _day_slots:
                            _summary_lines = [
                                "\n\n══════════════════════════════════════",
                                "⚠️  AVAILABLE SLOTS SUMMARY (Pacific Time)",
                                "ONLY offer times listed below. NEVER suggest",
                                "a time that is not in this list.",
                                "══════════════════════════════════════",
                            ]
                            for _day, _times in sorted(_day_slots.items()):
                                _first = _times[0]
                                _last = _times[-1]
                                _summary_lines.append(
                                    f"  {_day}: {len(_times)} slots | "
                                    f"First: {_first[0]} | Last: {_last[0]} (ends {_last[3]})"
                                )
                            _summary_lines.append(
                                "══════════════════════════════════════"
                            )
                            result_str = result_str + "\n".join(_summary_lines)
                            logger.info(f"SLOT SUMMARY: appended summary for {len(_day_slots)} day(s)")
                    except Exception as _sum_err:
                        logger.warning(f"SLOT SUMMARY: could not generate — {_sum_err}")
                    # ──────────────────────────────────────────────────────────────

                except Exception as _tz_err:
                    logger.warning(f"SLOT TZ CONVERT: could not convert slots — {_tz_err}")

            # NOTE: The broken MCP 'Locations' tool has been disabled.
            # The agent now uses the local get_available_locations() tool from tools.py
            # which returns complete location data including IDs, names, addresses, etc.

            # POST-PROCESS: Extract appointment ID from create_appointment response
            if tool.name == 'create_appointment' and result_str:
                try:
                    # Parse the response to extract appointment ID
                    response_data = json.loads(result_str)
                    if isinstance(response_data, list) and len(response_data) > 0:
                        appointments = response_data[0].get('appointments', [])
                        if appointments:
                            # Find the newly created appointment (should be last or have matching patient_id)
                            new_apt = None
                            patient_id = kwargs.get('patient_id')
                            
                            # Try to find appointment matching the patient_id
                            for apt in appointments:
                                if apt.get('patient', {}).get('id') == int(patient_id):
                                    # Check if this is a newly created one (status might be 1 for pending)
                                    if apt.get('status_id') in [1, 3]:  # Pending or other new status
                                        new_apt = apt
                                        break
                            
                            # If we found a matching appointment, enhance the response
                            if new_apt:
                                apt_id = new_apt.get('id')
                                start_time = new_apt.get('start_time')
                                end_time = new_apt.get('end_time')
                                
                                # Store appointment_id in ContextMemory
                                from .util import ContextMemory
                                await ContextMemory._store_value('appointment_id', str(apt_id))
                                
                                enhanced_response = f"""✅ APPOINTMENT CREATED SUCCESSFULLY

📋 APPOINTMENT DETAILS:
   • Appointment ID: {apt_id} (stored for future use)
   • Patient ID: {patient_id}
   • Start Time: {start_time}
   • End Time: {end_time}
   
🔑 IMPORTANT: To cancel this appointment, use appointment_id: {apt_id}

Original API Response: {result_str[:500]}..."""
                                
                                logger.info(f"✅ Created appointment ID: {apt_id} for patient {patient_id} - Stored for future use")
                                return enhanced_response

                    # ── ALREADY-BOOKED SAFETY NET ────────────────────────────────────
                    # Only applies when this was a DEDUP HIT (second call that reused
                    # an in-flight future).  If the first call itself returned "already
                    # booked" that is a real API error (patient genuinely has a
                    # conflicting appointment) — do NOT misreport it as a success.
                    result_lower = result_str.lower()
                    already_booked_signals = [
                        'already', 'duplicate', 'conflict', 'exists',
                        'already booked', 'already scheduled', 'already exists',
                        'has appointment', 'could not add'
                    ]
                    if _appointment_was_dedup_hit and any(signal in result_lower for signal in already_booked_signals):
                        patient_id = kwargs.get('patient_id', 'unknown')
                        logger.warning(
                            f"⚠️  create_appointment returned a possible duplicate error — "
                            f"treating as SUCCESS (appointment was likely booked by a concurrent call). "
                            f"Raw response: {result_str[:200]}"
                        )
                        success_response = f"""✅ APPOINTMENT ALREADY EXISTS / SUCCESSFULLY BOOKED

📋 BOOKING STATUS:
   • The appointment for Patient ID {patient_id} was already booked (possibly by a concurrent request).
   • This is a SUCCESS — please confirm to the patient that their appointment is confirmed.

⚠️  IMPORTANT INSTRUCTION FOR LLM:
   - DO NOT say "I couldn't book" or "there was an error".
   - The appointment IS booked. Confirm it to the patient warmly.
   - Requested time: {kwargs.get('start_time', 'as requested')}

Original API Response: {result_str[:300]}"""
                        return success_response
                    # ─────────────────────────────────────────────────────────────────

                except Exception as e:
                    logger.warning(f"Could not parse create_appointment response: {e}")
                    # Return original response if parsing fails
            
            # POST-PROCESS: Extract and store patient_id from create_patient response
            if tool.name == 'create_patient' and result_str:
                try:
                    # Parse the response to extract patient ID
                    response_data = json.loads(result_str)
                    if isinstance(response_data, dict) and 'id' in response_data:
                        patient_id = str(response_data['id'])
                        
                        # Store in ContextMemory for future use
                        from .util import ContextMemory
                        await ContextMemory._store_value('patient_id', patient_id)
                        
                        enhanced_response = f"""✅ PATIENT CREATED SUCCESSFULLY

📋 PATIENT DETAILS:
   • Patient ID: {patient_id}
   • Name: {kwargs.get('first_name', '')} {kwargs.get('last_name', '')}
   
🔑 IMPORTANT: This patient_id ({patient_id}) will be used for all future operations.

Original API Response: {result_str}"""
                        
                        logger.info(f"✅ Created patient ID: {patient_id} - Stored for future use")
                        return enhanced_response
                except Exception as e:
                    logger.warning(f"Could not parse create_patient response: {e}")
                    # Return original response if parsing fails
            
            # POST-PROCESS: Guide agent to select and store patient_id from Patient_Verification
            if tool.name == 'Patient_Verification' and result_str:
                try:
                    # Parse the verification response
                    response_data = json.loads(result_str)
                    if isinstance(response_data, list) and len(response_data) > 0:
                        patients = response_data[0].get('patients', [])
                        if len(patients) > 0:
                            # ── AUTO-STORE verified patient when exactly 1 result ──
                            # This ensures create_appointment (and other tools) can
                            # auto-inject the correct patient_id even if the LLM
                            # loses track of it during the conversation.
                            if len(patients) == 1:
                                _verified_patient.clear()
                                _verified_patient['patient_id'] = patients[0].get('id')
                                _verified_patient['patient_external_id'] = patients[0].get('external_id', '')
                                _verified_patient['name'] = f"{patients[0].get('first_name', '')} {patients[0].get('last_name', '')}"
                                logger.info(
                                    f"VERIFIED PATIENT STORED: patient_id={_verified_patient['patient_id']}, "
                                    f"external_id={_verified_patient['patient_external_id']}, "
                                    f"name={_verified_patient['name']}"
                                )
                            else:
                                # Multiple patients — store all; will be narrowed
                                # by DOB match once the LLM picks one.
                                _verified_patient.clear()
                                _verified_patient['candidates'] = [
                                    {
                                        'patient_id': p.get('id'),
                                        'patient_external_id': p.get('external_id', ''),
                                        'name': f"{p.get('first_name', '')} {p.get('last_name', '')}",
                                        'dob': p.get('dob', ''),
                                    }
                                    for p in patients
                                ]
                                logger.info(
                                    f"VERIFIED PATIENT CANDIDATES STORED: {len(patients)} patients"
                                )

                            # Add guidance to help AI select the correct patient
                            enhanced_response = f"""✅ PATIENT VERIFICATION RESULTS

Found {len(patients)} patient(s) matching the search.

🔑 CRITICAL: You already collected the patient's DOB before this call.
Now silently compare the caller-stated DOB with the results below.
Do NOT ask for DOB again. Do NOT reveal any data from these records.

📋 MATCHING PATIENTS:
"""
                            for idx, patient in enumerate(patients, 1):
                                patient_id = patient.get('id')
                                name = f"{patient.get('first_name', '')} {patient.get('last_name', '')}"
                                dob = patient.get('dob', 'N/A')
                                chart = patient.get('chart_number', 'N/A')
                                
                                enhanced_response += f"""
Patient #{idx}:
   • Patient ID: {patient_id}
   • Name: {name}
   • Date of Birth: {dob}
   • Chart Number: {chart}
"""
                            
                            enhanced_response += f"""
⚠️ DECISION TREE — follow your prompt instructions:
• If exactly 1 patient's DOB matches the caller's stated DOB → verified. Save patient_id.
  Say "Thank you for confirming!" and proceed.
• If multiple patients match DOB → re-confirm name/DOB, then match.
• If zero DOB matches → say "I'm not finding you in our system with that information."
  Then transfer to human. NEVER reveal the actual DOB on file.

Original API Response: {result_str[:500]}..."""
                            
                            logger.info(f"✅ Patient verification returned {len(patients)} result(s)")
                            return enhanced_response
                except Exception as e:
                    logger.warning(f"Could not parse Patient_Verification response: {e}")
                    # Return original response if parsing fails
            
            # PRE-VALIDATION: Cancel_Appointment must receive a UUID, not a numeric fragment
            if tool.name == 'Cancel_Appointment':
                import re as _re_c
                appointment_id = kwargs.get('appointment_id', '')
                appt_id_str = str(appointment_id).strip()
                _uuid_re = r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'

                if not appt_id_str:
                    logger.error("VALIDATION FAILED: appointment_id missing for Cancel_Appointment")
                    return (
                        "❌ MISSING appointment_id.\n\n"
                        "Call get_appointments_list first. "
                        "The UUID shown as 'appointment_id' in that response is what you need.\n"
                        "Format: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
                    )

                if not _re_c.match(_uuid_re, appt_id_str, _re_c.IGNORECASE):
                    logger.error(f"VALIDATION FAILED: appointment_id '{appt_id_str}' is not a UUID")
                    return (
                        f"❌ WRONG appointment_id: \"{appt_id_str}\"\n\n"
                        "Cancel_Appointment requires the UUID appointment_id from get_appointments_list.\n"
                        "UUID format: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx\n\n"
                        f"❌ Wrong  : appointment_id = \"{appt_id_str}\"  ← not a valid UUID\n\n"
                        "Re-read the get_appointments_list response and copy the exact UUID shown there."
                    )

            # ================================================================
            # POST-PROCESS: create_insurance — extract key IDs and prompt
            # the agent to immediately call the eligibility tool.
            # Only surfaces: insurance_policy_id, insurance_profile_id,
            # patient_id, payer_id, and effective_from (today).
            # ================================================================
            if tool.name == 'create_insurance' and result_str:
                try:
                    response_data = json.loads(result_str)

                    # The API may return a list or a dict — normalise to dict
                    if isinstance(response_data, list) and response_data:
                        resp_obj = response_data[0]
                    elif isinstance(response_data, dict):
                        resp_obj = response_data
                    else:
                        resp_obj = {}

                    # Extract nested insurance_policies list
                    ins_policies = resp_obj.get('insurance_policies', [])
                    if isinstance(ins_policies, dict):
                        ins_policies = [ins_policies]

                    policy = ins_policies[0] if ins_policies else {}

                    insurance_policy_id  = str(policy.get('id', ''))
                    insurance_profile_id = (
                        str(policy.get('insurance_profile_id', ''))
                        or str(resp_obj.get('id', ''))
                    )
                    patient_id_elig   = str(kwargs.get('patient_id', ''))
                    payer_id_elig     = str(kwargs.get('payer_id', ''))
                    today_elig        = date.today().strftime('%Y-%m-%d')

                    enhanced_response = f"""✅ INSURANCE CREATED SUCCESSFULLY

📋 SAVED VALUES (use these for eligibility):
   • insurance_policy_id  : {insurance_policy_id}
   • insurance_profile_id : {insurance_profile_id}
   • patient_id           : {patient_id_elig}
   • payer_id             : {payer_id_elig}
   • eligibility_date     : {today_elig}

🔑 MANDATORY NEXT STEP — call eligibility RIGHT NOW:
   eligibility(
     patient_id           = "{patient_id_elig}",
     payer_id             = "{payer_id_elig}",
     insurance_policy_id  = "{insurance_policy_id}",
     insurance_profile_id = "{insurance_profile_id}",
     eligibility_date     = "{today_elig}",
     provider_id          = "3012"
   )

Do NOT skip the eligibility call. Do NOT ask the patient anything before calling it."""

                    logger.info(
                        f"✅ create_insurance post-process: "
                        f"policy_id={insurance_policy_id} profile_id={insurance_profile_id} "
                        f"patient={patient_id_elig} payer={payer_id_elig}"
                    )
                    return enhanced_response
                except Exception as _e:
                    logger.warning(f"Could not parse create_insurance response: {_e}")
                    # Fall through and return the raw result_str

            return result_str

        # Set function metadata
        tool_impl.__signature__ = inspect.Signature(parameters=params)
        tool_impl.__name__ = tool.name
        tool_impl.__doc__ = tool.description
        tool_impl.__annotations__ = {'return': str, **annotations}
        # Python 3.14 PEP 749: __annotate__ supersedes __annotations__ for get_type_hints().
        # Remove it so get_type_hints() falls back to our manually set __annotations__ dict.
        if hasattr(tool_impl, '__annotate__'):
            try:
                del tool_impl.__annotate__
            except (AttributeError, TypeError):
                pass

        # Apply the decorator
        decorated = function_tool()(tool_impl)

        # Also patch the wrapper that function_tool() returns so that LiveKit's
        # get_type_hints() call on the wrapper finds all annotations regardless of
        # how the decorator propagates metadata in Python 3.14.
        try:
            decorated.__annotations__ = {'return': str, **annotations}
            if hasattr(decorated, '__annotate__'):
                try:
                    del decorated.__annotate__
                except (AttributeError, TypeError):
                    pass
        except (AttributeError, TypeError):
            pass

        return decorated

    @staticmethod
    async def register_with_agent(agent, mcp_servers: List[MCPServer],
                                 convert_schemas_to_strict: bool = True,
                                 auto_connect: bool = True) -> List[Callable]:
        """
        Helper method to prepare and register MCP tools with a LiveKit agent.

        Args:
            agent: The LiveKit agent instance
            mcp_servers: List of MCPServer instances
            convert_schemas_to_strict: Whether to convert schemas to strict format
            auto_connect: Whether to auto-connect to servers

        Returns:
            List of tool functions that were registered
        """
        # Prepare the dynamic tools
        tools = await MCPToolsIntegration.prepare_dynamic_tools(
            mcp_servers,
            convert_schemas_to_strict=convert_schemas_to_strict,
            auto_connect=auto_connect
        )

        # Register with the agent
        if hasattr(agent, '_tools') and isinstance(agent._tools, list):
            agent._tools.extend(tools)
            logger.info(f"Registered {len(tools)} MCP tools with agent")

            # Log the names of registered tools
            if tools:
                tool_names = [getattr(t, '__name__', 'unknown') for t in tools]
                logger.info(f"Registered tool names: {tool_names}")
        else:
            logger.warning("Agent does not have a '_tools' attribute, tools were not registered")

        return tools

    @staticmethod
    async def create_agent_with_tools(agent_class, mcp_servers: List[MCPServer], agent_kwargs: Dict = None,
                                    convert_schemas_to_strict: bool = True) -> Any:
        """
        Factory method to create and initialize an agent with MCP tools already loaded.

        Args:
            agent_class: Agent class to instantiate
            mcp_servers: List of MCP servers to register with the agent
            agent_kwargs: Additional keyword arguments to pass to the agent constructor
            convert_schemas_to_strict: Whether to convert JSON schemas to strict format

        Returns:
            An initialized agent instance with MCP tools registered
        """
        # Connect to MCP servers
        for server in mcp_servers:
            if not getattr(server, 'connected', False):
                try:
                    logger.debug(f"Connecting to MCP server: {server.name}")
                    await server.connect()
                except Exception as e:
                    logger.error(f"Failed to connect to MCP server {server.name}: {e}")

        # Create agent instance
        agent_kwargs = agent_kwargs or {}
        agent = agent_class(**agent_kwargs)

        # Prepare tools
        tools = await MCPToolsIntegration.prepare_dynamic_tools(
            mcp_servers,
            convert_schemas_to_strict=convert_schemas_to_strict,
            auto_connect=False  # Already connected above
        )

        # Register tools with agent
        if tools and hasattr(agent, '_tools') and isinstance(agent._tools, list):
            agent._tools.extend(tools)
            logger.info(f"Registered {len(tools)} MCP tools with agent")

            # Log the names of registered tools
            tool_names = [getattr(t, '__name__', 'unknown') for t in tools]
            logger.info(f"Registered tool names: {tool_names}")
        else:
            if not tools:
                logger.warning("No tools were found to register with the agent")
            else:
                logger.warning("Agent does not have a '_tools' attribute, tools were not registered")

        return agent
