import asyncio
import json
import functools
import os
import logging
import re
from typing import Any, Dict, List

# Import from mcp libraries
from mcp.types import Tool as MCPTool, CallToolResult
from .server import MCPServer

# Lazy imports for token refresh (avoid circular imports at module level)
_auth_logger = logging.getLogger("auth_retry")

# ── Per-token async refresh locks ────────────────────────────────────────────
# Prevents concurrent OAuth storms: if two tool calls both detect an expired
# token simultaneously, only one OAuth flow fires; the second waits and then
# reuses the fresh token that was just written to DB.
# Locks are lazy-initialised inside a running event loop to avoid the
# DeprecationWarning raised when asyncio.Lock() is created at import time.
_cc_refresh_lock: "asyncio.Lock | None" = None
_ws_refresh_lock: "asyncio.Lock | None" = None


def _get_cc_lock() -> "asyncio.Lock":
    global _cc_refresh_lock
    if _cc_refresh_lock is None:
        _cc_refresh_lock = asyncio.Lock()
    return _cc_refresh_lock


def _get_ws_lock() -> "asyncio.Lock":
    global _ws_refresh_lock
    if _ws_refresh_lock is None:
        _ws_refresh_lock = asyncio.Lock()
    return _ws_refresh_lock


# Tools that authenticate with CARECLOUD_BEARER_TOKEN (all others use COMPANION_TOKEN)
# Imported from the single authoritative routing table in token_refresh_service.
from token_refresh_service import CARECLOUD_TOOLS as _CARECLOUD_TOOL_NAMES


def _is_auth_failure(result_text: str) -> bool:
    """Check if a tool result indicates an authorization / authentication failure."""
    if not result_text:
        return False
    lower = result_text.lower()
    auth_keywords = [
        "unauthorized", "401", "403", "forbidden",
        "token expired", "token invalid", "invalid token",
        "authentication failed", "authorization failed", "auth failed",
        "not authenticated", "not authorized",
        "access denied", "invalid credentials", "session expired",
        "authtoken", "invalid_grant", "token_expired",
    ]
    if any(kw in lower for kw in auth_keywords):
        return True
    # CareCloud-specific: {"error_code": "0037", ... "message": "Authorization Failed"}
    if '"error_code"' in lower and '"0037"' in lower:
        return True
    return False


def _reload_tokens_from_db() -> None:
    """Sync tokens into TokenManager (→ os.environ) from DB if DB is reachable.

    TokenManager.load_from_db() is the single path for DB→memory. It already
    captures all exceptions internally, so this is always safe to call.
    If the DB is unreachable, TokenManager keeps the tokens it already holds
    in memory (set by the last successful fetch), and os.environ stays in sync
    via the property setters — no dead tokens, no crash.
    """
    from token_manager import TokenManager
    TokenManager().load_from_db()


def _refresh_companion_token() -> None:
    """Fetch a fresh Companion token and route it through TokenManager.

    Flow: HTTP fetch → TokenManager.ws_token (updates os.environ) → DB (best-effort).
    DB failure is logged but does not stop the agent.
    """
    from WS_TOKEN import get_fresh_ws_token
    from token_manager import TokenManager
    try:
        new_token = get_fresh_ws_token()
        TokenManager().ws_token = new_token          # updates os.environ["COMPANION_TOKEN"]
        TokenManager().persist_to_db()               # best-effort DB write
        _auth_logger.info("Companion (WS) token refreshed via TokenManager (len=%d)", len(new_token))
    except Exception as exc:
        _auth_logger.error("Companion token refresh failed: %s", exc)


def _refresh_carecloud_token() -> None:
    """Fetch a fresh CareCloud token and route it through TokenManager.

    Flow: HTTP fetch → TokenManager.ex_token (updates os.environ) → DB (best-effort).
    DB failure is logged but does not stop the agent.
    """
    from EX_TOKEN import get_fresh_ex_token
    from token_manager import TokenManager
    try:
        new_token = get_fresh_ex_token()
        TokenManager().ex_token = new_token          # updates os.environ["CARECLOUD_BEARER_TOKEN"]
        TokenManager().persist_to_db()               # best-effort DB write
        _auth_logger.info("CareCloud (EX) token refreshed via TokenManager (len=%d)", len(new_token))
    except Exception as exc:
        _auth_logger.error("CareCloud token refresh failed: %s", exc)

# A minimal FunctionTool class used by the agent.
class FunctionTool:
    def __init__(self, name: str, description: str, params_json_schema: Dict[str, Any], on_invoke_tool, strict_json_schema: bool = False):
        self.name = name
        self.description = description
        self.params_json_schema = params_json_schema
        self.on_invoke_tool = on_invoke_tool  # This should be an async function.
        self.strict_json_schema = strict_json_schema

    def __repr__(self):
        return f"FunctionTool(name={self.name})"


class ContextMemory:
    """Minimal in-memory store for user-selected IDs to reuse across tool calls."""

    _state: Dict[str, Any] = {}
    _lock = asyncio.Lock()

    @staticmethod
    def _is_blank(value: Any) -> bool:
        if value is None:
            return True
        if isinstance(value, str):
            return value.strip() == ""
        if isinstance(value, (list, dict, tuple, set)):
            return len(value) == 0
        return False

    @classmethod
    async def _store_value(cls, key: str, value: Any) -> None:
        """Directly store a value in context memory."""
        async with cls._lock:
            cls._state[key] = value

    @classmethod
    async def sync_arguments(cls, arguments: Dict[str, Any], schema: Dict[str, Any], logger) -> None:
        """
        Persist provided IDs and inject remembered ones when missing.

        Tracks: location_id(s), resource_id(s), visit_reason_id, nature_of_visit_id, patient_id, appointment_id, provider_id.
        
        IMPORTANT: 
        - Always prioritizes newly provided values (never assumes)
        - Only injects stored values when explicitly missing from current call
        - Latest values always override old ones
        """

        aliases = {
            "location_id": "location_id",
            "location_ids": "location_id",
            "resource_id": "resource_id",
            "resource_ids": "resource_id",
            "visit_reason_id": "visit_reason_id",
            "nature_of_visit_id": "nature_of_visit_id",
            "patient_id": "patient_id",
            "patient_ids": "patient_id",
            "appointment_id": "appointment_id",
            "provider_id": "provider_id",
        }

        schema_props = schema.get("properties", {}) if isinstance(schema, dict) else {}
        injected = {}
        remembered = {}
        updated = {}

        async with cls._lock:
            for arg_name, canonical in aliases.items():
                # Only touch args that are part of this tool's schema (when available)
                if schema_props and arg_name not in schema_props:
                    continue

                raw_value = arguments.get(arg_name)

                # PRIORITY 1: Remember newly provided values (latest info always wins)
                if not cls._is_blank(raw_value):
                    old_value = cls._state.get(canonical)
                    cls._state[canonical] = raw_value
                    remembered[canonical] = raw_value
                    
                    # Log if we're updating an existing value
                    if old_value and old_value != raw_value:
                        updated[canonical] = f"{old_value} → {raw_value}"
                        logger.info(f"🔄 Updated {canonical}: {old_value} → {raw_value} (using latest)")
                    continue

                # PRIORITY 2: Inject stored value ONLY when current call is missing/blank
                if canonical in cls._state:
                    arguments[arg_name] = cls._state[canonical]
                    injected[arg_name] = cls._state[canonical]

        if remembered:
            logger.info(
                "📝 Stored context params (latest): " + ", ".join(f"{k}={v}" for k, v in remembered.items())
            )
        if injected:
            logger.info(
                "✅ Injected context params (from memory): " + ", ".join(f"{k}={v}" for k, v in injected.items())
            )

class MCPUtil:
    @classmethod
    async def get_function_tools(cls, server, convert_schemas_to_strict: bool) -> List[FunctionTool]:
        tools = await server.list_tools()
        function_tools = []
        for tool in tools:
            ft = cls.to_function_tool(tool, server, convert_schemas_to_strict)
            function_tools.append(ft)
        return function_tools

    @classmethod
    def to_function_tool(cls, tool, server, convert_schemas_to_strict: bool) -> FunctionTool:
        # In a more complete implementation, you might convert the JSON schema into a strict version.
        schema = tool.inputSchema

        # OpenAI requires tool names to match ^[a-zA-Z0-9_-]+$ (no spaces or special chars).
        # Sanitize by replacing any disallowed character with an underscore.
        # The original name is captured in the closure so server.call_tool still uses it.
        sanitized_name = re.sub(r'[^a-zA-Z0-9_\-]', '_', tool.name)
        if sanitized_name != tool.name:
            logging.getLogger(__name__).info(
                f"[MCPUtil] Tool name sanitized: '{tool.name}' → '{sanitized_name}'"
            )

        # Use a default argument to capture the current tool correctly in the closure
        async def invoke_tool(context: Any, input_json: str, current_tool_name=tool.name) -> str:
            logger = logging.getLogger(__name__)
            
            try:
                arguments = json.loads(input_json) if input_json else {}
            except Exception as e:
                # Return error message as string
                return f"Error parsing input JSON for tool '{current_tool_name}': {e}"
            
            # Automatically inject tokens from environment for tools that require them.
            # This keeps tokens out of the LLM-visible schema but satisfies the MCP tool schema.

            # CareCloud tools → CARECLOUD_BEARER_TOKEN injected into web_token
            carecloud_tools = {
                "get_appointments_list", "Appoitment_template",
                "Blockout", "get_provider_appointments", "Visit_Reasons",
                # NOTE: 'Locations' removed - using local get_available_locations() instead
            }

            # Companion tools → COMPANION_TOKEN injected into web_token
            companion_tools = {
                "RMSM_update_demographics", "RMSM_3277_primary_care_physician",
                "RMSM_3277_referral_source", "RMSM_3277_referring_physician",
                "get_state_codes", "Business-entity", "Create_Task", "Create_Encounter",
                "create_appointment", "Patient_Verification", "create_patient",
                "Available_time_slots", "Open_Encounter_tab", "Cancel_Appointment",
                "update_demographics",
                # Insurance & Eligibility tools
                "create_insurance", "insurance-profiles", "eligibility",
                "insurance_policies_update", "find-by-tracer-number",
            }

            def _inject_tokens(args: dict, tool_name: str) -> None:
                """Inject the latest tokens from os.environ into the arguments dict."""
                if tool_name in companion_tools:
                    token = os.environ.get("COMPANION_TOKEN")
                    if token is not None:
                        args["COMPANION_TOKEN"] = token
                        if "web_token" in args:
                            args["web_token"] = token
                        logger.info(f"✅ Injected COMPANION_TOKEN for '{tool_name}' (token length: {len(token)})")

                if tool_name in carecloud_tools:
                    token = os.environ.get("CARECLOUD_BEARER_TOKEN")
                    if token is not None:
                        args["CARECLOUD_BEARER_TOKEN"] = token
                        if "web_token" in args:
                            args["web_token"] = token
                        if "ex_token" in args:
                            args["ex_token"] = token
                        if "Ex_Token" in args:
                            args["Ex_Token"] = token
                        logger.info(f"✅ Injected CARECLOUD_BEARER_TOKEN for '{tool_name}' (token length: {len(token)})")

            # --- Initial token injection ---
            _inject_tokens(arguments, current_tool_name)

            # Inject or remember context-sensitive IDs (location/resource/visit reason)
            await ContextMemory.sync_arguments(arguments, schema, logger)

            # ------------------------------------------------------------------
            # Helper: execute the tool call and return the result as a string
            # ------------------------------------------------------------------
            async def _reconnect_server() -> None:
                """Force-reconnect the MCP server (cleanup + fresh connect)."""
                try:
                    logger.info(f"🔄 Reconnecting MCP server for '{current_tool_name}'…")
                    await server.cleanup()
                    await asyncio.sleep(0.5)
                    await server.connect()
                    logger.info("✅ MCP server reconnection successful")
                except Exception as re_err:
                    logger.error(f"❌ MCP server reconnection failed: {re_err}")
                    raise

            # Connection-related error types that should trigger a reconnect + retry
            _CONN_ERROR_TYPES = {
                'ClosedResourceError', 'ConnectionError', 'TimeoutError',
                'RemoteProtocolError', 'ReadError', 'WriteError',
                'ConnectError', 'PoolTimeout', 'BrokenResourceError',
            }

            async def _execute_tool_call() -> str:
                """Run the MCP tool call with connection-level retry."""
                max_conn_retries = 2
                for attempt in range(max_conn_retries):
                    try:
                        if not hasattr(server, 'session') or server.session is None or not getattr(server, 'connected', False):
                            logger.warning(f"Server not connected, attempting to reconnect (attempt {attempt + 1}/{max_conn_retries})")
                            await _reconnect_server()

                        result = await server.call_tool(current_tool_name, arguments)

                        # --- Convert MCP result to string ---
                        if hasattr(result, 'content') and isinstance(result.content, list) and len(result.content) >= 1:
                            if len(result.content) == 1:
                                content_item = result.content[0]
                                if isinstance(content_item, (str, int, float, bool)):
                                    return str(content_item)
                                elif hasattr(content_item, 'text'):
                                    return content_item.text
                                else:
                                    try:
                                        return json.dumps(content_item)
                                    except TypeError:
                                        return str(content_item)
                            else:
                                extracted_content = []
                                for item in result.content:
                                    if hasattr(item, 'text'):
                                        extracted_content.append(item.text)
                                    elif isinstance(item, (str, int, float, bool)):
                                        extracted_content.append(item)
                                    else:
                                        try:
                                            extracted_content.append(json.dumps(item))
                                        except TypeError:
                                            extracted_content.append(str(item))
                                return json.dumps(extracted_content)
                        else:
                            try:
                                return json.dumps(result)
                            except TypeError:
                                return str(result)

                    except Exception as e:
                        error_type = type(e).__name__
                        if error_type in _CONN_ERROR_TYPES and attempt < max_conn_retries - 1:
                            logger.warning(f"Connection error on attempt {attempt + 1}, reconnecting: {error_type}: {e}")
                            try:
                                await _reconnect_server()
                                logger.info("Reconnection successful, retrying tool call")
                                continue
                            except Exception as reconnect_error:
                                logger.error(f"Failed to reconnect: {reconnect_error}")

                        error_details = str(e)
                        if hasattr(e, 'response') and hasattr(e.response, 'text'):
                            error_details += f" Response: {e.response.text}"
                        elif hasattr(e, 'args') and e.args:
                            error_details = f"{error_type}: {' '.join(str(arg) for arg in e.args)}"
                        return f"Error calling tool '{current_tool_name}': {error_details}"

                return f"Error: Failed to execute tool '{current_tool_name}' after {max_conn_retries} attempts"

            # ==================================================================
            # AUTH-AWARE RETRY LOGIC
            # Phase 1: Execute the tool call
            # Phase 2: If auth failure → reload tokens from DB → retry
            # Phase 3: If still auth failure → run full OAuth refresh → retry
            # ==================================================================

            # --- Phase 1: First attempt ---
            result_text = await _execute_tool_call()

            if not _is_auth_failure(result_text):
                return result_text

            # --- Phase 2: Auth failed → reload fresh tokens from DB and retry ---
            logger.warning(f"⚠️ Auth failure detected for '{current_tool_name}'. Reloading tokens from DB…")
            _reload_tokens_from_db()
            _inject_tokens(arguments, current_tool_name)

            result_text = await _execute_tool_call()

            if not _is_auth_failure(result_text):
                logger.info(f"✅ Retry after DB token reload succeeded for '{current_tool_name}'")
                return result_text

            # --- Phase 3: Still failing → targeted async (non-blocking) OAuth refresh ---
            # Only refreshes the token type relevant to this tool to minimise dead air.
            # Uses asyncio.to_thread() so the event loop stays responsive during the
            # HTTP OAuth flow. A per-token lock ensures only ONE refresh fires at a time
            # even if multiple concurrent calls hit Phase 3 simultaneously.
            logger.warning(f"⚠️ Auth still failing for '{current_tool_name}' after DB reload. Running full token refresh…")

            _is_cc_tool = current_tool_name in _CARECLOUD_TOOL_NAMES

            if _is_cc_tool:
                logger.info(f"🔄 Refreshing CareCloud (EX) token for '{current_tool_name}'…")
                async with _get_cc_lock():
                    await asyncio.to_thread(_refresh_carecloud_token)
            else:
                logger.info(f"🔄 Refreshing Companion (WS) token for '{current_tool_name}'…")
                async with _get_ws_lock():
                    await asyncio.to_thread(_refresh_companion_token)

            # Reload DB → env vars so the freshly written token is visible to this process
            _reload_tokens_from_db()
            _inject_tokens(arguments, current_tool_name)

            # The SSE connection may have gone stale during the OAuth flow.
            # Reconnect with a 5-second timeout so we never hang indefinitely.
            try:
                await asyncio.wait_for(_reconnect_server(), timeout=5.0)
            except asyncio.TimeoutError:
                logger.warning(f"⚠️ MCP reconnect timed out after token refresh for '{current_tool_name}' — proceeding anyway")
            except Exception as rc_err:
                logger.error(f"MCP reconnection failed after token refresh: {rc_err}")
                return f"Error: MCP server reconnection failed after token refresh for '{current_tool_name}': {rc_err}"

            result_text = await _execute_tool_call()

            if not _is_auth_failure(result_text):
                logger.info(f"✅ Retry after full token refresh succeeded for '{current_tool_name}'")
            else:
                logger.error(f"❌ Tool '{current_tool_name}' still failing after full token refresh. Returning error.")

            return result_text

        return FunctionTool(
            name=sanitized_name,
            description=tool.description,
            params_json_schema=schema,
            on_invoke_tool=invoke_tool,
            strict_json_schema=convert_schemas_to_strict,
        )