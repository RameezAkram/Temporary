"""
TokenManager — Singleton that holds both auth tokens in memory and schedules
background refresh using threading.Timer (non-blocking, self-rescheduling).

Usage (in agent.py or any other entry point):
    from token_manager import TokenManager
    TokenManager().load_from_db()   # load initial tokens on startup
    TokenManager().start()          # kick off the background refresh cycle
"""

import os
import logging
import threading
from dotenv import load_dotenv

from db import persist_both_tokens, fetch_tokens_from_both_dbs

load_dotenv()

logger = logging.getLogger("token_manager")
if not logger.handlers:
    _handler = logging.StreamHandler()
    _handler.setFormatter(logging.Formatter(
        "%(asctime)s [TOKEN_MANAGER] %(levelname)s %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    ))
    logger.addHandler(_handler)
    logger.setLevel(logging.INFO)

# Refresh every 3 hours — same cadence as the previous 8× daily schedule
REFRESH_INTERVAL_SECONDS = 3 * 60 * 60

BUSINESS_ENTITY_ID = os.getenv("BUSINESS_ID", "4944")


class TokenManager:
    """Singleton holder for CareCloud EX and WS auth tokens.

    Access the singleton instance via TokenManager() — the same object is
    returned on every call thanks to __new__.

    Members
    -------
    ex_token : str   CareCloud OAuth2 bearer token (CARECLOUD_BEARER_TOKEN)
    ws_token : str   Companion WS auth token       (COMPANION_TOKEN)

    Both setters automatically keep os.environ in sync so all existing code
    that reads os.environ["CARECLOUD_BEARER_TOKEN"] / os.environ["COMPANION_TOKEN"]
    continues to work without modification.
    """

    _instance = None
    _class_lock = threading.Lock()

    def __new__(cls):
        with cls._class_lock:
            if cls._instance is None:
                inst = super().__new__(cls)
                inst._ex_token = ""
                inst._ws_token = ""
                inst._timer: threading.Timer | None = None
                inst._started = False
                cls._instance = inst
        return cls._instance

    # ------------------------------------------------------------------
    # Token properties — setters keep os.environ in sync
    # ------------------------------------------------------------------

    @property
    def ex_token(self) -> str:
        return self._ex_token

    @ex_token.setter
    def ex_token(self, value: str) -> None:
        self._ex_token = value
        os.environ["CARECLOUD_BEARER_TOKEN"] = value

    @property
    def ws_token(self) -> str:
        return self._ws_token

    @ws_token.setter
    def ws_token(self, value: str) -> None:
        self._ws_token = value
        os.environ["COMPANION_TOKEN"] = value

    # ------------------------------------------------------------------
    # Startup: load initial tokens from DB
    # ------------------------------------------------------------------

    def load_from_db(self) -> None:
        """Read both tokens from TokenTable (MySQL primary, SQL Server fallback).

        Captures all exceptions and logs them — never raises so startup is not
        blocked by a DB outage.
        """
        try:
            tokens = fetch_tokens_from_both_dbs(BUSINESS_ENTITY_ID)
            ex = tokens.get("ex_auth_token") or ""
            ws = tokens.get("ws_auth_token") or ""
            if ex:
                self.ex_token = ex
                logger.info("Loaded ex_auth_token from DB (len=%d)", len(ex))
            else:
                logger.warning("ex_auth_token missing in TokenTable")
            if ws:
                self.ws_token = ws
                logger.info("Loaded ws_auth_token from DB (len=%d)", len(ws))
            else:
                logger.warning("ws_auth_token missing in TokenTable")
        except Exception as exc:
            logger.error("load_from_db failed: %s", exc)

    # ------------------------------------------------------------------
    # Refresh: the "my_function" called by threading.Timer
    # ------------------------------------------------------------------

    def _do_refresh(self) -> None:
        """Fetch both fresh tokens, update this singleton, and persist to DB.

        Steps
        -----
        1. Get the new ex_token  (pure HTTP, no side effects in EX_TOKEN)
        2. Update self.ex_token  (also updates os.environ)
        3. Get the new ws_token  (pure HTTP, no side effects in WS_TOKEN)
        4. Update self.ws_token  (also updates os.environ)
        5. Update both tokens in the database (single UPDATE query)
           — DB exception is caught, logged, and execution continues
        6. Reschedule the next refresh via threading.Timer
        """
        logger.info("=" * 50)
        logger.info("Token refresh starting…")

        # ── Step 1 & 2: EX token ─────────────────────────────────────────────
        try:
            from EX_TOKEN import get_fresh_ex_token
            new_ex = get_fresh_ex_token()
            self.ex_token = new_ex
            logger.info("ex_token refreshed and updated in singleton (len=%d)", len(new_ex))
        except Exception as exc:
            logger.error("ex_token refresh failed: %s — keeping current token", exc)
            new_ex = self._ex_token  # keep whatever we have

        # ── Step 3 & 4: WS token ─────────────────────────────────────────────
        try:
            from WS_TOKEN import get_fresh_ws_token
            new_ws = get_fresh_ws_token()
            self.ws_token = new_ws
            logger.info("ws_token refreshed and updated in singleton (len=%d)", len(new_ws))
        except Exception as exc:
            logger.error("ws_token refresh failed: %s — keeping current token", exc)
            new_ws = self._ws_token  # keep whatever we have

        # ── Step 5: Persist both tokens to both databases ────────────────────
        try:
            persist_both_tokens(new_ex, new_ws, BUSINESS_ENTITY_ID)
        except Exception as exc:
            logger.error(
                "DB update failed (tokens are still live in memory/env): %s", exc
            )

        logger.info("Token refresh complete ✓")
        logger.info("=" * 50)

        # ── Step 6: Reschedule next refresh ───────────────────────────────────
        self._schedule_next()

    # ------------------------------------------------------------------
    # Timer management
    # ------------------------------------------------------------------

    def _schedule_next(self) -> None:
        """Create and start a one-shot daemon Timer for the next refresh."""
        self._timer = threading.Timer(REFRESH_INTERVAL_SECONDS, self._do_refresh)
        self._timer.daemon = True
        self._timer.name = "token-refresh-timer"
        self._timer.start()
        logger.info(
            "Next token refresh scheduled in %.0f seconds (%.1f hours)",
            REFRESH_INTERVAL_SECONDS,
            REFRESH_INTERVAL_SECONDS / 3600,
        )

    def persist_to_db(self) -> None:
        """Write the current in-memory tokens to the database.

        Best-effort: DB being unreachable is logged but never raises so the
        caller (mcp_client, token_refresh_service, etc.) keeps running with
        the tokens already live in memory and os.environ.
        """
        try:
            persist_both_tokens(self._ex_token, self._ws_token, BUSINESS_ENTITY_ID)
        except Exception as exc:
            logger.error(
                "persist_to_db failed (tokens still live in memory/env): %s", exc
            )

    def start(self) -> None:
        """Start the background refresh cycle (call once at application startup).

        Idempotent — calling start() a second time on the same singleton is a no-op.
        """
        if self._started:
            logger.info("TokenManager already started — skipping duplicate start()")
            return
        self._started = True
        self._schedule_next()
        logger.info("TokenManager background refresh started (interval=%ds)", REFRESH_INTERVAL_SECONDS)
