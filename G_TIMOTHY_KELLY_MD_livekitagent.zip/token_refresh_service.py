"""
Token Refresh Service
---------------------
Single source of truth for:
  - Tool → service routing (which tools use COMPANION_TOKEN vs CARECLOUD_BEARER_TOKEN)
  - Async refresh of BOTH tokens on any failure (non-blocking, uses asyncio.to_thread)
  - DB write + os.environ sync after every refresh
  - Audio feedback (keyboard typing + verbal cue) while tokens are being refreshed
  - LLM-callable @function_tool wrapper so the agent can trigger a refresh directly

Usage (internal, awaited by agent_tools.py on auth failure):
    result = await refresh_token_for_tool(tool_name)
    kwargs['web_token'] = result["token"]

Usage (LLM-visible tool, registered in agent.py):
    from token_refresh_service import create_refresh_token_tool
    agent._tools.append(create_refresh_token_tool())
"""

import asyncio
import logging
import os
import time
from typing import Any, Optional

logger = logging.getLogger("token_refresh_service")

# ── Agent session reference ──────────────────────────────────────────────────
# Set by agent.py after AgentSession creation.  Used to play keyboard typing
# sounds and a verbal cue while tokens are being refreshed so the caller
# doesn't hear dead air.
_agent_session: Optional[Any] = None


def set_agent_session(session) -> None:
    """Set the AgentSession reference so token refresh can provide audio feedback."""
    global _agent_session
    _agent_session = session
    logger.info("[TOKEN_REFRESH] Agent session reference set for audio feedback")


# ── Authoritative tool → service routing ─────────────────────────────────────
# These frozensets are imported by mcp_client/agent_tools.py and
# mcp_client/util.py — do NOT redefine them elsewhere.

COMPANION_TOOLS: frozenset = frozenset({
    'Patient_Verification', 'create_patient', 'update_demographics',
    'create_insurance', 'insurance_policies_update', 'insurance-profiles',
    'eligibility', 'Available_time_slots', 'create_appointment',
    'Cancel_Appointment', 'Business-entity', 'get_providers', 'get_resources',
    'Create_Encounter', 'Open_Encounter_tab',
    'Create_Task', 'find-by-tracer-number',
})

CARECLOUD_TOOLS: frozenset = frozenset({
    'get_appointments_list', 'Appoitment_template',
    'Blockout', 'get_provider_appointments', 'Visit_Reasons',
})

# ── Per-service async locks ────────────────────────────────────────────────────
# Prevents concurrent OAuth storms: only one refresh fires per service at a time;
# parallel callers wait and then reuse the fresh token from DB.
_companion_lock: "asyncio.Lock | None" = None
_carecloud_lock: "asyncio.Lock | None" = None


def _get_companion_lock() -> asyncio.Lock:
    global _companion_lock
    if _companion_lock is None:
        _companion_lock = asyncio.Lock()
    return _companion_lock


def _get_carecloud_lock() -> asyncio.Lock:
    global _carecloud_lock
    if _carecloud_lock is None:
        _carecloud_lock = asyncio.Lock()
    return _carecloud_lock


# ── Audio feedback during refresh ─────────────────────────────────────────────

async def _play_refresh_audio_feedback():
    """Play keyboard typing sounds + a verbal cue while tokens are refreshing.

    Uses the agent session's say() method which triggers the
    BackgroundAudioPlayer's thinking_sound (keyboard typing) automatically
    in the gap before TTS starts synthesizing the verbal cue.
    """
    if not _agent_session:
        logger.debug("[TOKEN_REFRESH] No agent session — skipping audio feedback")
        return
    try:
        logger.info("[TOKEN_REFRESH] Playing audio feedback (keyboard typing + verbal cue)")
        await _agent_session.say(
            "One moment please, I'm updating our system.",
            allow_interruptions=True,
        )
    except asyncio.CancelledError:
        pass
    except Exception as exc:
        logger.warning("[TOKEN_REFRESH] Audio feedback failed (non-fatal): %s", exc)


# ── Proactive CareCloud token freshness check ─────────────────────────────────

# Guard against concurrent proactive refreshes (one at a time is enough).
_proactive_refresh_in_flight: bool = False

_FRESHNESS_BUFFER_SECONDS = 300  # refresh 5 minutes before the token expires


def is_carecloud_token_fresh() -> bool:
    """Return True if the CareCloud token is not yet close to expiry.

    Reads CARECLOUD_TOKEN_REFRESHED_AT and CARECLOUD_TOKEN_EXPIRES_IN from
    os.environ (set by EX_TOKEN.refresh_token() after every successful refresh).
    If those env vars are absent (first startup before first scheduled refresh)
    we assume the DB-loaded token is still valid and return True to avoid an
    unnecessary refresh on every call.
    """
    refreshed_at_str = os.environ.get("CARECLOUD_TOKEN_REFRESHED_AT", "")
    expires_in_str = os.environ.get("CARECLOUD_TOKEN_EXPIRES_IN", "")
    if not refreshed_at_str or not expires_in_str:
        # Timestamps not recorded yet — trust whatever the DB gave us.
        return True
    try:
        refreshed_at = float(refreshed_at_str)
        expires_in = float(expires_in_str)
        age = time.time() - refreshed_at
        fresh = age < (expires_in - _FRESHNESS_BUFFER_SECONDS)
        if not fresh:
            logger.warning(
                "[TOKEN_FRESHNESS] CareCloud token is stale "
                "(age=%.0fs, expires_in=%.0fs, buffer=%ds)",
                age, expires_in, _FRESHNESS_BUFFER_SECONDS,
            )
        return fresh
    except (ValueError, TypeError) as exc:
        logger.warning("[TOKEN_FRESHNESS] Could not parse freshness env vars: %s", exc)
        return True  # Assume fresh if unparseable — reactive refresh will catch real failures


async def ensure_carecloud_token_fresh() -> None:
    """Proactively refresh the CareCloud token if it is close to expiry.

    Called by agent_tools.py before every CARECLOUD tool invocation.
    Skips if the token is still fresh, and de-duplicates concurrent callers
    to avoid refresh storms when multiple tools are invoked in quick succession.

    This function never raises — failures are logged and the tool call proceeds
    (the reactive auth-error handler in agent_tools.py will catch real failures).
    """
    global _proactive_refresh_in_flight
    if is_carecloud_token_fresh():
        return
    if _proactive_refresh_in_flight:
        # Another coroutine is already refreshing — wait briefly then continue.
        logger.info("[TOKEN_FRESHNESS] Proactive refresh already in-flight, waiting…")
        await asyncio.sleep(0.5)
        return
    _proactive_refresh_in_flight = True
    try:
        logger.info("[TOKEN_FRESHNESS] Proactive CareCloud token refresh starting…")
        ok = await _refresh_single_service("carecloud")
        if ok:
            logger.info("[TOKEN_FRESHNESS] Proactive CareCloud token refresh succeeded")
        else:
            logger.warning(
                "[TOKEN_FRESHNESS] Proactive CareCloud token refresh failed — "
                "proceeding with existing token (reactive handler will catch errors)"
            )
    except Exception as exc:
        logger.error("[TOKEN_FRESHNESS] Proactive refresh raised unexpected exception: %s", exc)
    finally:
        _proactive_refresh_in_flight = False


# ── Core async refresh — refreshes BOTH tokens on any failure ─────────────────

async def _refresh_single_service(service: str) -> bool:
    """Fetch a fresh token and push it through TokenManager (→ os.environ → DB).

    Flow for every refresh path:
        HTTP fetch → TokenManager member (os.environ updated via setter)
                   → TokenManager.persist_to_db() (best-effort, DB failure is logged)

    Returns True on success, False on exception.
    """
    try:
        if service == "carecloud":
            async with _get_carecloud_lock():
                from EX_TOKEN import get_fresh_ex_token
                from token_manager import TokenManager
                new_token = await asyncio.to_thread(get_fresh_ex_token)
                TokenManager().ex_token = new_token          # → os.environ["CARECLOUD_BEARER_TOKEN"]
                await asyncio.to_thread(TokenManager().persist_to_db)   # → DB (best-effort)
                logger.info(
                    "[TOKEN_REFRESH] CareCloud (EX) token updated in TokenManager+DB (len=%d)",
                    len(new_token),
                )
                return True
        else:
            async with _get_companion_lock():
                from WS_TOKEN import get_fresh_ws_token
                from token_manager import TokenManager
                new_token = await asyncio.to_thread(get_fresh_ws_token)
                TokenManager().ws_token = new_token          # → os.environ["COMPANION_TOKEN"]
                await asyncio.to_thread(TokenManager().persist_to_db)   # → DB (best-effort)
                logger.info(
                    "[TOKEN_REFRESH] Companion (WS) token updated in TokenManager+DB (len=%d)",
                    len(new_token),
                )
                return True
    except Exception as exc:
        logger.error("[TOKEN_REFRESH] %s refresh raised exception: %s", service, exc)
        return False


async def refresh_token_for_tool(tool_name: str) -> dict:
    """
    Refresh BOTH tokens (CareCloud EX + Companion WS) when any tool fails auth.

    When either token expires, the other is likely close to expiring too — so we
    proactively refresh both in parallel to prevent a second auth failure seconds
    later.  Keyboard typing sounds and a verbal cue play while the refresh runs
    so the caller doesn't hear dead air.

    Flow:
      1. Route: identify which service triggered the failure.
      2. Play audio feedback (keyboard typing + verbal cue) in the background.
      3. asyncio.gather → refresh BOTH tokens in parallel (each under its own lock).
      4. Reload DB → os.environ so the fresh tokens are visible to all code paths.
      5. Reset BOTH auth-fail counters on success.
      6. Return a result dict the caller can use immediately.

    Returns:
        {
            "service":   "companion" | "carecloud",   # original triggering service
            "refreshed": bool,        # True if the triggering service's refresh succeeded
            "token":     str,         # fresh token for the triggering service
            "env_key":   str,         # "COMPANION_TOKEN" | "CARECLOUD_BEARER_TOKEN"
            "error":     str | None,  # exception message if refresh failed, else None
            "both_refreshed": bool,   # True if BOTH services refreshed successfully
        }
    """
    is_carecloud = tool_name in CARECLOUD_TOOLS
    service = "carecloud" if is_carecloud else "companion"
    env_key = "CARECLOUD_BEARER_TOKEN" if is_carecloud else "COMPANION_TOKEN"

    logger.warning(
        "[TOKEN_REFRESH] Auth failure for tool='%s' service=%s — refreshing BOTH tokens…",
        tool_name, service,
    )

    # Play audio feedback in the background while tokens refresh
    audio_task = asyncio.create_task(_play_refresh_audio_feedback())

    error_msg = None

    # Refresh BOTH tokens in parallel — each under its own async lock
    try:
        ex_ok, ws_ok = await asyncio.gather(
            _refresh_single_service("carecloud"),
            _refresh_single_service("companion"),
            return_exceptions=False,
        )
        logger.info(
            "[TOKEN_REFRESH] Dual refresh complete — CareCloud=%s, Companion=%s",
            ex_ok, ws_ok,
        )
    except Exception as exc:
        error_msg = str(exc)
        logger.error("[TOKEN_REFRESH] Dual refresh raised exception: %s", exc)
        ex_ok = False
        ws_ok = False

    # Cancel audio task if it's still running
    if audio_task and not audio_task.done():
        audio_task.cancel()

    # The triggering service's success status
    refreshed = ex_ok if is_carecloud else ws_ok
    both_refreshed = ex_ok and ws_ok

    # TokenManager already holds the freshest tokens (set by _refresh_single_service above).
    # Call load_from_db() as a safety sync — no-op if DB is down, graceful fallback to memory.
    try:
        from token_manager import TokenManager
        TokenManager().load_from_db()
    except Exception as exc:
        logger.error("[TOKEN_REFRESH] TokenManager.load_from_db failed: %s", exc)

    token = os.environ.get(env_key, "")
    logger.info(
        "[TOKEN_REFRESH] Done — service=%s refreshed=%s both_refreshed=%s token_len=%d",
        service, refreshed, both_refreshed, len(token),
    )

    # Reset BOTH auth-fail counters when refresh succeeds so the pre-emptive guard
    # allows the next tool retry through for both services.
    try:
        from mcp_client.agent_tools import reset_auth_fail_count
        if ex_ok:
            reset_auth_fail_count("carecloud")
        if ws_ok:
            reset_auth_fail_count("companion")
    except Exception as exc:
        logger.warning("[TOKEN_REFRESH] Could not reset auth fail count: %s", exc)

    return {
        "service":        service,
        "refreshed":      refreshed,
        "token":          token,
        "env_key":        env_key,
        "error":          error_msg,
        "both_refreshed": both_refreshed,
    }


# ── LLM-callable @function_tool factory ──────────────────────────────────────

def create_refresh_token_tool():
    """
    Return a LiveKit @function_tool that the LLM can call to refresh a token.

    The LLM should call this only when explicitly instructed to — e.g. when a
    SYSTEM ERROR message tells it the auth service is unavailable and a retry
    is warranted ONLY after a successful refresh.

    IMPORTANT: Normal auth failures are handled automatically by agent_tools.py.
    The LLM should call transfer_to_human() on persistent failures — NOT loop
    on this tool.
    """
    from livekit.agents.llm import function_tool

    @function_tool
    async def refresh_token_for_service(service: str) -> str:
        """Refresh the authentication token for a CareCloud service.
        Call this ONLY when instructed by a SYSTEM ERROR message.
        After a successful refresh, retry the original tool once.
        If the refresh fails, say 'Let me connect you with the office.' and call transfer_to_human().

        Args:
            service: Which service token to refresh.
                     Use 'companion' for: Patient_Verification, create_appointment,
                     Available_time_slots, create_insurance, Cancel_Appointment, and all
                     patient/scheduling Companion tools.
                     Use 'carecloud' for: get_appointments_list, Blockout,
                     get_provider_appointments, Visit_Reasons, Appoitment_template.
        """
        # Map the human-readable service name to a known tool for routing.
        # refresh_token_for_tool will refresh BOTH tokens regardless.
        _sentinel_tool = "Patient_Verification" if service.lower() == "companion" else "get_appointments_list"
        result = await refresh_token_for_tool(_sentinel_tool)

        if result["refreshed"]:
            both = " (both tokens refreshed)" if result.get("both_refreshed") else ""
            return (
                f"Token refreshed successfully for service='{result['service']}'{both} "
                f"(token_len={len(result['token'])}). "
                f"You may now retry the tool that failed. If it fails again, call transfer_to_human()."
            )
        else:
            err = result.get("error") or "unknown error"
            return (
                f"Token refresh FAILED for service='{result['service']}': {err}. "
                f"Say 'Let me connect you with the office.' and call transfer_to_human() immediately."
            )

    return refresh_token_for_service
